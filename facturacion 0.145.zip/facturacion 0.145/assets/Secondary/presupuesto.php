<?php

function addheadertoDB() {
    //HEADER DETAILS - VAR DECLARATION
    $uID = $_POST['uid'];
    $uName = $_POST['uiname'];
    $uTlf = $_POST['uitlf'];
    $uDNI = $_POST['uiDNI'];
    $uDir = $_POST['uidir'];
    $uother1 = $_POST['uiother1'];
    $uother2 = $_POST['uiother2'];
    $uPresNum = $_POST['uipresnum'];
    $uEmail = $_POST['uiemail'];
    $uDate = $_POST['uidate'];
    $uPresName = $_POST['uipresname'];
    
    
}

?>