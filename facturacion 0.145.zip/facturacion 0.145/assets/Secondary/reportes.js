let HFROM = document.querySelector("#DATEFROM");
let HTO = document.querySelector("#DATETO");
let DEFFROM = document.querySelector("#DATEFROMdefault");
let DEFTO = document.querySelector("#DATETOdefault");

let fullDate = new Date();
let currYear = fullDate.getUTCFullYear();
let currMonth = fullDate.getUTCMonth() + 1; 
let currDay = fullDate.getUTCDate();


let toggleTriggerReport = document.querySelector('#toggleTrigger')
let toggleTargetReport = document.querySelector('#filter-toggle')
DEFFROM.innerHTML = TrimSelector(currMonth)[0];
HFROM.value = TrimSelector(currMonth)[2];
DEFTO.innerHTML = TrimSelector(currMonth)[1];
HTO.value = TrimSelector(currMonth)[3];

let triggerbtn = document.querySelectorAll('.CNTNTswitch');

let counter = -1;
triggerbtn.forEach(function (trigger) {
    trigger.addEventListener("click", function (e) {
        e.preventDefault();
        console.log(e.target);
        if (trigger.hasAttribute("data-target")) {
            let targetID = "#" + trigger.dataset.target;
            let target = document.querySelector(targetID);
            console.log(target.children.length);
            counter = (counter == target.children.length - 1) ? 0 : counter + 1;
            console.log(counter);
            return contentSwitcher(target, counter);
        }
    })
});

function contentSwitcher(target, counter) {

    let modules = target.children;
    modules = Array.from(modules);
    modules.forEach(function (moduleA) {
        moduleA.classList.add("CNTNT");
        moduleA.classList.remove("CNTNTshown");
    })
    modules[counter].classList.remove("CNTNT");
    console.log(counter)
}



let dropdowns = document.querySelectorAll("[data-assimilatefrom]");
dropdowns.forEach(function(dropdown){
    let ops = dropdown.children;
    Array.from(ops).forEach(function(op){
    op.addEventListener("click",function(){
        let assimailateTo = document.querySelector("[data-assimilateto="+dropdown.dataset.assimilatefrom+"]");
        assimailateTo.innerHTML= op.innerHTML;
        })
    })
})

// let dds = document.querySelectorAll("[data-ddfrom]");
//     dds.forEach(function(dd){
//         Array.from(dd.children).forEach(function(option){
//             option.addEventListener("click", function(){
//                 let ddto = document.querySelector("[data-ddto="+dd.dataset.ddfrom+"]").innerHTML = option.innerHTML;
//             })
//         })
//     })

//MODALS

let modal = document.querySelector("#REPO-modal");
let modalTriggers = document.querySelectorAll(".open-modal");
let modalContent = modal.querySelector(".modal-content");
Array.from(modalTriggers).forEach(function(modalTrigger){
    modalTrigger.addEventListener("click", function(e){
        e.preventDefault();
        $('#REPO-modal').modal('open');
        modalContent.innerHTML = modalTrigger.dataset.modal;
    })
})

//filter toggle
filterToggle(toggleTriggerReport,toggleTargetReport);