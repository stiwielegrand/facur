var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
        if (!mutation.addedNodes) return;

        var editTriggers = document.querySelectorAll('[data-btnAction="edit"]');
        editTriggers.forEach(function(editTrigger){
            editTrigger.addEventListener('click', function(){
                relocate("crear_presupuesto.html","edit",editTrigger.dataset.id)
            })
        })

        for (var i = 0; i < mutation.addedNodes.length; i++) {
            var node = mutation.addedNodes[i];
        }
    })
})

observer.observe(document.body, {
    childList: true
    , subtree: true
    , attributes: false
    , characterData: false
})

document.addEventListener('DOMContentLoaded', function () {

    var tabs = [todos, pendientes, facturados, nofacturados, rechazados, borrador];
    tabs.forEach(function (tab) {
        tab.container.innerHTML = PREScontentHeader + gatherArticles(tab.estado, 1);
        load(tabs);
    });

    contentLoadTriggers = document.querySelectorAll("[data-sidenavArticle]");
    contentLoadTriggers.forEach(function (LoadTrigger) {
        LoadTrigger.addEventListener("click", function () {
            generateContent(LoadTrigger);
        })
    });

    sortingCriteria();
});




function generateArticles(value) {
    if (value.status == 1 ) var currentState = "Pendiente";
    else if (value.status == 3) var currentState = "Aceptado";
    else if (value.status == 4) var currentState = "Facturado";
    else if (value.status == 2) var currentState = "Rechazado";
    let Article = `  
    <li class="collection-item floatIn">
        <div class="row">
            <div class="col l3"><strong><a href="#" class="sidenav-trigger" data-target="rightcontent" data-sidenavArticle="${value.ID}">${value.uipresname}</a></strong></div>
            <div class="col l2">${value.uiname}</div>
            <div class="col l2">${value.uidate}</div>
            <div class="col l1">${value.presnum}</div>
            <div class="col l2">${value.GRANDTOTAL} €</div>
            <div class="col l2 m3 s12">${currentState}</div>
        </div>
    </li>`;
    return Article;
}

function gatherArticles(criteria, page) {
    //PAGINATION vars
    let paginationTop = `<div class="card-action center paginationStyle"><ul class="pagination">`
    let paginationBot = `</ul></div>`
    let paginationBody = "";
    //gather vars
    let PREScontentBody = "";
    var paginated = 0;
    presetSortCrit = localStorage.getItem("presetSortCrit");
    presetRetrieveCrit = localStorage.getItem("presetRetrieveCrit");
    if (!criteria || typeof criteria === 'undefined') var arr = Array.from(retrieveData(presetSortCrit,presetRetrieveCrit));
    else var arr = retrieveData(presetSortCrit,presetRetrieveCrit).filter(element => element.status == criteria);
    if (arr.length > 10) {
        paginated = 1;
        var result = Math.trunc(arr.length / 10);
        var remainder = arr.length % 10;
        if (remainder != 0) result += 1;
        if (page != 1) arr = arr.slice(((page - 1) * 10), (page * 10))
        else arr = arr.slice(0, page * 10)
    }
    if(arr.length == 0) {
        return "<div class='err-display center-align'>No se encontraron resultados</div>";
    }
    arr.forEach(function (valuestopass) {
        PREScontentBody += generateArticles(valuestopass);
    })
    //PAGINATION
    if (paginated == 1) {
        PREScontentBody += "</ul>";
        for (let x = 1; x <= result; x++) {
            if (x != page) {
                paginationBody += `<li><a href="#" class="pageChange" data-page="${x}" data-currenttab="${criteria}">${x}</a></li>`
            } else {
                paginationBody += `<li class="active"><a>${x}</a></li>`
            };
        }
        PREScontentBody += (paginationTop + paginationBody + paginationBot);
    }
    if(paginated = 0) PREScontentBody += "</ul>";
    return PREScontentBody;
}

function generateContent(LoadTrigger) {
    let articleID = LoadTrigger.dataset.sidenavarticle; //ShouldContainTheID
    content = retrieveArticle(articleID);
    console.log("Content gen fired")
    if (content.connection == "success") {
    let other1 = (content.uiother1.length > 0) ? `
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Otros datos:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPother1">${content.uiother1}</span></div>` : "";

    let other2 = (content.uiother2.length > 0) ? `
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Otros datos:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPother2">${content.uiother2}</span></div>` : "";

    function productArticles(productos) {
        return `
            ${content.producto.map(function (producto) {
                    return `
                    <div class="row">
                        <div class="col m8 l8 OPproductDetails">${producto.UIproduct}</div>
                        <div class="col m4 l4 OPproductDetails right-align"><span class="badgeManual grey">${producto.UIcantidad + producto.UIunidad}</span>${producto.UIprecio} €</div>
                        <div class="col m8 l8 OPproductSubDetails">${producto.UIcomsINP}</div>
                        <div class="col m4 l4 OPproductSubDetails right-align">IVA ${producto.UIiva}%</div>
                    </div>`
                }).join('')}`
    }
    console.log(content)
    
        rightcontent.innerHTML = `
                <div class="row articleheader z-depth-1">
                <div class="col m1 l1">
                    <a href="#" class="sidenav-close"><i class="material-icons articleHeaderIcon">clear</i></a>
                </div>
                <div class="col m11 l11 offset-l-1 offset-m-1 center-align">
                    <p id="OPitemTitle">${content.uipresname}</p>
                </div>
            </div>
            <div class="articlecontent">
                <div class="row center-align">
                    <div class="col m2 l2 offset-m1 offset-l1">
                        <button class="waves-effect waves-red btn-flat" data-btnAction="1" data-ID="${content.ID}">Enviar</button>
                    </div>
                    <div class="col m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat" data-btnAction="2" data-ID="${content.ID}"> PDF</button>
                    </div>
                    <div class="col m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat" id="" onclick="PrintElem(content)">Imprimir</button>
                    </div>
                    <div class="col m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat" data-btnAction="edit" data-ID="${content.ID}">Modificar</button>
                    </div>
                    
                    <div class="col m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat" data-btnAction="3">Pendiente</button> 
                    </div>
                </div>
                <div class="row">
                    <div class="col m12 l12 center-align OPitemValueContainer">
                        <h3>
                            <p id="OPitemValue">${content.GRANDTOTAL} €</p>
                        </h3>
                    </div>
                    <div class="col m12 l12 center-align">
                        <h6>
                            <p id="OPitemSubValue">Presupostado el <span id="OPdate">${content.uidate}</span></p>
                        </h6>
                    </div>

                    ${productArticles((content.producto))}
                    <div class="col l9 m9 right-align OPproductSubDetails OPproductSubTotals">SubTotal</div>
                    <div class="col l3 m3 right-align OPproductSubDetails OPproductSubTotals">${content.SUBTOTAL}€</div>
                    <div class="col l9 m9 right-align OPproductSubDetails OPproductSubTotals">IVA (${content.IVAtotalpercent}%)</div>
                    <div class="col l3 m3 right-align OPproductSubDetails OPproductSubTotals">${content.IVAtotalamount}€</div>
                    <div class="col l9 m9 right-align OPproductSubDetails highlight OPproductSubTotals">Total</div>
                    <div class="col l3 m3 right-align OPproductSubDetails highlight OPproductSubTotals">${content.GRANDTOTAL}€</div>
                    <div class="row btnpad">
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Cliente:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPname">${content.uiname}</span></div>
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">DNI:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPDNI">${content.uiDNI}</span></div>
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Dirección:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPdir">${content.uidir}</span></div> 
                        ${other1 + other2}
                    </div>
                </div>
            </div>`;
            console.log(content.GRANDTOTAL)
            animateDigits(OPitemValue,content.GRANDTOTAL,"€")
            document.querySelector(".sidenav-close").addEventListener("click", function(e){
            e.preventDefault();
    })
    } else {
        rightcontent.innerHTML = `<div class='err-display center-align'>No se pudo mostrar el contenido!</div>
                                    <div class='center-align'>
                                    <div class='col s12 err-display-giant'>${content.err}</div>
                                    <div class='col'><textarea style="width:380px; resize:none;">${content.errmsg}</textarea></div>
                                    </div>`;
    }
}

function animateDigits(destinationID, valueTo,suffix) {
    let options = {
    useEasing: true, 
    useGrouping: true, 
    separator: '.', 
    decimal: ',', 
    suffix: suffix 
    };
    var count = new CountUp (destinationID,0,valueTo,2, 1,options);
    if(!count.error) count.start();
}