<?
$id = 125;
try{
    // SELECT THE COLUMNS
    // $stmt  = $pdo->query("SELECT pres.* 
    // FROM  pres
    // WHERE presno=$id AND vers=70"); 
    $stmt  = $pdo->query("SELECT * FROM headers_pres WHERE presno=$id AND vers=(SELECT MAX(vers) FROM headers_pres)"); 
    // $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    // $stmt  = $pdo->query("SELECT * FROM pres WHERE presno=$id");  
    // var_dump($stmt);
    // echo "<br><br>";
    $JSON = new \stdClass();
    while($row = $stmt->fetch()){
        $id = $row['id'];
        echo $id;
        // IVAtotalamount
        // SUBTOTAL
        // IVAtotalpercent
        $JSON->connection = "success";
        // $JSON->ID = $row['id'];
        $JSON->uiname = $row['uiname'];
        $JSON->uitlf = $row['uitlf'];
        // $JSON->uiDNI = $row['uidni'];
        // $JSON->uidir = $row['uidir'];
        // $JSON->uiemail = $row['uiemail'];
        // $JSON->uiother1 = $row['uiother1'];
        // $JSON->uiother2 = $row['uiother2'];
        // $JSON->presnum = $row['presno'];
        $JSON->uipresname = $row['uipresname'];
        // $JSON->uidate = $row['uifecha'];
        // $JSON->SUBTOTAL = $row['SUBTOTAL'];
        // $JSON->uiid = $row['uiid'];
        // $JSON->uiproduct = $row['uiproduct'];
        // $JSON->uicant = $row['uicant'];
        // $JSON->uiunidad = $row['uiunidad'];
        $vers = $row['vers'];
// echo sizeof($row['uiid']);

//         $JSON->uiid = $row['uiid'];
//         $JSON->uiproduct = $row['uiproduct'];
//         $JSON->uicant = $row['uicant'];
//         $JSON->uiunidad = $row['uiunidad'];
    }
    echo "<pre>",var_dump($JSON),"</pre>";

    $stmt2  = $pdo->query("SELECT pres.* FROM pres WHERE presno=$id AND vers=$vers"); 

    $results = $stmt2->fetchAll();
    foreach ($results as $row){
        echo $row['id']."<br>";
        $JSON ->prodid[] = $row['id'];
        $JSON ->prodid[] = $row['uiproduct'];
    }
    echo "<pre>",var_dump($JSON),"</pre>";
}
catch(Exception $e) {
    $JSON->connection = "failed";
    $JSON->err = $e;
}
?>



else
{
        $id = 125;
        try{
            // SELECT THE COLUMNS
            // $stmt  = $pdo->query("SELECT pres.* 
            // FROM  pres
            // WHERE presno=$id AND vers=70"); 
            $stmt  = $pdo->query("SELECT * FROM headers_pres WHERE presno=$id AND vers=(SELECT MAX(vers) FROM headers_pres)"); 
            // $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
            // $stmt  = $pdo->query("SELECT * FROM pres WHERE presno=$id");  
            // var_dump($stmt);
            // echo "<br><br>";
            $JSON = new \stdClass();
            while($row = $stmt->fetch()){
                $id = $row['id'];
                echo $id;
                // IVAtotalamount
                // SUBTOTAL
                // IVAtotalpercent
                $JSON->connection = "success";
                // $JSON->ID = $row['id'];
                $JSON->uiname = $row['uiname'];
                $JSON->uitlf = $row['uitlf'];
                // $JSON->uiDNI = $row['uidni'];
                // $JSON->uidir = $row['uidir'];
                // $JSON->uiemail = $row['uiemail'];
                // $JSON->uiother1 = $row['uiother1'];
                // $JSON->uiother2 = $row['uiother2'];
                // $JSON->presnum = $row['presno'];
                $JSON->uipresname = $row['uipresname'];
                // $JSON->uidate = $row['uifecha'];
                // $JSON->SUBTOTAL = $row['SUBTOTAL'];
                // $JSON->uiid = $row['uiid'];
                // $JSON->uiproduct = $row['uiproduct'];
                // $JSON->uicant = $row['uicant'];
                // $JSON->uiunidad = $row['uiunidad'];
                $vers = $row['vers'];
        // echo sizeof($row['uiid']);

        //         $JSON->uiid = $row['uiid'];
        //         $JSON->uiproduct = $row['uiproduct'];
        //         $JSON->uicant = $row['uicant'];
        //         $JSON->uiunidad = $row['uiunidad'];
            }
            echo "<pre>",var_dump($JSON),"</pre>";

            $stmt2  = $pdo->query("SELECT pres.* FROM pres WHERE presno=$id AND vers=$vers"); 

            $results = $stmt2->fetchAll();
            foreach ($results as $row){
                echo $row['id']."<br>";
                $JSON ->prodid[] = $row['id'];
                $JSON ->prodid[] = $row['uiproduct'];
            }
            echo "<pre>",var_dump($JSON),"</pre>";
        }
        catch(Exception $e) {
            $JSON->connection = "failed";
            $JSON->err = $e;
        }
    }