let PREScontentHeader = `
<ul class="collection entryHolder">
    <li class="collection-item">
        <div class="row">
            <div class="col l3 m3 s4 sortCrit" data-sort="nombre">Presupuesto<i class="material-icons iconalign">arrow_drop_down</i></div>
            <div class="col l2 m3 s4 sortCrit" data-sort="cliente">Cliente<i class="material-icons left iconalign">arrow_drop_down</i></div>
            <div class="col l2 show-on-medium-and-up sortCrit" data-sort="date">Fecha<i class="material-icons left iconalign">arrow_drop_down</i></div>
            <div class="col l1 show-on-medium-and-up sortCrit" data-sort="num">Nº<i class="material-icons left iconalign">arrow_drop_down</i></div>
            <div class="col l2 m2 show-on-medium-and-up sortCrit" data-sort="val">Valor<i class="material-icons left iconalign">arrow_drop_down</i></div>
            <div class="col l2 m4 s4 sortCrit" data-sort="state">Estado<i class="material-icons left iconalign">arrow_drop_down</i></div>
        </div>
    </li>`;

        let Article = `  
    <li class="collection-item floatIn">
        <div class="row">
            <div class="col l3"><strong><a href="#" class="sidenav-trigger" data-target="rightcontent" data-sidenavArticle="${value.ID}">${value.uipresname}</a></strong></div>
            <div class="col l2">${value.uiname}</div>
            <div class="col l2">${value.uidate}</div>
            <div class="col l1">${value.presnum}</div>
            <div class="col l2">${value.GRANDTOTAL} €</div>
            <div class="col l2 m3 s12">${currentState}</div>
        </div>
    </li>`;