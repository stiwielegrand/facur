var todosContainer = document.querySelector("#todos");
var pendientesContainer = document.querySelector("#pendientes");
var facturadosContainer = document.querySelector("#facturados");
var nofacturadosContainer = document.querySelector("#nofacturados");
var rechazadosContainer = document.querySelector("#rechazados");
var borradorContainer = document.querySelector("#borrador");
let contentLoadTriggers;
var pageChangeBtns;
var dateFrom = document.querySelector('input[name="presupuesto-from"]');
var dateTo = document.querySelector('input[name="presupuesto-to"]');
var critForUser = document.querySelector('input[name="presupuesto-foruser"]');
var sortTrigger = document.querySelector('[name="filtrar"]')
var todos = {container: todosContainer,estado: ""};
var pendientes = {container: pendientesContainer,estado: 1};
var facturados = {container: facturadosContainer,estado: 4};
var nofacturados = {container: nofacturadosContainer,estado: 3};
var rechazados = {container: rechazadosContainer,estado: 2};
var borrador = {container: borradorContainer,estado: "?"};
let toggleTriggerPres = document.querySelector('#toggleTrigger')
let toggleTargetPres = document.querySelector('#filter-toggle')

var presetSortCrit;
var presetRetrieveCrit;

const retriveScript = "assets/PHP/loader_pres.php";


//INITS
filterToggle(toggleTriggerPres,toggleTargetPres)