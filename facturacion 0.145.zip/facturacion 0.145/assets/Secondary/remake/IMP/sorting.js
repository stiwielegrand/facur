function sortingCriteria() {
    var sortCrits = document.querySelectorAll('[class*="sortCrit"]');
    presetSortCrit = localStorage.getItem("presetSortCrit");
    presetRetrieveCrit = localStorage.getItem("presetRetrieveCrit");
    if(presetSortCrit !== null || presetRetrieveCrit !== null) {

    if(presetSortCrit !== null) {
        var presetSortElements = document.querySelectorAll("[data-sort='"+presetSortCrit+"']");
        presetSortElements.forEach(function(presetSortElement){
                presetSortElement.classList.add('actual-selection');
        })
    }
    retrieveData(presetSortCrit,presetRetrieveCrit)
    }

    sortCrits.forEach(function(crit){
        crit.addEventListener('click', function(){
            sortCrits.forEach(function(rest){
                rest.classList.remove('actual-selection');
            });
            crit.classList.add('actual-selection');
            let criteriaToStore = crit.dataset.sort;
            presetRetrieveCrit = localStorage.getItem("presetRetrieveCrit");
            localStorage.setItem("presetSortCrit",criteriaToStore)
            // if(presetRetrieveCrit != null) {
            //     presetRetrieveCrit = presetRetrieveCrit;
            // }
            retrieveData(criteriaToStore,presetRetrieveCrit);
        })
    })
    sortTrigger.addEventListener("click", function(){
        var allCriteria = [dateFrom.value,dateTo.value,critForUser.value];
        presetSortCrit = localStorage.getItem("presetSortCrit");
        localStorage.setItem("presetRetrieveCrit",allCriteria)
        retrieveData(presetSortCrit,allCriteria);
    })    

}