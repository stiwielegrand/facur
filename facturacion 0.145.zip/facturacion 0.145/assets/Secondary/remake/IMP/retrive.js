function retrieveData(sorting, criteria) {
    let link = retriveScript + "?type=sorting"
    if (sorting != null) {
        link += "&sorttype=" + sorting;
    }
    if (criteria != null) {
        let i = 1;
        if (Array.isArray(criteria) == false) {
            criteria = criteria.split(",");
        }
        criteria.forEach(function (crit) {
            let char = i++;
            link += "&criteria" + char + "=" + crit;
        })
    }
    console.log(link)
    // return fakeJSON; // TO BE REMOVED

    let XHR = new XMLHttpRequest();
    XHR.addEventListener("error", function () {
        console.log("XHR load Error!");
    })
    XHR.addEventListener("progress", function () {
        loading();
    })
    XHR.addEventListener("load", function () {
        let RES = XHR.response;
        if (XHR.response.includes("MSQROW0") == true) {
            return errDisplay("MSQROW0");
        }
        else {
            function IsJsonString(RES) {
                try {
                    JSON.parse(RES);
                } catch (e) {
                    return errDisplay(e);
                }
                RESPONSE = JSON.parse(RES);
                var defaultPage = 1;
                return display(defaultPage);
            }
        }
    })

    XHR.open("GET", link, true); //TRY FALSE CHECK WHAT LOADS
    XHR.send(); //SEND ID
}

function retrieveArticle(ID) {
    let link = retriveScript + "?type=article&id=" + ID;
    //MAKE ONLOAD AN ANIMATION 
    console.log(ID);
    var fakeJSONarticle = Array.from(fakeJSON).filter(element => element.ID == ID);
    console.log(fakeJSONarticle)

    return fakeJSONarticle[0]; // TO BE REMOVED

    XHR.addEventListener("load", function () {
        let RES = XHR.response;
        function IsJsonString(RES) {
            try {
                JSON.parse(RES);
            } catch (e) {
                return errDisplayArticle(e);
            }
            var article = JSON.parse(RES);
            return displayArticle(article);
        }
    })

    XHR.addEventListener("progress", function () {
        contentLoading();
    })

    XHR.open("GET", link, true); //TRY FALSE CHECK first response 
    XHR.send(); //SEND ID
}