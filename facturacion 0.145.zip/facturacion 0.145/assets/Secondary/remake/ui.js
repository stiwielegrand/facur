let test = document.querySelector('#test');

function loading() {
    let animation = document.createElement('div');
    animation.className = "spinner";
    let spinners=[];
    for(let x=1; x<4; x++)
        {
            spinners[x] = document.createElement('div');
            spinners[x].className = "bounce"+x;
        }
        console.log(spinners);
    spinners.forEach(function(spinner){
        animation.appendChild(spinner);
    })
    document.documentElement.appendChild(animation)
}

loading()