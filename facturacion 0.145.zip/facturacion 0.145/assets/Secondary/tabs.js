let tabButton = document.querySelectorAll("[data-tabtrigger]");
tabButton.forEach(function(thisButton){
    let tab = thisButton.getAttribute('data-tabtrigger');
    thisButton.addEventListener('click', function() {expand(thisButton,tab)});
})
 function expand(tabButton, tab){
    // Declare all variables
    var i, tabcontent, tabchange;
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    // Get all elements with class="tablinks" and remove the class "active"
    tabchange = document.getElementsByClassName("tabchange");
    for (i = 0; i < tabchange.length; i++) {
        tabchange[i].className = tabchange[i].className.replace(" active", "");
    }
    // Show the current tab, and add an "active" class to the button that opened the tab
    let toBeVisible = document.querySelector('[data-container="'+tab+'"]');
    toBeVisible.style.display = "block";
    tabButton.className += " active";
}
document.querySelector("[data-tabtrigger=todos]").click();