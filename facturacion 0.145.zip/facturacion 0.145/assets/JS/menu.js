function XHR(argument) {
    // return "username";
    let XHR = new XMLHttpRequest();
    XHR.addEventListener("load", function () {
        if (argument == "username") {
            sessionStorage.setItem('username', XHR.response)
        }
        return XHR.response;
    })
    XHR.open("GET", "assets/PHP/info.php", true); //TRY FALSE CHECK WHAT LOADS
    XHR.send(argument); //SEND ID
}

let username = async function username() {
    let usernamevalue;
    if (localStorage.getItem('username') == undefined) {
        //return undefined;
        usernamevalue = await XHRrequester("assets/PHP/info.php", "username");
        if (usernamevalue != undefined)
        { CacheUser(usernamevalue) }
        else
        { usernamevalue = "usuario"; }
    } else {
        usernamevalue = localStorage.getItem('username');
        /*console.log("it is:" +usernamevalue )*/
    }
    Array.from(document.querySelectorAll("[class*='OPcurrentUsername']")).forEach(function (UNfield) {
        UNfield.innerHTML = usernamevalue;
    })

}()

let incoming = function incoming() {
    if (XHR("newmails") === undefined) {
        return "";
    }
    else {
        return XHR("newmails");
    }
    // return " ("+4+")"; 
}()


document.querySelector("[class*='OPnewMails']").innerHTML = incoming;