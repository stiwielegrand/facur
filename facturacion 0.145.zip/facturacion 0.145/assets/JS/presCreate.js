let UIaddbtn = document.querySelector('#UIadd'),
    container = document.querySelector('#inputcontainer'),
    individualContainer = document.querySelector('.quot'),
    firstDel = document.querySelector('#firstdel'),
    UIuds = document.getElementsByName('UIunidad[]'),
    UIcantidad = document.getElementsByName('UIcantidad[]'),
    UIprecio = document.getElementsByName('UIprecio[]'),
    UIsubTotalAll = document.getElementsByName('OPsubtotal[]'),
    UIivaPercent = document.getElementsByName('UIiva[]'),
    simpleIvaContainer = document.querySelector('#ivacontainer-simple'),
    complexIvaContainer = document.querySelector('#ivacontainer-complex'),
    OPtotal = document.querySelector('#OPtotal'),
    FULLtotal = document.querySelector('#FULLtotal'),
    UIid = document.getElementsByName('UIid[]'),
    UIivadisc = document.querySelector('#UIivadisc'),
    UIivaperc = document.querySelector('#UIivaperc'),
    OPoriginalcontainer = document.querySelector('#OPoriginalcontainer'),
    UIivaclose = document.querySelector('#UIivaclose'),
    UIivacalculator = document.querySelector('#UIivacalculator'),
    UIsubmit = document.querySelector('#uiSubmit'),
    uiname = document.querySelector('input[name="uiname"]'),
    uitlf = document.querySelector('input[name="uitlf"]'),
    uiDNI = document.querySelector('input[name="uiDNI"]'),
    uidir = document.querySelector('input[name="uidir"]'),
    uiemail = document.querySelector('input[name="uiemail"]'),
    uiother1 = document.querySelector('input[name="uiother1"]'),
    uidate = document.querySelector('input[name="uidate"]'),
    uiother2 = document.querySelector('input[name="uiother2"]'),
    uipresnum = document.querySelector('input[name="presnum"]'),
    uipresname = document.querySelector('input[name="uipresname"]'),
    simpleivaamount = document.querySelector('#simpleivaamount'),
    simpleivaprecent = document.querySelector('#simpleivaprecent'),
    complexivaamount = document.querySelector("#complexivatotal"),
    UIgoaddEmpty = document.querySelector('#UIgoaddEmpty'),
    UIdeletePres = document.querySelector('#UIdeletePres'),
    UserDataImport = document.querySelector("#UserDataImport"),
    prevPres = document.querySelector("#prevPres"),
    UIrejectCurrentCont = document.querySelector("#UIrejectCurrentCont"),
    UIivaContents = [];

// let userList = gatherData("userList");

// let PrevVersList = gatherData("prevVers");


includeNew(); evaluate(); ivacheck();
UIaddbtn.addEventListener('click', OPaddquot);
individualContainer.addEventListener('click', OPdelquot);
UIivadisc.addEventListener('change', ivadescount);
UIivaperc.addEventListener('change', ivadescount);
UIivadisc.addEventListener('keyup', ivadescount);
UIivaperc.addEventListener('keyup', ivadescount);
UIivacalculator.addEventListener('click', ivadescountclean);
UIsubmit.addEventListener('click', SubmitPres);
UIgoaddEmpty.addEventListener('click', function () {
    upload('temp');
})
UIdeletePres.addEventListener('click', function () {
    relocate();
})
UserDataImport.addEventListener('click', function () {
    gatherData("userList");
});
prevPres.addEventListener('click', function () {
    loadPrevs(null);
})
UIrejectCurrentCont.addEventListener('click', function () {
    edit(UIrejectCurrentCont.dataset.ID, UIrejectCurrentCont.dataset.vers);
})

document.querySelector('#forceCalc').addEventListener('click', function () {
    ivacheck(); subtotal(); evaluate();
})

if (localStorage.getItem('relocateArgument') != undefined) {
    console.log("relocate found")
    edit(localStorage.getItem('relocateArgumentID'));
    localStorage.removeItem('relocateArgument');
    localStorage.removeItem('relocateArgumentID');
    document.querySelector(".outside").innerHTML = "Editar Presupuesto";
}

function OPaddquot() {
    let OPbody = document.createElement('div');
    OPbody.className = 'row fpresupuesto';
    let OPprodContainer = document.createElement('div'),
        OPcantContainer = document.createElement('div'),
        OPudsContainer = document.createElement('div'),
        OPpriceContainer = document.createElement('div'),
        OPsubContainer = document.createElement('div'),
        OPivaContainer = document.createElement('div'),
        OPdelContainer = document.createElement('div'),
        OPcomsContainer = document.createElement('div'),
        OPUIid = document.createElement('input');
    OPprodContainer.className = 'input-field col s4';
    OPcantContainer.className = 'input-field col s1';
    OPudsContainer.className = 'input-field col s1';
    OPpriceContainer.className = 'input-field input-group col s2';
    OPsubContainer.className = 'input-field input-group col s2';
    OPivaContainer.className = 'input-field input-group col s1';
    OPdelContainer.className = 'input-field col s1';
    OPcomsContainer.className = 'row textareacontainer';
    OPUIid.className = 'uniqID';
    OPUIid.value = '';
    OPUIid.setAttribute('name', 'UIid[]');
    OPUIid.type = 'hidden';
    OPprodContainer.innerHTML += '<input type="text" class="input-field validate" placeholder="Producto" name="UIproductINP[]"><label for="fproducto" class="active">Producto</label></div>';
    OPcantContainer.innerHTML += '<input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" step="any" min="0" class="input-field validate nospinner" placeholder="Cantidad" name="UIcantidad[]"><label class="active" for="fcantidad">Cantidad</label>';
    OPudsContainer.innerHTML += '<input type="text" class="input-field validate UIunit" placeholder="Unidad" name="UIunidad[]" ><label class="active" for="funidad">Unidad</label>';
    OPpriceContainer.innerHTML += '<input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" step="any" min="0" class="input-field validate nospinner" placeholder="Precio/ud" name="UIprecio[]"><span class="suffix"><span class="badge badgefix" name="OPunit"></span></span><label for="fpunidad" class="active">Precio/ud</label>';
    OPsubContainer.innerHTML += '<input type="text" class="input-field validate" placeholder="Subtotal" readonly name="OPsubtotal[]"><span class="suffix"><span class="badge badgefix">€</span></span><label for="fsubtotal" class="active">Subtotal</label>';
    OPivaContainer.innerHTML += '<input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" step="any" min="0" class="input-field validate nospinner" value="21" name="UIiva[]"><span class="suffix" ><span class="badge badgefix">%</span></span><label for="fiva" class="active">IVA</label>';
    OPdelContainer.innerHTML += '<div class="input-field col s1"><a href="" class="btn redopt uidel"><i class="material-icons">delete_forever</i></a></div>';
    OPcomsContainer.innerHTML += '<div class="input-field col s11 UItextarea"><textarea class="materialize-textarea" name="UIcomsINP[]"></textarea><label for="textarea1">Comentario</label></div>';
    let OPelements = [OPUIid, OPprodContainer, OPcantContainer, OPudsContainer, OPpriceContainer, OPsubContainer, OPivaContainer, OPdelContainer, OPcomsContainer];
    for (var i = 0; i < OPelements.length; i++) {
        OPbody.appendChild(OPelements[i]);
    }
    container.appendChild(OPbody);
    //Refresh the variable pool
    includeNew();
    evaluate();
    ivacheck();
    OPprodContainer.firstChild.focus();


}
function includeNew() {
    let array = levelUp();
    for (let x = 0; x < array.length; x++) {
        array[x].unit.addEventListener('keyup', UIunitcheck);
        array[x].unit.addEventListener('input', UIunitcheck);
        array[x].cant.addEventListener('keyup', sumLinear);
        array[x].cant.addEventListener('input', sumLinear);
        array[x].cant.addEventListener('change', sumLinear);
        array[x].cant.addEventListener('paste', sumLinear);
        array[x].prperunit.addEventListener('keyup', sumLinear);
        array[x].prperunit.addEventListener('input', sumLinear);
        array[x].prperunit.addEventListener('change', sumLinear);
        array[x].subtotal.addEventListener('change', subtotal);
        array[x].subtotal.addEventListener('input', subtotal);
        //array[x].IVA.addEventListener('change', ivacheck);
        array[x].IVA.addEventListener('keyup', ivacheck);
        array[x].IVA.addEventListener('input', ivacheck);
        array[x].IVA.addEventListener('input', subtotal);
        array[x].IVA.addEventListener('keyup', subtotal);
    }
}
function OPdelquot(e) {
    e.preventDefault();
    let array = levelUp();
    let INPname = document.querySelector('#UIvalue');
    let BTNgodel = document.querySelector('#UIgodel');
    if (e.target.parentElement.classList.contains('uidel')) {
        let OPbodyTarget = e.target.parentElement.parentElement.parentElement.parentElement;
        if (e.target.parentElement.parentElement.parentElement.parentElement.childNodes[1].childNodes[0].value.length > 0) {
            INPname.innerHTML = e.target.parentElement.parentElement.parentElement.parentElement.childNodes[1].childNodes[0].value;
            $('#UIsure').modal('open');
            BTNgodel.onclick = function () {
                if (this.id == "UIgodel") {
                    proceedDel(OPbodyTarget);
                }
            }
        } else {
            proceedDel(OPbodyTarget);
        }
    }
    if (e.target.classList.contains('uidel')) {
        let OPbodyTarget = e.target.parentElement.parentElement.parentElement;
        if (e.target.parentElement.parentElement.parentElement.childNodes[1].childNodes[0].value.length > 0) {
            INPname.innerHTML = e.target.parentElement.parentElement.parentElement.childNodes[1].childNodes[0].value;
            $('#UIsure').modal('open');
            BTNgodel.onclick = function () {
                if (this.id == "UIgodel") {
                    proceedDel(OPbodyTarget);
                }
            }
        } else {
            proceedDel(OPbodyTarget);
        }
    }
}
function proceedDel(x) {
    x.remove();
    ivacheck();
    subtotal();
    evaluate();
}
function UIunitcheck() {
    let OPunit = this.parentElement.parentElement.querySelector('span[name="OPunit"]');
    let unit = this.value;
    if (this.value.length != 0) {
        OPunit.innerHTML = '€/' + unit;
    } else
        OPunit.innerHTML = '';
}
function evaluate() {
    for (let i = 0; i < UIid.length; i++) {
        UIid[i].value = i + 1;
    }
}
function sumLinear() {
    let calcCantidad = this.parentElement.parentElement.querySelector('input[name="UIcantidad[]"]');
    let calcPrecio = this.parentElement.parentElement.querySelector('input[name="UIprecio[]"]');
    let OPsubTotal = this.parentElement.parentElement.querySelector('input[name="OPsubtotal[]"]');
    if (calcCantidad.value && calcPrecio.value != 0) {
        OPsubTotal.value = toFixedTrunc(parseFloat(calcCantidad.value) * parseFloat(calcPrecio.value), 2);
        subtotal();
        ivacheck();
    }
    [calcCantidad, calcPrecio].forEach(function (element) {
        element.addEventListener('keyup', function () {
            if (this.value == "" || this.value == 0) {
                OPsubTotal.value = "";
                subtotal();
                ivacheck();
            }
        });
        element.addEventListener('change', function () {
            if (this.value == "" || this.value == 0) {
                OPsubTotal.value = "";
                subtotal();
                ivacheck();
            }
        });
    });
}

function sumLinearEdit() {
    let calcCantidad = document.querySelectorAll('input[name="UIcantidad[]"]');
    let calcPrecio = document.querySelectorAll('input[name="UIprecio[]"]');
    let OPsubTotal = document.querySelectorAll('input[name="OPsubtotal[]"]');
    let OPunits = document.querySelectorAll('span[name="OPunit"]');
    let units = document.querySelectorAll('input[name="UIunidad[]"]');
    for (let x = 0; x < calcCantidad.length; x++) {
        if (units[x].value.length != 0) {
            OPunits[x].innerHTML = '€/' + units[x].value;
        }
        else OPunits[x].innerHTML = '';
        if (calcCantidad[x].value && calcPrecio[x].value != 0) {
            OPsubTotal[x].value = toFixedTrunc(parseFloat(calcCantidad[x].value) * parseFloat(calcPrecio[x].value), 2);
            subtotal();
            ivacheck();
        }
    }
}
function subtotal() {
    let OPsubTotal = document.querySelectorAll('input[name="OPsubtotal[]"]');
    let total = [];
    for (let i = 0; i < OPsubTotal.length; i++) {
        let summand = (OPsubTotal[i].value);
        if (summand != "") {
            total.push(parseFloat(summand));
        } else {
            let total = [];
        }
    }
    if (total.length > 0) {
        ivacheck();
        let totalAmount = total.reduce(function (acc, val) {
            return acc + val;
        });
        OPtotal.innerHTML = toFixedTrunc(totalAmount, 2);
        console.log("-----------------------------simple Sum1:" + totalAmount + " Sum2:" + simpleivaamount.innerHTML)
        FULLtotal.innerHTML = toFixedTrunc(parseFloat(totalAmount) + parseFloat(simpleivaamount.innerHTML), 2);
    } else {
        OPtotal.innerHTML = "0.00";
        FULLtotal.innerHTML = "0.00";
    }
}

function levelUp(content) {
    let multiArticles = [];
    for (var x = 0; x < UIid.length; x++) {
        multiArticles[x] = {
            id: document.getElementsByName('UIid[]')[x],
            prod: document.getElementsByName('UIproductINP[]')[x],
            cant: document.getElementsByName('UIcantidad[]')[x],
            unit: document.getElementsByName('UIunidad[]')[x],
            prperunit: document.getElementsByName('UIprecio[]')[x],
            IVA: document.getElementsByName('UIiva[]')[x],
            coms: document.getElementsByName('UIcomsINP[]')[x],
            subtotal: document.getElementsByName('OPsubtotal[]')[x],
            parent: document.getElementsByName('OPsubtotal[]')[x].parentElement.parentElement
        };

    }
    return multiArticles;
}
function ivadescountclean() {
    let UIivadisc = document.querySelector('#UIivadisc');
    let UIivaperc = document.querySelector('#UIivaperc');
    UIivadisc.value = '';
    ivadescount(UIivadisc, UIivaperc);
}
function ivadescount(UIivadisc, UIivaperc) {
    if (UIivadisc != "" || UIivaperc != "") {
        let DESCfinal = parseFloat(document.querySelector('#UIivadisc').value);
        let DESCperc = parseFloat(document.querySelector('#UIivaperc').value);
        let original = DESCfinal / ((DESCperc / 100) + 1);
        OPoriginalcontainer.value = toFixedTrunc(original, 2);
    } else if (UIivadisc.value == "" || UIivaperc.value == "" || UIivaperc.value == NaN || UIivadisc.value == NaN) {
        OPoriginalcontainer.value = "";
    }
}
function toFixedTrunc(value, n) {
    const v = value.toString().split('.');
    if (n <= 0) return v[0];
    let f = v[1] || '';
    if (f.length > n) return `${v[0]}.${f.substr(0, n)}`;
    while (f.length < n) f += '0';
    return `${v[0]}.${f}`
}

function ivacheck() {
    let array = levelUp();
    //UIivaContents.every((val, i, arr) => val === arr[0]) IS THE SIMPLIFIED VERSION OF THIS
    let areAllivaEqual = array.every(function (currentValue, i, arr) {
        if (i === 0) {
            return true;
        } else {
            return (currentValue.IVA.value === arr[i - 1].IVA.value)
        }
    });
    if (areAllivaEqual == true) {
        //ALL IVA EQUAL
        complexIvaContainer.style.display = 'none';
        //        simpleIvaContainer.style.display = 'inline';
        simpleivaprecent.innerHTML = "IVA (" + array[0].IVA.value + "%)";
        let NUMivaOP = function () {
            var result = [];
            for (let i = 0; i < array.length; i++) {
                result.push((array[i].prperunit.value * array[i].cant.value) * (array[i].IVA.value / 100));
            };
            let output = result.reduce(function (sum, sumand) {
                return sum + sumand;
            })
            return output;
        };
        console.log(NUMivaOP());
        if (array[0].subtotal.value == "") {
            simpleivaamount.innerHTML = OPtotal.innerHTML;
        }
        else if (NUMivaOP() === 0) {
            console.log("trigg nulla")
            simpleivaamount.innerHTML = "0.00";
        } else {
            simpleivaamount.innerHTML = toFixedTrunc(NUMivaOP(), 2);
        }
    } else {
        //ALL IVA NOT EQUAL
        complexIvaContainer.style.display = 'inline';
        //        simpleIvaContainer.style.display = 'none';
        let NUMivaArrayOP = function () {
            var multipliers = [];
            for (let i = 0; i < array.length; i++) {
                multipliers.push(parseInt(array[i].IVA.value));
            };
            var diffMultipliers = multipliers.filter(function (item, p, self) {
                return self.indexOf(item) == p;
            });
            var multipliersRelative = [];
            for (var x = 0; x < diffMultipliers.length; x++) {
                multipliersRelative[x] = array.filter(function (item, position, self) {
                    return item.IVA.value == diffMultipliers[x];
                });
            }
            return [multipliersRelative, diffMultipliers];
        }
        let Fullstack = NUMivaArrayOP()[0];
        let multis = NUMivaArrayOP()[1];
        console.log(Fullstack);
        let IVAamountfilter = function (criteria) {
            let test = [];
            Fullstack.forEach(function (children) {
                children.forEach(function (prop) {
                    if (parseInt(prop.IVA.value) == criteria) {
                        if (prop.subtotal.value != "") {
                            test.push(parseInt(prop.subtotal.value) * criteria / 100);
                        }
                    }
                })
            })
            if (test.length > 0) {
                let individualVal = test.reduce(function (a, b) {
                    return a + b;
                });
                return toFixedTrunc(individualVal, 2);
            } else return "";
        }
        complexIvaContainer.innerHTML = "";
        for (let x = 0; x < multis.length; x++) {
            var ivaAmountIndividual;
            if (IVAamountfilter(NUMivaArrayOP()[1][x]) == "") {
                ivaAmountIndividual = "0.00";
            }
            else { ivaAmountIndividual = IVAamountfilter(NUMivaArrayOP()[1][x]); }
            complexIvaContainer.innerHTML += "<div class='col s7 ivacontainers'>IVA (" + (NUMivaArrayOP()[1])[x] + "%)</div><div class='col s5 input-group'><span class='complexivaamount'>" + ivaAmountIndividual + "</span> €</div>";
            console.log(IVAamountfilter(NUMivaArrayOP()[1][x]))
        }
        let complexivasfield = document.querySelectorAll(".complexivaamount");
        let complexivasfieldarr = Array.from(complexivasfield);
        let complexivas = complexivasfieldarr.map(function (val) {
            if (val.innerHTML != "") {
                return parseFloat(val.innerHTML);
            } else {
                return "";
            }
        })
        let complexivatotal = complexivas.reduce(function (a, b) {
            return a + b;
        })
        simpleivaprecent.innerHTML = "IVA TOTAL";
        if (complexivatotal != "") {
            simpleivaamount.innerHTML = toFixedTrunc(complexivatotal, 2);
        } else {
            //KEEP THIS UNDER CHECK it was ""
            simpleivaamount.innerHTML = "0.00";
        }
    }
}
function SubmitPres(e) {
    e.preventDefault;
    let fieldvalidation = function () {
        let count = 0;
        let anyempty = levelUp().forEach(function (field) {
            let tobechecked = [field.prod, field.cant, field.prperunit, field.IVA];
            tobechecked.forEach(function (val) {
                if (val.value == "") {
                    count++;
                    val.classList += " invalid";
                    console.log(val)
                }
            })
        })
        if (count != 0) {
            return false;
        } else {
            return true;
        }
    }
    if (uiname.value == "" || uiemail.value == "" || uitlf.value == "" || uiDNI.value == "" || uidate.value == "" || uipresname.value == "" || uidir.value == "" || fieldvalidation() == false) {
        console.log(fieldvalidation())
        let mandatory = [uiname, uiemail, uitlf, uiDNI, uipresname, uidir];
        for (let i = 0; i < mandatory.length; i++) {
            if (mandatory[i].value == "") {
                mandatory[i].classList += " invalid";
                console.log(mandatory[i]);
            } else if (mandatory[i].value != "") {
                mandatory[i].class = "input-field validate valid";
            }
        }
        if (uidate.value == "") {
            uidate.classList += " invalid";
        } else if (uidate.value != "") {
            uidate.classList = "input-field validate datepicker valid";
        }
        (function () {
            var alreadyExistingAlerts = document.querySelectorAll('[class*="slideOutAlert"]');
            console.log(alreadyExistingAlerts)
            if (alreadyExistingAlerts.length < 1) {
                let alertDIV = document.createElement('div');
                alertDIV.classList = " slideOutAlert col l12 ";
                alertDIV.innerHTML = '<span>Rellene los campos obligatorios.</span><a class="">Guardar en Borrador</a><span class="right"><a class="closeThisAlertbox"><i class="material-icons">close</i></a></span>';
                document.querySelector("#headerDetails").appendChild(alertDIV);
                setTimeout(function () {
                    $('[class*="slideOutAlert"]').fadeOut(1000);
                    setTimeout(function () {
                        $('[class*="slideOutAlert"]').remove();
                    }, 1000)
                }, 5000)
            }

        })()
    } else {
        upload();
    }
}
function upload(style) {
    console.log("runs");
    console.log(document.querySelector("#OPtotal").innerHTML)
    console.log(document.querySelector("#FULLtotal").innerHTML)
    console.log(document.querySelector("#simpleivaamount").innerHTML)
    let XHR = new XMLHttpRequest();
    let formData = new FormData(document.querySelector("#newPresupuesto"));

    var urlEncodedData = "";
    var urlEncodedDataPairs = [];
    urlEncodedDataPairs.push(...["SUBTOTAL=" + document.querySelector("#OPtotal").innerHTML, "GRANDTOTAL=" + document.querySelector("#FULLtotal").innerHTML, "IVA=" + document.querySelector("#simpleivaamount").innerHTML]);

    for (var pair of formData.entries()) {
        console.log(pair[0] + ', ' + pair[1]);
        urlEncodedDataPairs.push(pair[0] + '=' + pair[1]);
    }
    console.log(urlEncodedDataPairs)


    // Combine the pairs into a single string and replace all %-encoded spaces to 
    // the '+' character; matches the behaviour of browser form submissions.
    urlEncodedData = urlEncodedDataPairs.join('&').replace(/%20/g, '+');
    console.log(urlEncodedData);

    XHR.addEventListener("load", function (event) {
        // relocate();
        console.log(XHR.response);
    });

    XHR.addEventListener("error", function (event) {
        alert("Error!");
    });
    if (style == "temp") {
        XHR.open("POST", "assets/PHP/submit_pres.php?style=temp", true);
        XHR.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        XHR.send(urlEncodedData);
    }
    else {
        XHR.open("POST", "assets/PHP/submit_pres.php", true);
        XHR.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        XHR.send(urlEncodedData);
    }
}

function load(page) {
    if (page == null) page = 1;
    let clientDataList = document.querySelector("#clientDataList");
    let clientDataListFooter = document.querySelector('#clientDataListFooter');
    let userListToLoad = [];

    console.log(users, page)

    let articles = pagination("loadUsers", users, page)[0];
    let pages = pagination("loadUsers", users, page)[1];
    let contents = pagination("loadUsers", users, page)[2];

    console.log(articles)
    console.log(pages)
    console.log(contents)
    clientDataList.innerHTML = articles;
    clientDataListFooter.innerHTML = pages;
}

function pagination(target, list, page) {
    if (list == "") { /*(list == ""||list == undefined)*/
        return ["No se han encontrado elementos", "", ""];
    }
    else {
        let maxPages;
        if ((list.length % 10) == 0) maxPages = list.length / 10;
        else maxPages = Math.trunc((list.length / 10) + 1);
        let pageButtons = [];
        for (let x = 1; x <= maxPages; x++) {
            if (x != page) pageButtons.push('<li><a class="' + target + 'Pagination" href="#" data-page="' + x + '" data-target="' + target + '">' + x + '</a></li>');
            else pageButtons.push('<li class="active"><a>' + x + '</a></li>');

        }
        let clientListPagination =
            `<div class="modal-footer">
                <div class="row">
                    <div class="col s12 ">
                        <ul class="pagination center-align">
                        ${pageButtons.map(function (element) {
                return element;
            }).join('')}
                        </ul>
                    </div>
                </div>
            </div>`;

        let clientListcontent = function () {
            //FIRST
            if (page == 1) { list = list.slice(0, 10); }
            //LAST
            else if (maxPages == page) { list = list.slice((page * 10) - 10); }
            //MID
            else { list = list.slice(((page * 10) - 10), (page * 10)); }
            return list;
        }
        if (target == "loadUsers") {
            let clientList = `
            ${clientListcontent().map(function (collectionItems) {
                    return '<a href="#!" class="collection-item modal-close" data-action="clientDataFiller" data-id="' + collectionItems.ID + '">' + collectionItems.uiname + '</a>'
                }).join('')}`
            return [clientList, clientListPagination, clientListcontent()];
        }
        if (target == "prevVers") {
            let clientList = `
            ${clientListcontent().map(function (collectionItems) {
                    return '<a href="#" class="collection-item modal-close" data-action="prevEdit" data-id="' + collectionItems.ID + '" data-vers="' + collectionItems.vers + '">' + collectionItems.presname + ' (' + collectionItems.created + ')</a>'
                }).join('')}`
            return [clientList, clientListPagination, clientListcontent()];
        }
    }
}

function fillClientData(ID) {
    let CD = function retrieveData() {
        let JSONuser = users.filter(element => element.ID == ID);
        console.log(JSONuser);
        return JSONuser[0]; // TO BE REMOVED
    }
    uiname.value = CD().uiname;
    let CDphoneNo = CD().uitlf.match(/\d/g);
    CDphoneNo = CDphoneNo.join('');
    uitlf.value = CDphoneNo;
    uidir.value = CD().uidir;
    uiemail.value = CD().uiemail;
    uiDNI.value = CD().uiDNI;

    let mandatory = [uitlf, uidir, uiemail, uiDNI, uiname];
    for (let i = 0; i < mandatory.length; i++) {
        if (mandatory[i].value == "") {
            mandatory[i].classList += " invalid";
        }
        if (mandatory[i].value != "") {
            mandatory[i].classList = "input-field validate valid nospinner";
        }
    }
    if (uidate.value == "") {
        uidate.classList += " invalid";
    } else if (uidate.value != "") {
        uidate.classList = "input-field validate datepicker valid";
    }
}

function loadProgress() {
    let clientDataList = document.querySelector("#clientDataList");
    console.log("c loading progress")
    let animation =
        `<div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>`;

    clientDataList.innerHTML = "<div class='loadingDisplay'><h4>Cargando</h4><br><br>" + animation + "</div>";
    setTimeout(function () {
        // contentLoadingSucc(pass);
        /*        load(null)*/
        // contentLoaderr(pass);
    }, 2000);
}

function loadErr(err) {
    let clientDataList = document.querySelector("#clientDataList");


    let errMSG = "Ha ocurrido un error inesperado"
    if (err == "MSQROW0") {
        errMSG = "No se han encontrado resultados"
    }
    clientDataList.innerHTML = "<div class='loadingDisplay'><h4>" + errMSG + "</h4><textarea>" + err + "</textarea></div>";
}

function loadPrevs(page) {
    if (page == null) page = 1;
    let clientDataList = document.querySelector("#prevPresContainer");
    let clientDataListFooter = document.querySelector('#prevPresFooter');
    let userListToLoad = [];
    let articles = pagination("prevVers", PrevVersList, page)[0];
    let pages = pagination("prevVers", PrevVersList, page)[1];
    let contents = pagination("prevVers", PrevVersList, page)[2];
    clientDataList.innerHTML = articles;
    clientDataListFooter.innerHTML = pages;
}

function edit(ID, vers) {
    console.log(ID)
    console.log(vers)
    gatherData("userList");
    console.log(users)
    fillClientData(ID); //Should be Client ID  WILL BE THE IMPLEMENTED USER ID. PRES HEADER SHOULD ONLY CONTAIN THE USER ID // JOIN USER ID WITH USERS MSQ TABLE
    // var link = retriveScript+"?type=article&id="+ID;
    //MAKE ONLOAD AN ANIMATION 
    console.log(ID);
    var toEdit = Array.from(fakeJSON).filter(element => element.ID == ID)[0];
    uipresnum.value = toEdit.presnum;
    uipresname.value = toEdit.uipresname;
    container.innerHTML = "";

    toEdit.producto.forEach(function (iF) {
        editFields(iF.UIproduct, iF.UIcantidad, iF.UIunidad, iF.UIprecio, iF.UIiva, iF.UIcomsINP);
    })
    includeNew(); sumLinearEdit(); evaluate(); ivacheck();

    console.log(toEdit.producto)

    function editFields(product, cantidad, uds, precio, iva, coms) {
        let OPbody = document.createElement('div');
        OPbody.className = 'row fpresupuesto';
        let OPprodContainer = document.createElement('div'),
            OPcantContainer = document.createElement('div'),
            OPudsContainer = document.createElement('div'),
            OPpriceContainer = document.createElement('div'),
            OPsubContainer = document.createElement('div'),
            OPivaContainer = document.createElement('div'),
            OPdelContainer = document.createElement('div'),
            OPcomsContainer = document.createElement('div'),
            OPUIid = document.createElement('input');
        OPprodContainer.className = 'input-field col s4';
        OPcantContainer.className = 'input-field col s1';
        OPudsContainer.className = 'input-field col s1';
        OPpriceContainer.className = 'input-field input-group col s2';
        OPsubContainer.className = 'input-field input-group col s2';
        OPivaContainer.className = 'input-field input-group col s1';
        OPdelContainer.className = 'input-field col s1';
        OPcomsContainer.className = 'row textareacontainer';
        OPUIid.className = 'uniqID';
        OPUIid.value = '';
        OPUIid.setAttribute('name', 'UIid[]');
        OPUIid.type = 'hidden';
        OPprodContainer.innerHTML += '<input type="text" class="input-field validate" placeholder="Producto" name="UIproductINP[]" value="' + product + '"><label for="fproducto" class="active">Producto</label></div>';
        OPcantContainer.innerHTML += '<input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" step="any" min="0" class="input-field validate nospinner" placeholder="Cantidad" name="UIcantidad[]" value="' + cantidad + '"><label class="active" for="fcantidad">Cantidad</label>';
        OPudsContainer.innerHTML += '<input type="text" class="input-field validate UIunit" placeholder="Unidad" name="UIunidad[]" value="' + uds + '"><label class="active" for="funidad">Unidad</label>';
        OPpriceContainer.innerHTML += '<input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" step="any" min="0" class="input-field validate nospinner" placeholder="Precio/ud" name="UIprecio[]" value="' + precio + '"><span class="suffix"><span class="badge badgefix" name="OPunit"></span></span><label for="fpunidad" class="active">Precio/ud</label>';
        OPsubContainer.innerHTML += '<input type="text" class="input-field validate" placeholder="Subtotal" readonly name="OPsubtotal[]"><span class="suffix"><span class="badge badgefix">€</span></span><label for="fsubtotal" class="active">Subtotal</label>';
        OPivaContainer.innerHTML += '<input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" step="any" min="0" class="input-field validate nospinner" value="21" name="UIiva[]" value="' + iva + '"><span class="suffix" ><span class="badge badgefix">%</span></span><label for="fiva" class="active">IVA</label>';
        OPdelContainer.innerHTML += '<div class="input-field col s1"><a href="" class="btn redopt uidel"><i class="material-icons">delete_forever</i></a></div>';
        OPcomsContainer.innerHTML += '<div class="input-field col s11 UItextarea"><textarea class="materialize-textarea" name="UIcomsINP[]">' + coms + '</textarea><label for="textarea1">Comentario</label></div>';
        let OPelements = [OPUIid, OPprodContainer, OPcantContainer, OPudsContainer, OPpriceContainer, OPsubContainer, OPivaContainer, OPdelContainer, OPcomsContainer];
        //    Append
        for (var i = 0; i < OPelements.length; i++) {
            OPbody.appendChild(OPelements[i]);
        }
        container.appendChild(OPbody);
    }
}


var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
        if (!mutation.addedNodes) return;

        document.querySelectorAll('.closeThisAlertbox').forEach(function (closeBtn) {
            closeBtn.addEventListener('click', function () {
                closeBtn.parentElement.parentElement.fadeOut();
                //closeBtn.parentElement.parentElement.remove();
                /////////////////////////////////////////////// LEFT HERE
            })
        });

        Array.from(document.querySelectorAll("a[data-action='clientDataFiller']")).forEach(function (page) {
            page.addEventListener('click', function () {
                fillClientData(page.dataset.id);
            });
        });

        Array.from(document.querySelectorAll("a[data-action='prevEdit']")).forEach(function (version) {
            version.addEventListener('click', function () {
                let trigger = document.querySelector("#UIrejectCurrentCont");
                trigger.dataset.ID = version.dataset.id;
                trigger.dataset.vers = version.dataset.vers;
                setTimeout(function () {
                    $('#UIrejectCurrent').modal('open');
                }, 300)
            });
        });


        Array.from(document.querySelectorAll(".loadUsersPagination")).forEach(function (page) {
            page.addEventListener('click', function () {
                load(page.dataset.page);
            });
        });

        Array.from(document.querySelectorAll('.prevPresPagination')).forEach(function (page) {
            page.addEventListener('click', function () {
                loadPrevs(page.dataset.page);
            });
        });

        for (var i = 0; i < mutation.addedNodes.length; i++) {
            var node = mutation.addedNodes[i];
        }
    })
})

observer.observe(document.body, {
    childList: true
    , subtree: true
    , attributes: false
    , characterData: false
})

$(window).bind('click mouseup mousedown keydown keypress keyup submit change', idleUser);
var active = true,
    delay = 60000,
    timer = null;

function idleUser(e) {
    active = true;
    if (timer) clearTimeout(timer);
    timer = setTimeout(function (t) {
        active = false;
        console.log("idle")
    }, delay);
}