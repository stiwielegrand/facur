document.addEventListener('DOMContentLoaded', function () {
    var elems = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(elems, ({
        edge: 'left',
        preventScrolling: 'true',
        onOpenStart: function () {
            let current = document.querySelector("#slide-out");
            current.style.zIndex = 999;
            var doc = document.querySelector('html');
        }
    }));

    var elems = document.querySelectorAll('.rightcontent');
    var doc = document.querySelector('html');
    var instances = M.Sidenav.init(elems, ({
        edge: 'right',
        preventScrolling: 'false',
        inDuration: 500,
        outDuration: 700,
        onOpenStart: function () {
            doc.style.overflowY = 'hidden';
        },
        onCloseStart: function () {
            doc.style.overflowY = 'scroll';
            rightcontent.innerHTML = '';
        }
    }));

    //    var elems = document.querySelectorAll('.rightcontent');
    //    var doc = document.querySelector('html');
    //    var instances = M.Sidenav.init(elems, ({
    //        edge: 'right',
    //        preventScrolling: 'false',
    //        inDuration: 500,
    //        onOpenStart: function() {
    //            doc.style.overflowY = 'hidden';
    //        },
    //        onCloseStart: function() {
    //            doc.style.overflowY = 'scroll';
    //        }
    //    }));
    //
});

$(document).ready(function () {
    $('.dropdown-trigger').dropdown();
    $('select').formSelect({
        /*        dropdownOptions : {
                    isMultiple: true,
                    wrapper: $('#wrapper')
                }*/
    });
    $('.collapsible').collapsible({
        accordion: false
    });
    $('.tabs').tabs({ onShow: function (tab) { console.log(tab); sortingCriteria(); } });
    $('.datepicker').datepicker({
        autoClose: true,
        format: 'd-m-yyyy',
        firstDay: 1,
        i18n: {
            labelMonthSelect: 'Selecciona el mes',
            labelYearSelect: 'Selecciona el año',
            months: ['Enero', 'Febrero', 'Marzo', 'April', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
            monthsShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dic'],
            weekdaysFull: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
            weekdaysShort: ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'],
            weekdaysAbbrev: ['D', 'L', 'Ma', 'Mi', 'J', 'V', 'S'],
            today: 'Hoy',
            clear: 'Limpiar',
            cancel: 'Cancelar',
            done: 'Seleccionar'
        }
    });
    $('.tooltipped').tooltip();
    $('#REPO-modal').modal();
    $('.modal').modal();
    var test = {};
    Array.from(fakeJSON).forEach(function (element) {
        test[element.uiname] = null;
    })
    $('input.autocomplete').autocomplete({
        data: test,
        limit: 3
    });
});

function XHRrequester(server, request) {

    return new Promise(function (resolve, reject) {
        let XHR = new XMLHttpRequest();

        let link = server+"?info";

        XHR.addEventListener("load", function () {
            console.log("resolve")
            resolve(XHR.response)
        })
        XHR.addEventListener("error", function () {
            console.log("reject")
            resolve(undefined)
        })
        XHR.open("GET", link, true); 
        XHR.send(request); 

      /*  setTimeout(function(){
            resolve(undefined)
        },2000)*/
    })
}

function CacheUser(user) {
    localStorage.setItem('username', user)
} 

function relocate(place, argument, ID) {
    if (argument != undefined) {
        localStorage.setItem('relocateArgument', argument)
        localStorage.setItem('relocateArgumentID', ID)
    }
    var url = "presupuesto.html";
    if (place != null) url = place;
    window.location = url;
}

let toggleTriggerPres = document.querySelector('#toggleTrigger')
let toggleTargetPres = document.querySelector('#filter-toggle')
filterToggle(toggleTriggerPres, toggleTargetPres)

function filterToggle(trigger, content) {
    if (trigger != undefined) {
        trigger.addEventListener('click', function (e) {
            e.preventDefault();
            content.classList.toggle('filter-shown');
            trigger.classList.toggle('tiggered-filter');
        })
    }
}

var dateOptions = { month: 'long', day: 'numeric' };
// console.log(fullDate.toLocaleDateString('es-ES', dateOptions));

var users;
var prevs;
function gatherData(request) {

    let error = [];
    let XHR = new XMLHttpRequest();
    let retrieveLink = "assets/PHP/";
    let link;

    if (request == "userList") {
        link = retrieveLink + "asset_loader.php?type=retr&content=userlist";

        XHR.addEventListener("progress", function () {
            console.log("XHR loading!");
            loadProgress();
        })

        XHR.addEventListener("error", function () {
            console.log("XHR load Error!");
            let err = XHR.response;
            users = fakeJSONusers;
            loadErr(err);
        })

        XHR.addEventListener("load", function () {
            console.log("XHR loaded!");
            console.log(XHR.response);
            users = fakeJSONusers;
            load(null);
        })
    }

    else if (request == "provider") {
        link = retrieveLink + "asset_loader.php?type=retr&content=provider";

        XHR.addEventListener("progress", function () {
            console.log("XHR loading!");
            loadProgress();
        })

        XHR.addEventListener("error", function () {
            console.log("XHR load Error!");
            let err = XHR.response;
            users = fakeJSONusers;
            loadErr(err);
        })

        XHR.addEventListener("load", function () {
            console.log("XHR loaded!");
            console.log(XHR.response);
            users = fakeJSONusers;
            load(null);
        })
    }

    else if (request == "prevVers") {

    }

    XHR.open("GET", link, true); //TRY FALSE CHECK WHAT LOADS
    XHR.send(); //SEND ID
}

function settings(setting, type) {
    let XHR = new XMLHttpRequest();
    let retrieveLink = "assets/PHP/settings.php";
    let link;

    if (setting == "mailtxt") {
        link = retrieveLink + "?req=mailtxt&&for=" + type;
        // PRES or FACT

        XHR.addEventListener("error", function () {
            console.log("XHR load Error!");
            assignSend("");
            // assignSend(fakeSend);
        })

        XHR.addEventListener("load", function () {
            console.log("XHR loaded!");
            console.log(XHR.response);
            assignSend(XHR.response);
        })
    }
    XHR.open("GET", link, true); //TRY FALSE CHECK WHAT LOADS
    XHR.send(); //SEND ID
}

function assignSend(assign) {
    // $('#TextToSend').val(fakeSend);
    $('#TextToSend').val(assign);
    M.textareaAutoResize($('#TextToSend'));
}

var loadText = function () {
    return new Promise(function (resolve, reject) {
        let XHR = new XMLHttpRequest();

        let link = "php/settings.php?req=prestemp"

        XHR.addEventListener("load", function () {
            console.log("resolve")
            resolve(XHR.response)
        })
        XHR.addEventListener("error", function () {
            console.log("reject")
            resolve("")
        })
        XHR.open("GET", link, true); //TRY FALSE CHECK first response 
        XHR.send(); //SEND ID

    })
}

var loadCompData = function () {
    return new Promise(function (resolve, reject) {
        let XHR = new XMLHttpRequest();

        let link = "php/settings.php?re=compinfo"

        XHR.addEventListener("load", function () {
            console.log("resolve")
            if (XHR.response != false) {
                resolve(JSON.parse(XHR.response))
            }
            else {
                resolve(null);
            }
        })
        XHR.addEventListener("error", function () {
            console.log("reject")
            resolve(null)
        })
        XHR.open("GET", link, true);
        XHR.send(); //SEND ID
    })
}

const loader = async function (content) {

    var text = await loadText();

    var CompData = await loadCompData();

    await PrintElem(content, text, compdata);


}