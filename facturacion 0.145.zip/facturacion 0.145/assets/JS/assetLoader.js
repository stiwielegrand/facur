var contentLoadTriggers;
var pageChangeBtns;
var dateFrom = document.querySelector('input[name="presupuesto-from"]');
var dateTo = document.querySelector('input[name="presupuesto-to"]');
var critForUser = document.querySelector('input[name="presupuesto-foruser"]');
var filterTrigger = document.querySelector('[name="filtrar"]')
var stateFilter = document.querySelector('#state_filter');
var sortCrits = document.querySelectorAll('[class*="sortCrit"]');
var articleDisplay = document.querySelector("#articleDisplay");
//var preSort = sessionStorage.getItem("preSort");
var contentContainer = document.querySelector(".ContentView");
let entryHolder = document.querySelector('[class*="entryHolder"]');
var articleContainerPagination = document.querySelector("#articleContainerPagination");

let retriveScript, editScript;

if (LDR == F) {
    retriveScript = "assets/PHP/asset_loader.php?content=fact";
    editScript = "assets/PHP/edit.php?type=pres";
}
else if (LDR == P) {
    retriveScript = "assets/PHP/loader_pres.php?content=pres";
    editScript = "assets/PHP/edit.php?type=fact";
}

console.log(retriveScript)

dateFrom.value = TrimSelector(currMonth)[2];
dateTo.value = TrimSelector(currMonth)[3];

sorting();

function retrieveList(sorting, filter) {
    let link = retriveScript + "&type=sorting"
    if (sorting != null) {
        link += "&sorttype=" + sorting;
    }
    if (filter != null) {
        let i = 1;
        if (Array.isArray(filter) == false) {
            filter = filter.split(",");
        }
        filter.forEach(function (crit) {
            let char = i++;
            link += "&criteria" + char + "=" + crit;
        })
    }
    console.log(link)

    // return loading();  
    // return load(fakeJSON);    

    let XHR = new XMLHttpRequest();

    XHR.addEventListener("progress", loading)
    XHR.addEventListener("error", function () {
        //PROVISIONAL//
        loadsucc();
        return load(fakeJSON);
        // loaderr("Error durante la carga. Estado XHR: "+XHR.status+ "n Estado de timeout: "+XHR.timeout);
        console.log(XHR.status)
    })
    XHR.addEventListener("load", function () {
        console.log("loaded")
        let RES = XHR.response;
        console.log(RES)
        if (XHR.response.includes("MSQROW0") == true) {
            return loaderr("MSQROW0");
        } else {
            console.log("else");
            try {
                JSON.parse(RES);
                console.log("not catched")
            } catch (e) {
                console.log("Catch")
                return loaderr(RES);
            }
            console.log("works")
            let RESPONSE = JSON.parse(RES);
            console.log(RESPONSE)
            loadsucc();
            return load(RESPONSE);

        }
    })

    XHR.open("GET", link, true); //TRY FALSE CHECK WHAT LOADS
    XHR.send(); //SEND ID
}

function loading() {
    console.log("LOADING RUNNING")
    let animation =
        `<div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>`;


    entryHolder.style.display = '';
    articleDisplay.style.display = 'none';
    articleContainerPagination.style.display = 'none';
    contentContainer.innerHTML = "<div class='loadingDisplay'><h4>Cargando</h4><br><br>" + animation + "</div>";

}

function loadsucc() {
    console.log("LOADING ENDED")
    let entryHolder = document.querySelector('[class*="entryHolder"]');
    let articleDisplay = document.querySelector('#articleDisplay');
    entryHolder.style.display = '';
    articleDisplay.style.display = '';
    articleContainerPagination.style.display = '';
    let loadingDisplay = document.querySelector('.loadingDisplay');
    loadingDisplay.style.display = 'none';
}

function loaderr(err) {
    console.log("XHR load Error!");
    let errMSG = "Ha ocurrido un error inesperado"
    if (err == "MSQROW0") {
        errMSG = "No se han encontrado resultados"
    }
    entryHolder.style.display = 'none';
    contentContainer.innerHTML = "<div class='loadingDisplay'><h4>" + errMSG + "</h4><textarea>" + err + "</textarea></div>";
    contentContainer.innerHTML = "<div class='loadingDisplay'><h4>" + errMSG + "</h4><textarea>" + err + "</textarea></div>";
}

function retrieveArticles(ID) {

    let XHR = new XMLHttpRequest();

    let link = retriveScript + "&type=article&id=" + ID;
    //MAKE ONLOAD AN ANIMATION 
    console.log(ID);
    ID = ID.dataset.sidenavarticle;
    var fakeJSONarticle = Array.from(fakeJSON).filter(element => element.ID == ID);
    console.log(fakeJSONarticle)

    return contentLoading(fakeJSONarticle[0]); // TO BE REMOVED

    XHR.addEventListener("progress", contentLoading)
    XHR.addEventListener("error", contentloaderr)
    XHR.addEventListener("load", function () {
        let RES = XHR.response;
        function IsJsonString(RES) {
            try {
                JSON.parse(RES);
            } catch (e) {
                return contentLoaderr(RES);
            }
            var article = JSON.parse(RES);
            generateContent(article)
        }
    })
    XHR.open("GET", link, true); //TRY FALSE CHECK first response 
    XHR.send(); //SEND ID
}

function contentLoading(pass) {
    console.log("c loading progress")
    let animation =
        `<div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>`;

    rightcontent.innerHTML = "<div class='loadingDisplay'><h4>Cargando</h4><br><br>" + animation + "</div>";
    generateContent(pass)
}

/*function contentLoadingSucc(pass) {
    console.log(pass)
    ;
    setTimeout(function() {
    }, 2000);
}*/

function contentLoaderr(err) {
    console.log("XHR load Error!");
    let errMSG = "Ha ocurrido un error inesperado"
    if (err == "MSQROW0") {
        errMSG = "No se han encontrado resultados"
    }
    rightcontent.innerHTML = "<div class='loadingDisplay'><h4>" + errMSG + "</h4><textarea>" + err + "</textarea></div>";
}

var sort;
var allCriteria;
function sorting(sort, filter) {
    let smallDevFilter = document.querySelector("#state_sort")
    //SET DEFAULTS
    if (allCriteria == undefined) allCriteria = [TrimSelector(currMonth)[2], TrimSelector(currMonth)[3], "", ""];
    if (sort == undefined) sort = "name";

    //CHECK WHAT IS THE STATE OF SMALLDEV IN DEFAULT
    //if (smallDevFilter =! )
    sortCrits.forEach(function (crit) {
        crit.addEventListener('click', function () {
            sortCrits.forEach(function (rest) {
                rest.classList.remove('actual-selection');
            });
            crit.classList.add('actual-selection');
            sort = crit.dataset.sort;
            return retrieveList(sort, allCriteria);
        })
    })
    filterTrigger.addEventListener("click", function () {
        //MIGHT GIVE ERROR!! STATEFILTER.INDEX
        allCriteria = [dateFrom.value, dateTo.value, critForUser.value, stateFilter.value];
        //smallDevFilter.value MIGHT GIVE ERROR
        if (smallDevFilter != undefined) {
            sort = smallDevFilter.value;
        }
        console.log(smallDevFilter)
        return retrieveList(sort, allCriteria);
    })
    return retrieveList(sort, allCriteria);
}

function stateChange(oldState, newState, ID) {
    var abortChange;
    M.toast({
        html: 'Modificando Estado<button class="btn-flat toast-action ABORT">Deshacer</button>',
        completeCallback: function () {
            if (abortChange != 1) {
                stateChangeProceed(newState);
            }
        }
    })

    document.querySelector('button[class*=ABORT]').addEventListener("click", function () {
        abortChange = 1;
        console.log("aborted")
        M.Toast.getInstance(document.querySelector('.toast')).dismiss();
        document.querySelector("[data-stateChange='" + oldState + "']").selected = true;

        return false;
    })

    function stateChangeProceed(newState) {
        let XHR = new XMLHttpRequest();
        let link = editScript + "&edit=state&id=" + ID + "&newstate=" + newState;
        console.log(link);
        // return false; // TO BE REMOVED

        XHR.addEventListener("error", function () {

            M.toast({ html: 'Ha ocurrido un error!', classes: 'toastFail' });
            document.querySelector("[data-stateChange='" + oldState + "']").selected = true;
        })

        XHR.addEventListener("load", function () {
            if (XHR.response == 1) {
                M.toast({ html: 'Estado Modificado!', classes: 'toastSuccess' })
                sorting();
            }
            else {
                M.toast({ html: 'Ha ocurrido un error!', classes: 'toastFail' })
            }
        })
        XHR.open("GET", link, true); //TRY FALSE CHECK first response 
        XHR.send(); //SEND ID
    }

}

function load(results) {
    console.log(results)
    var pagination, contents, pagination, paginationOutput;
    articleDisplay = document.querySelector("#articleDisplay");
    if (results.length > 10) {
        pagination = function (page) {
            let pageNums = [];
            if (page === undefined) page = 1;
            var pages = Math.trunc(results.length / 10);
            var remainder = results.length % 10;
            if (remainder != 0) pages += 1;
            console.log(results)
            if (page != 1) {
                results1 = results.slice(((page - 1) * 10), (page * 10));
            } else results1 = results.slice(0, page * 10)
            console.log(results1)
            for (let x = 1; x <= pages; x++) {
                if (x != page) {
                    pageNums.push(`<li><a href="#${x}" class="pageChange" data-page="${x}">${x}</a></li>`);
                } else {
                    pageNums.push(`<li class="active"><a>${x}</a></li>`);
                };
            }
            console.log(pageNums)
            paginationOutput = `<div class="card-action center paginationStyle"><ul class="pagination">${pageNums.map(function (pageNum) {
                return `${pageNum}`;
            }).join('')}</ul></div>`
            articleContainerPagination = document.querySelector("#articleContainerPagination");
            articleContainerPagination.innerHTML = paginationOutput;

            Array.from(document.querySelectorAll('.pageChange')).forEach(function (pageChange) {
                pageChange.addEventListener('click', function () {
                    console.log(pageChange.dataset.page)
                    pagination(pageChange.dataset.page);
                    contents();
                    window.scrollTo({ top: 200, behavior: 'smooth' })
                })
            })
            return paginationOutput;
        }
        pagination();
        contents = function () {
            var articles = [];
            results1.forEach(function (result) {
                articles.push(generateArticles(result));
            })
            articleDisplay.innerHTML = "";
            articles.forEach(function (content) {
                console.log("runs")
                content = new DOMParser().parseFromString(content, 'text/html');
                content = content.body.firstChild;
                articleDisplay.appendChild(content);
            })
            triggerBind();
        }
        contents();
    } else {
        console.log("else")
        articleContainerPagination.innerHTML = "";
        contents = function () {
            var articles = [];
            results.forEach(function (result) {
                articles.push(generateArticles(result));
            })
            articleDisplay.innerHTML = "";
            articles.forEach(function (content) {
                console.log("runs")
                content = new DOMParser().parseFromString(content, 'text/html');
                content = content.body.firstChild;
                articleDisplay.appendChild(content);
            })
            triggerBind();
        }
        console.log(contents());
    }
}

function triggerBind() {
    var sidenavArticleTriggers = document.querySelectorAll('[data-sidenavArticle]');
    sidenavArticleTriggers.forEach(function (sTrigger) {
        sTrigger.addEventListener('click', function () {
            retrieveArticles(sTrigger);
        })
    })
}

function generateArticles(value) {
    if (value.status == 1) var currentState = "Pendiente";
    else if (value.status == 3) var currentState = "Aceptado";
    else if (value.status == 4) var currentState = "Facturado";
    else if (value.status == 2) var currentState = "Rechazado";
    else if (value.status == "?") var currentState = "Borrador";
    let Article;
    if (value.status != "?") {
        Article = `<li class="collection-item">
            <div class="row">
                <div class="col l1 m12 s6">${value.presnum}</div>
                <div class="col s6 show-on-small hide-on-med-and-up right-align">${value.uidate}</div>
                <div class="col l3 m12 articleTitle s12 truncate"><a href="#" class="sidenav-trigger" data-target="rightcontent" data-sidenavArticle="${value.ID}">${value.uipresname}</a></div>
                <div class="col m3 l2 hide-on-small-only">${value.uiname}</div>
                <div class="col m3 l2 hide-on-small-only">${value.uidate}</div>
                <div class="col m3 l2 s6">${value.GRANDTOTAL} €</div>
                <div class="col l2 m3 s6">${currentState}</div>
            </div>
        </li>`;
    }
    else {
        Article = `<li class="collection-item">
            <div class="row">
                <div class="col l1 m12 s6 borradorStyle">${value.presnum}</div>
                <div class="col s6 show-on-small hide-on-med-and-up right-align borradorStyle">${value.uidate}</div>
                <div class="col l3 m12 borradorStyle s12 truncate"><a href="#" class="sidenav-trigger" data-target="rightcontent" data-sidenavArticle="${value.ID}">${value.uipresname}</a></div>
                <div class="col m3 l2 hide-on-small-only borradorStyle">${value.uiname}</div>
                <div class="col m3 l2 hide-on-small-only borradorStyle">${value.uidate}</div>
                <div class="col m3 l2 s6 borradorStyle">${value.GRANDTOTAL} €</div>
                <div class="col l2 m3 s6 borradorStyle">${currentState}</div>
            </div>
        </li>`;
    }
    return Article;
}

//UI PROB IRRELEVANt

var stateFilterOps = document.querySelectorAll('[data-change]');
console.log(stateFilterOps)
stateFilterOps.forEach(function (stateFilterOp) {
    stateFilterOp.addEventListener('click', function () {
        stateFilter.innerHTML = stateFilterOp.innerText;
        stateFilter.dataset.state = stateFilterOp.dataset.change;
        console.log(stateFilter)
    })

})

function generateContent(LoadTrigger) {
    // let articleID = LoadTrigger.dataset.sidenavarticle; //ShouldContainTheID
    content = LoadTrigger;
    console.log("Content gen fired")
    /*if (content.connection == "success") {*/
    let other1 = (content.uiother1.length > 0) ? `
                    <div class="hide-on-small-only">
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Otros datos:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPother1">${content.uiother1}</span></div>
                    </div>
                    <div class="hide-on-med-and-up">
                    <div class="col s12 OPproductSubDetailsSmall OPproductSubTotals"><span class="highlight">Otros datos:</span> <span id="OPother1">${content.uiother1}</span></div></div>` : "";

    let other2 = (content.uiother2.length > 0) ? `
                    <div class="hide-on-small-only">
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Otros datos:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPother2">${content.uiother2}</span></div>
                    </div>
                    <div class="hide-on-med-and-up">
                    <div class="col s12 OPproductSubDetailsSmall OPproductSubTotals"><span class="highlight">Otros datos:</span> <span id="OPother1">${content.uiother1}</span></div></div>` : "";

    let ops = function (current) {
        let otherStates = [];
        if (current == 1) {
            var currentState = "<option data-stateChange='1'>Pendiente</option>";
        }
        else {
            otherStates.push("<option data-stateChange='1'>Pendiente</option>");
        }
        if (current == 3) {
            var currentState = "<option data-stateChange='3'>Aceptado</option>";
        }
        else {
            otherStates.push("<option data-stateChange='3'>Aceptado</option>");
        }
        if (current == 4) {
            var currentState = "<option data-stateChange='4'>Facturado</option>";
        }
        else {
            otherStates.push("<option data-stateChange='4'>Facturado</option>");
        }
        if (current == 2) {
            var currentState = "<option data-stateChange='2'>Rechazado</option>";
        }
        else {
            otherStates.push("<option data-stateChange='2'>Rechazado</option>");
        }

        let listOutput = [currentState];
        otherStates.forEach(function (otherState) {
            listOutput.push(otherState);
        })

        return listOutput;
    }

    function productArticles(productos) {
        return `
            ${content.producto.map(function (producto) {
                return `
                    <div class="row">
                        <div class="col m8 l8 OPproductDetails">${producto.UIproduct}</div>
                        <div class="col m4 l4 OPproductDetails right-align hide-on-small-only"><span class="badgeManual grey">${producto.UIcantidad + producto.UIunidad}</span>${producto.UIprecio} €</div>
                        <div class="col m8 l8 OPproductSubDetails">${producto.UIcomsINP}</div>
                        <div class="col m4 l4 OPproductSubDetails right-align hide-on-small-only">IVA ${producto.UIiva}%</div>
                        <div class="col s8 left hide-on-med-and-up"><span class="badgeManual badgeSmall grey">${producto.UIcantidad + producto.UIunidad}</span>  IVA ${producto.UIiva}%</div>
                        <div class="col s4 left hide-on-med-and-up highlight">${producto.UIprecio} €</div>
                    </div>`
            }).join('')}`
    }
    console.log(content)

    function headerControls() {
        let controls = `
                <div class="row center-align">
                    <div class="col s12 m2 l2 offset-m1 offset-l1">
                        <button class="waves-effect waves-red btn-flat modal-trigger" href="#SendTo" data-btnAction="1" data-ID="${content.ID}">Enviar</button>
                    </div>
                    <div class="col s12 m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat" data-btnAction="2" data-ID="${content.ID}"> PDF</button>
                    </div>
                    <div class="col s12 m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat hide-on-med-and-down" id="" onclick="loader(content)">Imprimir</button>
                    </div>
                    <div class="col s12 m2 l2">
                        <button class="waves-effect waves-isolatec btn-flat hide-on-small-only" data-btnAction="edit" data-ID="${content.ID}">Modificar</button>
                    </div>
                    
                    <div class="col s12 m3 l3">
                        
                        <div class="input-field col s12 m12 center-align">
                        <select class="browser-default selectHeightCorr center-align selectForm" id="stateChange">
                        ${ops(content.status)}
                        </select>
                        </div>
                    </div>
                </div>`

        let incomplete = `<div class="row center-align alertTxt">Borrador pendiente de <button class="waves-effect waves-isolatec btn-flat hide-on-small-only alertTxt" data-btnAction="edit" data-ID="${content.ID}">Finalizar</button></div>`

        if (content.status == "?") {
            return incomplete;
        }
        else {
            return controls;
        }
    }

    function date() {
        if (LDR == P) {
            return `<p id="OPitemSubValue">Presupostado el <span id="OPdate">${content.uidate}</span></p>`;
        }
        else {
            return `<p id="OPitemSubValue">Facturado el <span id="OPdate">${content.uidate}</span></p>`;
        }
    }
    rightcontent.innerHTML = `
                <div class="row articleheader z-depth-1">
                <div class="col m1 l1">
                    <a href="#" class="sidenav-close"><i class="material-icons articleHeaderIcon">clear</i></a>
                </div>
                <div class="col m11 l11 offset-l-1 offset-m-1 center-align hide-on-small-only ">
                    <p id="OPitemTitle">${content.uipresname}</p>
                </div>
            </div>
            <div class="articlecontent">
            ${headerControls()}
                <div class="row">
                    <div class="col s12 m12 l12 center-align OPitemValueContainer">
                        <h3>
                            <p id="OPitemValue">${content.GRANDTOTAL} €</p>
                        </h3>
                    </div>
                    <div class="col s12 m12 l12 center-align">
                        <h6>
                            ${date()}
                        </h6>
                    </div>

                    ${productArticles((content.producto))}
                    <div class="hide-on-small-only">
                    <div class="col l9 m9 right-align OPproductSubDetails OPproductSubTotals">SubTotal</div>
                    <div class="col l3 m3 right-align OPproductSubDetails OPproductSubTotals">${content.SUBTOTAL}€</div>
                    <div class="col l9 m9 right-align OPproductSubDetails OPproductSubTotals">IVA (${content.IVAtotalpercent}%)</div>
                    <div class="col l3 m3 right-align OPproductSubDetails OPproductSubTotals">${content.IVAtotalamount}€</div>
                    <div class="col l9 m9 right-align OPproductSubDetails highlight OPproductSubTotals">Total</div>
                    <div class="col l3 m3 right-align OPproductSubDetails highlight OPproductSubTotals">${content.GRANDTOTAL}€</div>
                    <div class="row btnpad">
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Cliente:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPname">${content.uiname}</span></div>
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">DNI:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPDNI">${content.uiDNI}</span></div>
                    <div class="col l3 m3 OPproductSubDetails OPproductSubTotals">Dirección:</div>
                    <div class="col l9 m9 OPproductSubDetails OPproductSubTotals"> <span id="OPdir">${content.uidir}</span></div> 
                        ${other1 + other2}
                    </div></div>
                    <div class="hide-on-med-and-up">
                    <div class="col s6 right-align OPproductSubDetailsSmall OPproductSubTotals">SubTotal</div>
                    <div class="col s6 right-align OPproductSubDetailsSmall OPproductSubTotals">${content.SUBTOTAL}€</div>
                    <div class="col s6 right-align OPproductSubDetailsSmall OPproductSubTotals">IVA (${content.IVAtotalpercent}%)</div>
                    <div class="col s6 right-align OPproductSubDetailsSmall OPproductSubTotals">${content.IVAtotalamount}€</div>
                    <div class="col s6 right-align OPproductSubDetailsSmall highlight OPproductSubTotals">Total</div>
                    <div class="col s6 right-align OPproductSubDetailsSmall highlight OPproductSubTotals">${content.GRANDTOTAL}€</div>
                    <div class="row btnpad ">

                    <div class="col s12 OPproductSubDetailsSmall OPproductSubTotals"><span class="highlight">Cliente:</span> <span id="OPname">${content.uiname}</span></div>
                    <div class="col s12 OPproductSubDetailsSmall OPproductSubTotals"><span class="highlight">DNI:</span> <span id="OPDNI">${content.uiDNI}</span></div>
                    <div class="col s12 OPproductSubDetailsSmall OPproductSubTotals"><span class="highlight">Dirección:</span> <span id="OPdir">${content.uidir}</span></div>
                        ${other1 + other2}
                    </div>
                    </div>
                </div>
            </div>`;
    console.log(content.GRANDTOTAL)
    animateDigits(OPitemValue, content.GRANDTOTAL, "€")
    document.querySelector(".sidenav-close").addEventListener("click", function (e) {
        e.preventDefault();
    })
    let COMMANDSend = document.querySelector("[data-btnAction='1']")

    COMMANDSend.addEventListener('click', function () {
        let SendTo = document.querySelector("input[name='SendTo']");
        let Username = document.querySelector("input[name='Username']");
        SendTo.value = content.uiemail;
        Username.value = content.uiname;

        console.log('checked')
        if (SendTo.value.length > 3) { SendTo.classList.add('valid'); SendTo.classList.remove('invalid') }
        else SendTo.classList.add('invalid')
        settings("mailtxt", "pres");

    })


    var editTriggers = document.querySelectorAll('[data-btnAction="edit"]');
    editTriggers.forEach(function (editTrigger) {
        editTrigger.addEventListener('click', function () {
            if (LDR == P) {
                relocate("crear_presupuesto.html", "edit", editTrigger.dataset.id)
            }
            else {
                relocate("crear_factura_part.html", "edit", editTrigger.dataset.id)
            }
        })
    })
    let PreValue;
    let COMMANDChange = document.querySelector("#stateChange")
    if (COMMANDChange) {
        COMMANDChange.addEventListener('focus', function () {
            PreValue = document.querySelector("#stateChange").options[document.querySelector("#stateChange").selectedIndex].dataset.statechange;
        })
    }
    let COMMANDStateChange = document.querySelector("#stateChange")
    if (COMMANDStateChange) {
        COMMANDStateChange.addEventListener('change', function () {
            stateChange(PreValue, document.querySelector("#stateChange").selectedOptions[0].dataset.statechange, content.ID);
        })
    }

    document.querySelector("button[class*=SendMsg]").addEventListener('click', function () {
        let sendTo = document.querySelector("input[name='SendTo']");
        let TextToSend = document.querySelector("[name='TextToSend']");
        let username = document.querySelector("[name='Username']");
        if (sendTo.value.length > 3) {
            sendTo.classList.remove('invalid')
            sendTo.classList.add('valid')
            console.log(username)
            send(sendTo.value, TextToSend.value, username.value, PDFprint())
        }
        else {
            sendTo.classList.add('invalid');
            console.log('inavlaid')
        }
    })

    let COMMANDPDF = document.querySelector("[data-btnAction='2']")
    if (COMMANDPDF) {
        COMMANDPDF.addEventListener('click', function () {
            PDF();
        })
    }

    /*    } else {
            rightcontent.innerHTML = `<div class='err-display center-align'>No se pudo mostrar el contenido!</div>
                                        <div class='center-align'>
                                        <div class='col s12 err-display-giant'>${content.err}</div>
                                        <div class='col'><textarea style="width:380px; resize:none;">${content.errmsg}</textarea></div>
                                        </div>`;
        }*/
}



function animateDigits(destinationID, valueTo, suffix) {
    let options = {
        useEasing: true,
        useGrouping: true,
        separator: '.',
        decimal: ',',
        suffix: suffix
    };
    var count = new CountUp(destinationID, 0, valueTo, 2, 1, options);
    if (!count.error) count.start();
}

function send(sendTo, TextToSend, sendToName, PDF) {
    M.toast({
        html: 'Enviando mensaje!',
        classes: 'sendToast'
    })
    // $('#SendTo').modal('close')
    console.log(sendTo, TextToSend, sendToName)

    let XHR = new XMLHttpRequest();
    XHR.addEventListener("load", function () {
        let RES = XHR.response;
        if (RES = "TRUE") {
            M.toast({
                html: 'Mensaje Enviado!',
                classes: 'toastSuccess'
            })
            $('#SendTo').modal('close')
        }
        else {
            M.toast({
                html: 'Ha ocurrido un error!',
                classes: 'toastFail'
            })
            console.log(RES)
        }
    })

    XHR.addEventListener("progress", function () {
        console.log("enviando")
    })

    XHR.addEventListener("error", function () {
        M.toast({
            html: 'Ha ocurrido un error!',
            classes: 'toastFail'
        })
        console.log("error")
    })

    XHR.open("POST", "php/send.php", true); //TRY FALSE CHECK first response 
    XHR.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    XHR.send('sendTo=' + sendTo + "&Text=" + TextToSend + "&sendToName=" + sendToName + "&PDF=" + PDF); //SEND ID
}

function PDF() {

    console.log(PDFprint())

    let XHR = new XMLHttpRequest();
    XHR.addEventListener("load", function () {
        let RES = XHR.response;

        if (RES == true) {
            M.toast({
                html: 'PDF creado!',
                classes: 'toastSuccess'
            })

        }
        else {
            M.toast({
                html: 'Ha ocurrido un error!',
                classes: 'toastFail'
            })
        }
        console.log(RES)
    })

    XHR.open("POST", "assets/PHP/pdf.php", true); //TRY FALSE CHECK first response 
    XHR.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    XHR.send('CORE=' + PDFprint());
}