document.addEventListener('load', loader);
document.documentElement.overflow ='hidden !important';
    function loader(){
        
        setTimeout(function() {
            document.querySelector('#UIloader').classList += ' loader-leave';
            document.querySelector('#body-contents ').style.display = 'block';
            
            
        },113000)
    }