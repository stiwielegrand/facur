let fakeSend = `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean finibus interdum orci sed molestie. Vivamus in suscipit risus. Ut commodo condimentum lectus sit amet semper. Etiam iaculis nec elit ac mattis. Nullam posuere ornare elit sit amet vestibulum. Etiam tempor vehicula odio, id pellentesque risus tincidunt ac. Phasellus nibh tortor, mollis nec hendrerit quis, aliquet in odio. Pellentesque odio nunc, efficitur in dapibus a, laoreet sit amet eros. Fusce aliquet metus arcu, et mollis augue venenatis eu.

Nam vel bibendum ante, quis posuere libero. Pellentesque cursus nibh nec metus volutpat tincidunt. Integer a massa nec arcu vulputate dapibus nec ut diam. Suspendisse justo nisl, tempor sit amet eros commodo, pretium suscipit nulla. Nulla facilisi. Vestibulum id lacus cursus, sollicitudin arcu non, scelerisque odio. Nullam vulputate diam eu porta luctus. In hac habitasse platea dictumst. Maecenas nec varius lacus. Nam eget volutpat magna, ac interdum augue.`;

let fakePrevArticles=[
  {
    "ID": 0,
    "presname": "nisi et ea dolor et aliqua",
    "vers": 2,
    "created": "2018-05-31"
  },
  {
    "ID": 1,
    "presname": "nulla anim excepteur in Lorem quis",
    "vers": 4,
    "created": "2018-01-09"
  },
  {
    "ID": 2,
    "presname": "nulla minim dolor ex eu ipsum",
    "vers": 3,
    "created": "2018-07-12"
  },
  {
    "ID": 3,
    "presname": "duis occaecat officia culpa aliquip commodo",
    "vers": 1,
    "created": "2018-02-01"
  },
  {
    "ID": 4,
    "presname": "incididunt irure tempor id fugiat velit",
    "vers": 1,
    "created": "2018-05-07"
  },
  {
    "ID": 5,
    "presname": "in dolor veniam commodo duis deserunt",
    "vers": 6,
    "created": "2018-02-09"
  },
  {
    "ID": 6,
    "presname": "nisi eu voluptate occaecat elit aute",
    "vers": 10,
    "created": "2018-06-01"
  },
  {
    "ID": 7,
    "presname": "consequat eiusmod velit occaecat adipisicing Lorem",
    "vers": 8,
    "created": "2018-02-25"
  }
]
// let fakeJSONusers=[];
let fakeJSONusers=[
  {
    "ID": 0,
    "uiname": "Holder Dean",
    "uitlf": "348225532571",
    "uiDNI": 525636,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 1,
    "uiname": "Knowles Cross",
    "uitlf": "+34 (898) 489-2199",
    "uiDNI": 376553,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 2,
    "uiname": "April Day",
    "uitlf": "+34 (869) 457-3494",
    "uiDNI": 166583,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 3,
    "uiname": "Mayer Marks",
    "uitlf": "+34 (973) 422-3225",
    "uiDNI": 258364,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 4,
    "uiname": "Vargas Willis",
    "uitlf": "+34 (915) 504-3331",
    "uiDNI": 356255,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 5,
    "uiname": "Stacie Dale",
    "uitlf": "+34 (820) 475-3355",
    "uiDNI": 611990,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 6,
    "uiname": "Janell Slater",
    "uitlf": "+34 (988) 463-2801",
    "uiDNI": 612933,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 7,
    "uiname": "Reeves Church",
    "uitlf": "+34 (866) 423-2761",
    "uiDNI": 98356,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 8,
    "uiname": "Cummings Snow",
    "uitlf": "+34 (836) 400-2962",
    "uiDNI": 240649,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 9,
    "uiname": "Rachelle Hale",
    "uitlf": "+34 (813) 514-3256",
    "uiDNI": 426696,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 10,
    "uiname": "Hubbard Cobb",
    "uitlf": "+34 (869) 405-3672",
    "uiDNI": 377233,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 11,
    "uiname": "Ruthie Oliver",
    "uitlf": "+34 (878) 429-2598",
    "uiDNI": 484753,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 12,
    "uiname": "Jeannie Schultz",
    "uitlf": "+34 (879) 417-3878",
    "uiDNI": 24535,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 13,
    "uiname": "Gertrude Woods",
    "uitlf": "+34 (855) 446-2896",
    "uiDNI": 46483,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 14,
    "uiname": "Bridget Byrd",
    "uitlf": "+34 (926) 595-2232",
    "uiDNI": 64248,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 15,
    "uiname": "Oneil Pennington",
    "uitlf": "+34 (877) 518-2868",
    "uiDNI": 231347,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 16,
    "uiname": "Glenna Meyers",
    "uitlf": "+34 (856) 483-3402",
    "uiDNI": 396471,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 17,
    "uiname": "Marianne Vargas",
    "uitlf": "+34 (808) 491-2601",
    "uiDNI": 301215,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 18,
    "uiname": "Nash Moon",
    "uitlf": "+34 (902) 540-2866",
    "uiDNI": 369776,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 19,
    "uiname": "Salas Langley",
    "uitlf": "+34 (942) 429-3489",
    "uiDNI": 52240,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 20,
    "uiname": "Peters Santiago",
    "uitlf": "+34 (902) 565-2345",
    "uiDNI": 24855,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 21,
    "uiname": "Jolene Morton",
    "uitlf": "+34 (999) 505-2064",
    "uiDNI": 528582,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 22,
    "uiname": "Haley Nash",
    "uitlf": "+34 (860) 416-3214",
    "uiDNI": 586667,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 23,
    "uiname": "Socorro Wilkinson",
    "uitlf": "+34 (935) 553-3172",
    "uiDNI": 68158,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 24,
    "uiname": "Wise Stafford",
    "uitlf": "+34 (956) 488-2679",
    "uiDNI": 36309,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 25,
    "uiname": "Coleman Waller",
    "uitlf": "+34 (878) 401-3979",
    "uiDNI": 207344,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 26,
    "uiname": "Britt Vincent",
    "uitlf": "+34 (840) 559-3480",
    "uiDNI": 537663,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 27,
    "uiname": "Lelia Fry",
    "uitlf": "+34 (862) 411-3321",
    "uiDNI": 541289,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 28,
    "uiname": "Rios Jones",
    "uitlf": "+34 (904) 513-3151",
    "uiDNI": 556226,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 29,
    "uiname": "Renee Wilson",
    "uitlf": "+34 (836) 453-3866",
    "uiDNI": 579210,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 30,
    "uiname": "Shannon Reyes",
    "uitlf": "+34 (819) 426-3727",
    "uiDNI": 284701,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 31,
    "uiname": "Leticia Gamble",
    "uitlf": "+34 (813) 425-3268",
    "uiDNI": 532507,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 32,
    "uiname": "Santiago Greene",
    "uitlf": "+34 (969) 555-3691",
    "uiDNI": 122822,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 33,
    "uiname": "Louise Cooke",
    "uitlf": "+34 (873) 417-3112",
    "uiDNI": 578126,
    "uidir": "Dirección",
    "uiemail": "Email"
  },
  {
    "ID": 34,
    "uiname": "Terri Powell",
    "uitlf": "+34 (953) 554-2051",
    "uiDNI": 305718,
    "uidir": "Dirección",
    "uiemail": "Email"
  }
]



let fakeJSON=[
  {
    "connection": "fail",
    "err": 404,
    "errmsg":"mensaje de error",
    "ID": 0,
    "uiname": "Moran Stevens",
    "uitlf": "+34 (891) 573-2763",
    "uiDNI": 112933,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "esse irure duis cillum sit tempor elit amet incididunt eiusmod excepteur eiusmod",
    "uiother2": "incididunt excepteur in qui fugiat tempor officia commodo ea proident ea esse",
    "presnum": "pres2304",
    "uipresname": "presupuestout laboris aliquip0",
    "uidate": "2015-05-03",
    "SUBTOTAL": 2239.064,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 3632.4052,
    "status": "?",
    "producto": [
      {
        "UIproduct": "dolore aliqua enim",
        "UIid": 20,
        "UIcantidad": 28,
        "UIunidad": "kg",
        "UIprecio": 206,
        "OPsubtotal": 1842,
        "UIiva": 21,
        "UIcomsINP": "magna minim duis nostrud ut non quis consectetur sint do eu mollit"
      },
      {
        "UIproduct": "aliquip duis adipisicing",
        "UIid": 20,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 911,
        "OPsubtotal": 203,
        "UIiva": 21,
        "UIcomsINP": "reprehenderit ut labore aliqua duis non aliquip non fugiat ea duis officia"
      },
      {
        "UIproduct": "non proident enim",
        "UIid": 20,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 857,
        "OPsubtotal": 1270,
        "UIiva": 21,
        "UIcomsINP": "veniam sint dolor commodo culpa dolore culpa ea exercitation sunt sint ea"
      },
      {
        "UIproduct": "laboris pariatur officia",
        "UIid": 37,
        "UIcantidad": 28,
        "UIunidad": "kg",
        "UIprecio": 150,
        "OPsubtotal": 1287,
        "UIiva": 21,
        "UIcomsINP": "tempor incididunt amet ullamco ad magna veniam eu consectetur sunt eiusmod non"
      },
      {
        "UIproduct": "labore Lorem proident",
        "UIid": 37,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 108,
        "OPsubtotal": 1184,
        "UIiva": 21,
        "UIcomsINP": "mollit ea laboris do est eiusmod sit cillum officia ullamco consequat do"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 1,
    "uiname": "Katherine Saunders",
    "uitlf": "+34 (922) 440-2772",
    "uiDNI": 92774,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "deserunt cupidatat non qui ullamco excepteur eu ullamco enim veniam fugiat excepteur",
    "uiother2": "aute irure elit irure nostrud nisi adipisicing nostrud aute officia tempor anim",
    "presnum": "pres1345",
    "uipresname": "presupuestovoluptate et consequat1",
    "uidate": "2017-02-02",
    "SUBTOTAL": 2237.6733,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4861.1994,
    "status": 3,
    "producto": [
      {
        "UIproduct": "labore commodo cillum",
        "UIid": 31,
        "UIcantidad": 26,
        "UIunidad": "kg",
        "UIprecio": 884,
        "OPsubtotal": 679,
        "UIiva": 21,
        "UIcomsINP": "tempor Lorem ad sit anim anim nulla ea dolore ipsum do do"
      },
      {
        "UIproduct": "esse dolor id",
        "UIid": 30,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 377,
        "OPsubtotal": 1941,
        "UIiva": 21,
        "UIcomsINP": "incididunt nostrud officia sunt ipsum id cillum reprehenderit duis do consequat cillum"
      },
      {
        "UIproduct": "dolore do cupidatat",
        "UIid": 23,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 276,
        "OPsubtotal": 929,
        "UIiva": 21,
        "UIcomsINP": "aute aliquip duis elit eu id dolor amet ipsum adipisicing minim deserunt"
      },
      {
        "UIproduct": "tempor aliquip consequat",
        "UIid": 20,
        "UIcantidad": 38,
        "UIunidad": "kg",
        "UIprecio": 113,
        "OPsubtotal": 739,
        "UIiva": 21,
        "UIcomsINP": "elit ipsum id eu irure proident qui magna est veniam magna dolore"
      },
      {
        "UIproduct": "et deserunt ipsum",
        "UIid": 24,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 107,
        "OPsubtotal": 1937,
        "UIiva": 21,
        "UIcomsINP": "nisi irure sint consectetur do Lorem et officia non adipisicing anim Lorem"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 2,
    "uiname": "Earline Burns",
    "uitlf": "+34 (889) 464-2771",
    "uiDNI": 191269,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "ea pariatur ullamco adipisicing quis nostrud veniam esse minim officia esse nulla",
    "uiother2": "et in incididunt est velit sunt qui elit magna do occaecat dolor",
    "presnum": "pres1313",
    "uipresname": "presupuestoduis occaecat consectetur2",
    "uidate": "2015-01-24",
    "SUBTOTAL": 1683.6027,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4375.8476,
    "status": 2,
    "producto": [
      {
        "UIproduct": "non ut ex",
        "UIid": 25,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 579,
        "OPsubtotal": 176,
        "UIiva": 21,
        "UIcomsINP": "tempor esse consectetur in exercitation aliqua eiusmod ex deserunt magna est cupidatat"
      },
      {
        "UIproduct": "quis officia ea",
        "UIid": 38,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 988,
        "OPsubtotal": 550,
        "UIiva": 21,
        "UIcomsINP": "velit ullamco qui dolor aliqua laboris esse minim do ut fugiat sint"
      },
      {
        "UIproduct": "laboris proident est",
        "UIid": 28,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 187,
        "OPsubtotal": 363,
        "UIiva": 21,
        "UIcomsINP": "culpa non qui consequat ullamco sit laboris ex labore dolore aute ipsum"
      },
      {
        "UIproduct": "pariatur cupidatat amet",
        "UIid": 36,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 168,
        "OPsubtotal": 1211,
        "UIiva": 21,
        "UIcomsINP": "id cupidatat Lorem ullamco voluptate velit qui excepteur Lorem fugiat in ea"
      },
      {
        "UIproduct": "aliquip est sunt",
        "UIid": 23,
        "UIcantidad": 32,
        "UIunidad": "kg",
        "UIprecio": 881,
        "OPsubtotal": 318,
        "UIiva": 21,
        "UIcomsINP": "deserunt velit tempor velit eiusmod non incididunt sunt reprehenderit est consectetur magna"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 3,
    "uiname": "Alisa Valenzuela",
    "uitlf": "+34 (930) 541-3619",
    "uiDNI": 233260,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "non id fugiat exercitation amet esse nisi veniam sit consectetur magna veniam",
    "uiother2": "aute aliquip laborum nulla ut ut Lorem ea irure pariatur laboris labore",
    "presnum": "pres2132",
    "uipresname": "presupuestoquis mollit do3",
    "uidate": "2015-11-20",
    "SUBTOTAL": 4108.7916,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1935.9555,
    "status": 2,
    "producto": [
      {
        "UIproduct": "eiusmod velit duis",
        "UIid": 20,
        "UIcantidad": 20,
        "UIunidad": "kg",
        "UIprecio": 652,
        "OPsubtotal": 1526,
        "UIiva": 21,
        "UIcomsINP": "officia laboris velit veniam culpa est adipisicing voluptate ut nisi dolore anim"
      },
      {
        "UIproduct": "laboris ea laborum",
        "UIid": 40,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 838,
        "OPsubtotal": 781,
        "UIiva": 21,
        "UIcomsINP": "ex ex consequat et consectetur aliquip proident est cupidatat velit tempor cillum"
      },
      {
        "UIproduct": "ea consequat enim",
        "UIid": 36,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 585,
        "OPsubtotal": 1438,
        "UIiva": 21,
        "UIcomsINP": "consequat nisi magna exercitation tempor irure eu nostrud deserunt dolor reprehenderit reprehenderit"
      },
      {
        "UIproduct": "aliqua ullamco laborum",
        "UIid": 22,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 582,
        "OPsubtotal": 847,
        "UIiva": 21,
        "UIcomsINP": "in culpa ea officia ut excepteur incididunt fugiat culpa proident est dolore"
      },
      {
        "UIproduct": "exercitation irure adipisicing",
        "UIid": 27,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 598,
        "OPsubtotal": 1477,
        "UIiva": 21,
        "UIcomsINP": "eu exercitation est quis quis esse consequat amet irure culpa aliqua ut"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 4,
    "uiname": "Boone Gross",
    "uitlf": "+34 (803) 539-2875",
    "uiDNI": 405273,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "exercitation ut commodo in eu minim deserunt veniam dolor consequat aute anim",
    "uiother2": "quis exercitation velit in laborum cillum cupidatat nostrud Lorem ex dolor cupidatat",
    "presnum": "pres1469",
    "uipresname": "presupuestoesse proident ex4",
    "uidate": "2014-02-16",
    "SUBTOTAL": 3575.6211,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 2740.28,
    "status": 1,
    "producto": [
      {
        "UIproduct": "officia sint occaecat",
        "UIid": 28,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 923,
        "OPsubtotal": 1865,
        "UIiva": 21,
        "UIcomsINP": "velit occaecat excepteur velit consequat id fugiat laborum qui sunt cillum proident"
      },
      {
        "UIproduct": "adipisicing fugiat in",
        "UIid": 33,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 805,
        "OPsubtotal": 1779,
        "UIiva": 21,
        "UIcomsINP": "velit aliqua aliquip est labore culpa quis excepteur esse pariatur sint ad"
      },
      {
        "UIproduct": "incididunt minim incididunt",
        "UIid": 35,
        "UIcantidad": 36,
        "UIunidad": "kg",
        "UIprecio": 810,
        "OPsubtotal": 1221,
        "UIiva": 21,
        "UIcomsINP": "in exercitation duis consequat voluptate quis mollit mollit officia labore duis enim"
      },
      {
        "UIproduct": "duis sit sit",
        "UIid": 21,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 997,
        "OPsubtotal": 1350,
        "UIiva": 21,
        "UIcomsINP": "minim nisi sunt ullamco ut Lorem incididunt cillum est deserunt do amet"
      },
      {
        "UIproduct": "do enim tempor",
        "UIid": 33,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 388,
        "OPsubtotal": 141,
        "UIiva": 21,
        "UIcomsINP": "ea esse labore consectetur laborum adipisicing eu nostrud eiusmod anim veniam deserunt"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 5,
    "uiname": "Freida Holder",
    "uitlf": "+34 (819) 568-2267",
    "uiDNI": 135869,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "consectetur adipisicing adipisicing ipsum ipsum esse in laboris sunt magna qui nisi",
    "uiother2": "enim qui Lorem reprehenderit esse nulla pariatur magna enim eu qui officia",
    "presnum": "pres2158",
    "uipresname": "presupuestoenim laborum consectetur5",
    "uidate": "2015-08-15",
    "SUBTOTAL": 3788.252,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4660.4645,
    "status": 1,
    "producto": [
      {
        "UIproduct": "ut esse eiusmod",
        "UIid": 27,
        "UIcantidad": 28,
        "UIunidad": "kg",
        "UIprecio": 780,
        "OPsubtotal": 1762,
        "UIiva": 21,
        "UIcomsINP": "aliquip incididunt voluptate dolor deserunt aute officia magna veniam id reprehenderit ad"
      },
      {
        "UIproduct": "sint eiusmod ea",
        "UIid": 28,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 582,
        "OPsubtotal": 1234,
        "UIiva": 21,
        "UIcomsINP": "ut commodo duis Lorem laboris enim tempor occaecat quis magna mollit ut"
      },
      {
        "UIproduct": "laborum ut quis",
        "UIid": 26,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 235,
        "OPsubtotal": 1911,
        "UIiva": 21,
        "UIcomsINP": "pariatur velit Lorem laborum dolor nostrud consequat fugiat incididunt cillum eiusmod id"
      },
      {
        "UIproduct": "nostrud esse enim",
        "UIid": 20,
        "UIcantidad": 26,
        "UIunidad": "kg",
        "UIprecio": 259,
        "OPsubtotal": 1973,
        "UIiva": 21,
        "UIcomsINP": "do tempor adipisicing ea sint cupidatat occaecat sunt dolor reprehenderit et exercitation"
      },
      {
        "UIproduct": "est amet deserunt",
        "UIid": 21,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 130,
        "OPsubtotal": 1580,
        "UIiva": 21,
        "UIcomsINP": "laborum id consectetur ipsum irure eu duis incididunt velit dolore aute ex"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 6,
    "uiname": "Bettye Randall",
    "uitlf": "+34 (856) 452-3698",
    "uiDNI": 232866,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "dolor sit qui tempor do mollit occaecat laboris est ex do commodo",
    "uiother2": "in fugiat laboris minim eu consectetur Lorem laboris ex sint voluptate consectetur",
    "presnum": "pres1237",
    "uipresname": "presupuestovelit pariatur pariatur6",
    "uidate": "2017-08-08",
    "SUBTOTAL": 4099.4559,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 737.1915,
    "status": 3,
    "producto": [
      {
        "UIproduct": "aliquip ipsum cillum",
        "UIid": 31,
        "UIcantidad": 37,
        "UIunidad": "kg",
        "UIprecio": 806,
        "OPsubtotal": 958,
        "UIiva": 21,
        "UIcomsINP": "dolore excepteur eiusmod deserunt amet deserunt enim aliqua eiusmod et non laborum"
      },
      {
        "UIproduct": "pariatur amet eiusmod",
        "UIid": 30,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 660,
        "OPsubtotal": 489,
        "UIiva": 21,
        "UIcomsINP": "dolor qui ad occaecat laboris pariatur id et sunt occaecat aute reprehenderit"
      },
      {
        "UIproduct": "est laborum voluptate",
        "UIid": 27,
        "UIcantidad": 37,
        "UIunidad": "kg",
        "UIprecio": 838,
        "OPsubtotal": 1876,
        "UIiva": 21,
        "UIcomsINP": "pariatur commodo do incididunt officia exercitation non consectetur irure sunt veniam anim"
      },
      {
        "UIproduct": "aliqua eu adipisicing",
        "UIid": 36,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 320,
        "OPsubtotal": 1817,
        "UIiva": 21,
        "UIcomsINP": "fugiat ad ex amet culpa esse exercitation aute ullamco dolore labore ut"
      },
      {
        "UIproduct": "laborum sunt minim",
        "UIid": 35,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 364,
        "OPsubtotal": 821,
        "UIiva": 21,
        "UIcomsINP": "voluptate adipisicing dolor qui ullamco in voluptate mollit incididunt enim anim reprehenderit"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 7,
    "uiname": "Gilbert Rodriquez",
    "uitlf": "+34 (817) 413-3808",
    "uiDNI": 352833,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "ut elit id Lorem pariatur duis nulla irure eiusmod ut ea enim",
    "uiother2": "laboris occaecat magna adipisicing incididunt amet qui do labore amet incididunt sunt",
    "presnum": "pres1919",
    "uipresname": "presupuestoLorem ut sit7",
    "uidate": "2016-09-15",
    "SUBTOTAL": 1532.4881,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4071.9964,
    "status": 2,
    "producto": [
      {
        "UIproduct": "occaecat est sunt",
        "UIid": 21,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 805,
        "OPsubtotal": 657,
        "UIiva": 21,
        "UIcomsINP": "ea sint ipsum ea id eu laboris incididunt amet pariatur pariatur excepteur"
      },
      {
        "UIproduct": "consectetur pariatur irure",
        "UIid": 32,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 211,
        "OPsubtotal": 221,
        "UIiva": 21,
        "UIcomsINP": "dolore Lorem cillum dolore esse esse dolor magna enim ullamco sint duis"
      },
      {
        "UIproduct": "eu ut aute",
        "UIid": 32,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 366,
        "OPsubtotal": 383,
        "UIiva": 21,
        "UIcomsINP": "tempor laboris culpa veniam ea proident sit aute cillum Lorem do cillum"
      },
      {
        "UIproduct": "nostrud dolore consequat",
        "UIid": 22,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 390,
        "OPsubtotal": 155,
        "UIiva": 21,
        "UIcomsINP": "in commodo ad laborum proident commodo deserunt labore in officia sunt dolore"
      },
      {
        "UIproduct": "duis occaecat anim",
        "UIid": 24,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 560,
        "OPsubtotal": 992,
        "UIiva": 21,
        "UIcomsINP": "in ea reprehenderit duis proident mollit esse ipsum minim sit minim sint"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 8,
    "uiname": "Katharine White",
    "uitlf": "+34 (819) 402-3480",
    "uiDNI": 418997,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "excepteur voluptate voluptate ullamco culpa enim esse nulla id labore labore qui",
    "uiother2": "qui do fugiat non aliqua proident veniam amet laboris laborum amet consequat",
    "presnum": "pres2491",
    "uipresname": "presupuestoaliqua excepteur consectetur8",
    "uidate": "2017-08-02",
    "SUBTOTAL": 4658.823,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 158.6724,
    "status": 2,
    "producto": [
      {
        "UIproduct": "occaecat exercitation Lorem",
        "UIid": 29,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 790,
        "OPsubtotal": 143,
        "UIiva": 21,
        "UIcomsINP": "eiusmod veniam occaecat enim eiusmod adipisicing excepteur tempor enim aliqua tempor non"
      },
      {
        "UIproduct": "excepteur est nostrud",
        "UIid": 37,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 122,
        "OPsubtotal": 1279,
        "UIiva": 21,
        "UIcomsINP": "quis officia officia quis incididunt consequat aliqua aliqua in ullamco est nulla"
      },
      {
        "UIproduct": "ad aliqua exercitation",
        "UIid": 21,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 203,
        "OPsubtotal": 593,
        "UIiva": 21,
        "UIcomsINP": "cupidatat consequat duis Lorem ad do incididunt laboris ullamco eu id labore"
      },
      {
        "UIproduct": "sunt nulla consequat",
        "UIid": 28,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 557,
        "OPsubtotal": 278,
        "UIiva": 21,
        "UIcomsINP": "fugiat ad incididunt ullamco adipisicing mollit anim ipsum nostrud consectetur est qui"
      },
      {
        "UIproduct": "deserunt sunt nulla",
        "UIid": 24,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 641,
        "OPsubtotal": 1258,
        "UIiva": 21,
        "UIcomsINP": "minim id reprehenderit pariatur adipisicing enim nostrud magna ad in reprehenderit Lorem"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 9,
    "uiname": "Hope Casey",
    "uitlf": "+34 (990) 467-2446",
    "uiDNI": 89493,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "tempor amet laborum adipisicing occaecat sunt labore mollit qui ex magna id",
    "uiother2": "culpa laboris nisi velit ut in aliquip dolor mollit nulla anim sit",
    "presnum": "pres2186",
    "uipresname": "presupuestoduis commodo voluptate9",
    "uidate": "2016-06-18",
    "SUBTOTAL": 2062.0952,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 3545.2187,
    "status": 1,
    "producto": [
      {
        "UIproduct": "excepteur ut duis",
        "UIid": 29,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 776,
        "OPsubtotal": 578,
        "UIiva": 21,
        "UIcomsINP": "consectetur ut in Lorem laborum id eiusmod eiusmod magna exercitation elit excepteur"
      },
      {
        "UIproduct": "nisi tempor veniam",
        "UIid": 27,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 502,
        "OPsubtotal": 1496,
        "UIiva": 21,
        "UIcomsINP": "qui laborum consectetur ad anim dolor amet cupidatat deserunt sint fugiat proident"
      },
      {
        "UIproduct": "non adipisicing irure",
        "UIid": 35,
        "UIcantidad": 36,
        "UIunidad": "kg",
        "UIprecio": 263,
        "OPsubtotal": 1215,
        "UIiva": 21,
        "UIcomsINP": "irure elit sunt enim aliqua veniam dolore labore velit aliquip nulla cillum"
      },
      {
        "UIproduct": "cupidatat aliqua ad",
        "UIid": 34,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 211,
        "OPsubtotal": 523,
        "UIiva": 21,
        "UIcomsINP": "nostrud dolore non amet deserunt eiusmod quis fugiat elit elit culpa duis"
      },
      {
        "UIproduct": "duis enim ad",
        "UIid": 29,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 427,
        "OPsubtotal": 962,
        "UIiva": 21,
        "UIcomsINP": "do elit sint labore nisi officia quis veniam irure amet amet adipisicing"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 10,
    "uiname": "Garza Sanford",
    "uitlf": "+34 (850) 437-3898",
    "uiDNI": 417334,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "non officia anim minim amet sunt consequat do et officia commodo fugiat",
    "uiother2": "esse id cupidatat eu magna occaecat pariatur velit in sunt et qui",
    "presnum": "pres2285",
    "uipresname": "presupuestonulla sit enim10",
    "uidate": "2017-10-25",
    "SUBTOTAL": 3043.205,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1903.4272,
    "status": 1,
    "producto": [
      {
        "UIproduct": "consequat qui dolore",
        "UIid": 35,
        "UIcantidad": 37,
        "UIunidad": "kg",
        "UIprecio": 414,
        "OPsubtotal": 1626,
        "UIiva": 21,
        "UIcomsINP": "excepteur laboris do occaecat eiusmod enim veniam aliquip anim sint minim ipsum"
      },
      {
        "UIproduct": "id dolor sit",
        "UIid": 25,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 791,
        "OPsubtotal": 1955,
        "UIiva": 21,
        "UIcomsINP": "culpa Lorem qui elit ex incididunt eu commodo do cillum anim sint"
      },
      {
        "UIproduct": "non deserunt cillum",
        "UIid": 36,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 708,
        "OPsubtotal": 1679,
        "UIiva": 21,
        "UIcomsINP": "duis ipsum id culpa officia ad nostrud velit esse eu deserunt aliqua"
      },
      {
        "UIproduct": "nostrud dolor veniam",
        "UIid": 31,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 713,
        "OPsubtotal": 1645,
        "UIiva": 21,
        "UIcomsINP": "officia enim nostrud ullamco ex non eu nostrud nisi in pariatur dolore"
      },
      {
        "UIproduct": "velit et Lorem",
        "UIid": 31,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 331,
        "OPsubtotal": 238,
        "UIiva": 21,
        "UIcomsINP": "occaecat amet voluptate amet Lorem velit velit ipsum cillum est eu enim"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 11,
    "uiname": "Summer Meyer",
    "uitlf": "+34 (808) 506-2475",
    "uiDNI": 387039,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "aute sunt incididunt eu velit ipsum laboris commodo non nisi mollit veniam",
    "uiother2": "ipsum tempor labore elit deserunt eiusmod in ea consequat duis nisi aute",
    "presnum": "pres2341",
    "uipresname": "presupuestoduis adipisicing et11",
    "uidate": "2015-02-24",
    "SUBTOTAL": 2504.7065,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 3125.1578,
    "status": 3,
    "producto": [
      {
        "UIproduct": "laboris minim aliqua",
        "UIid": 31,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 842,
        "OPsubtotal": 1606,
        "UIiva": 21,
        "UIcomsINP": "labore et tempor consectetur do esse officia elit ea minim ipsum ex"
      },
      {
        "UIproduct": "id laboris consectetur",
        "UIid": 23,
        "UIcantidad": 32,
        "UIunidad": "kg",
        "UIprecio": 287,
        "OPsubtotal": 148,
        "UIiva": 21,
        "UIcomsINP": "enim quis enim sit commodo enim amet quis non est commodo deserunt"
      },
      {
        "UIproduct": "anim eiusmod adipisicing",
        "UIid": 36,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 835,
        "OPsubtotal": 1733,
        "UIiva": 21,
        "UIcomsINP": "eiusmod in velit consequat culpa non commodo dolore commodo deserunt mollit quis"
      },
      {
        "UIproduct": "amet aliqua mollit",
        "UIid": 28,
        "UIcantidad": 32,
        "UIunidad": "kg",
        "UIprecio": 522,
        "OPsubtotal": 1101,
        "UIiva": 21,
        "UIcomsINP": "laborum aliquip dolor nisi deserunt laborum tempor Lorem mollit nulla culpa laborum"
      },
      {
        "UIproduct": "in eiusmod culpa",
        "UIid": 36,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 130,
        "OPsubtotal": 983,
        "UIiva": 21,
        "UIcomsINP": "dolor ex dolore ad sunt voluptate magna commodo commodo non id sint"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 12,
    "uiname": "Rosalie Edwards",
    "uitlf": "+34 (860) 441-3775",
    "uiDNI": 584039,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "aliquip incididunt in laborum nulla esse veniam nulla laborum ea aliquip ullamco",
    "uiother2": "est ad aliquip sit reprehenderit aliqua pariatur minim esse elit amet laboris",
    "presnum": "pres1995",
    "uipresname": "presupuestoanim voluptate sit12",
    "uidate": "2016-07-07",
    "SUBTOTAL": 3113.3354,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4424.7001,
    "status": 1,
    "producto": [
      {
        "UIproduct": "fugiat ullamco sint",
        "UIid": 36,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 598,
        "OPsubtotal": 679,
        "UIiva": 21,
        "UIcomsINP": "laboris reprehenderit laborum tempor tempor cupidatat quis aute nulla enim laborum qui"
      },
      {
        "UIproduct": "dolor nostrud exercitation",
        "UIid": 37,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 151,
        "OPsubtotal": 108,
        "UIiva": 21,
        "UIcomsINP": "nulla aliquip cupidatat cillum mollit mollit mollit irure dolor occaecat nulla minim"
      },
      {
        "UIproduct": "incididunt occaecat ipsum",
        "UIid": 35,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 979,
        "OPsubtotal": 1596,
        "UIiva": 21,
        "UIcomsINP": "elit velit sunt Lorem in ea laboris in labore tempor do magna"
      },
      {
        "UIproduct": "ullamco sunt dolore",
        "UIid": 25,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 153,
        "OPsubtotal": 1666,
        "UIiva": 21,
        "UIcomsINP": "adipisicing proident esse tempor elit ut dolor nisi ullamco ut non ex"
      },
      {
        "UIproduct": "et elit amet",
        "UIid": 26,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 658,
        "OPsubtotal": 1628,
        "UIiva": 21,
        "UIcomsINP": "mollit ad reprehenderit sunt tempor labore veniam ullamco commodo ipsum velit ipsum"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 13,
    "uiname": "Benton Kidd",
    "uitlf": "+34 (989) 545-2167",
    "uiDNI": 506379,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "sunt ea reprehenderit mollit irure do exercitation dolore incididunt nulla nulla sit",
    "uiother2": "tempor magna dolore amet ut occaecat laborum consequat ad ad et id",
    "presnum": "pres1374",
    "uipresname": "presupuestoest aute mollit13",
    "uidate": "2018-06-29",
    "SUBTOTAL": 2041.1887,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 740.7394,
    "status": 2,
    "producto": [
      {
        "UIproduct": "ex velit nostrud",
        "UIid": 26,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 390,
        "OPsubtotal": 193,
        "UIiva": 21,
        "UIcomsINP": "Lorem eu esse ea dolore magna pariatur dolore nostrud sunt et officia"
      },
      {
        "UIproduct": "do culpa excepteur",
        "UIid": 22,
        "UIcantidad": 37,
        "UIunidad": "kg",
        "UIprecio": 507,
        "OPsubtotal": 1701,
        "UIiva": 21,
        "UIcomsINP": "quis eu anim esse consequat dolore culpa culpa eu id exercitation nulla"
      },
      {
        "UIproduct": "ut dolore exercitation",
        "UIid": 26,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 557,
        "OPsubtotal": 244,
        "UIiva": 21,
        "UIcomsINP": "aliquip veniam sint anim sit dolore sit anim irure enim sit dolore"
      },
      {
        "UIproduct": "sit qui est",
        "UIid": 23,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 969,
        "OPsubtotal": 634,
        "UIiva": 21,
        "UIcomsINP": "mollit sunt consectetur eu et reprehenderit eiusmod ipsum nisi est commodo proident"
      },
      {
        "UIproduct": "consectetur sunt ad",
        "UIid": 23,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 276,
        "OPsubtotal": 552,
        "UIiva": 21,
        "UIcomsINP": "aliqua laboris culpa Lorem veniam ullamco duis aute incididunt adipisicing in consectetur"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 14,
    "uiname": "Craig Carpenter",
    "uitlf": "+34 (805) 442-3142",
    "uiDNI": 573110,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "nulla laboris enim consectetur sint sint exercitation ipsum labore laborum id ea",
    "uiother2": "et pariatur ut occaecat excepteur do ullamco laboris magna sit magna veniam",
    "presnum": "pres1920",
    "uipresname": "presupuestoanim nisi consequat14",
    "uidate": "2017-12-28",
    "SUBTOTAL": 4103.6542,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 3133.8806,
    "status": 1,
    "producto": [
      {
        "UIproduct": "ipsum eiusmod enim",
        "UIid": 28,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 300,
        "OPsubtotal": 1480,
        "UIiva": 21,
        "UIcomsINP": "cillum cillum labore consectetur laboris amet velit irure sint elit aliquip ex"
      },
      {
        "UIproduct": "nostrud cupidatat sit",
        "UIid": 32,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 894,
        "OPsubtotal": 1652,
        "UIiva": 21,
        "UIcomsINP": "eiusmod occaecat excepteur pariatur occaecat veniam mollit laborum Lorem in culpa sint"
      },
      {
        "UIproduct": "laboris occaecat incididunt",
        "UIid": 23,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 507,
        "OPsubtotal": 421,
        "UIiva": 21,
        "UIcomsINP": "magna fugiat ipsum nisi tempor pariatur nostrud laborum in voluptate laborum dolor"
      },
      {
        "UIproduct": "incididunt officia qui",
        "UIid": 38,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 316,
        "OPsubtotal": 642,
        "UIiva": 21,
        "UIcomsINP": "commodo dolor ipsum occaecat ullamco minim excepteur proident nostrud amet proident do"
      },
      {
        "UIproduct": "consectetur officia cupidatat",
        "UIid": 26,
        "UIcantidad": 32,
        "UIunidad": "kg",
        "UIprecio": 412,
        "OPsubtotal": 753,
        "UIiva": 21,
        "UIcomsINP": "anim magna laboris quis duis consectetur aute nostrud incididunt do do est"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 15,
    "uiname": "Luann Baldwin",
    "uitlf": "+34 (959) 575-2047",
    "uiDNI": 605106,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "ullamco occaecat qui minim officia anim et velit elit occaecat Lorem ex",
    "uiother2": "voluptate aliquip consectetur culpa quis labore reprehenderit nulla laborum pariatur commodo sunt",
    "presnum": "pres1525",
    "uipresname": "presupuestolaborum incididunt aliqua15",
    "uidate": "2017-12-29",
    "SUBTOTAL": 2031.971,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1807.9946,
    "status": 3,
    "producto": [
      {
        "UIproduct": "cupidatat sint occaecat",
        "UIid": 24,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 331,
        "OPsubtotal": 1823,
        "UIiva": 21,
        "UIcomsINP": "aliqua cupidatat sunt elit proident labore laboris cupidatat irure et voluptate ea"
      },
      {
        "UIproduct": "magna aliqua minim",
        "UIid": 28,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 314,
        "OPsubtotal": 532,
        "UIiva": 21,
        "UIcomsINP": "dolor nostrud culpa labore ut reprehenderit in qui duis dolor et Lorem"
      },
      {
        "UIproduct": "commodo irure exercitation",
        "UIid": 21,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 210,
        "OPsubtotal": 909,
        "UIiva": 21,
        "UIcomsINP": "laboris tempor ad consequat adipisicing ad aliqua commodo id ut tempor do"
      },
      {
        "UIproduct": "non ipsum incididunt",
        "UIid": 36,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 900,
        "OPsubtotal": 1423,
        "UIiva": 21,
        "UIcomsINP": "duis enim in incididunt laborum labore tempor eiusmod consequat et incididunt culpa"
      },
      {
        "UIproduct": "labore ea cillum",
        "UIid": 22,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 639,
        "OPsubtotal": 1632,
        "UIiva": 21,
        "UIcomsINP": "reprehenderit culpa velit ea et ullamco magna tempor do nostrud enim nisi"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 16,
    "uiname": "Eve Stevenson",
    "uitlf": "+34 (811) 566-3671",
    "uiDNI": 76361,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "nulla fugiat qui ad quis non non velit occaecat nostrud laboris deserunt",
    "uiother2": "adipisicing elit aliqua aliqua quis aliqua id pariatur esse culpa non aliqua",
    "presnum": "pres1482",
    "uipresname": "presupuestoincididunt do cupidatat16",
    "uidate": "2016-04-18",
    "SUBTOTAL": 2159.9817,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4828.2351,
    "status": 4,
    "producto": [
      {
        "UIproduct": "occaecat consectetur sit",
        "UIid": 20,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 707,
        "OPsubtotal": 1291,
        "UIiva": 21,
        "UIcomsINP": "id commodo pariatur occaecat ex cillum consequat sint officia aute excepteur proident"
      },
      {
        "UIproduct": "adipisicing exercitation ad",
        "UIid": 21,
        "UIcantidad": 36,
        "UIunidad": "kg",
        "UIprecio": 449,
        "OPsubtotal": 1624,
        "UIiva": 21,
        "UIcomsINP": "consectetur ut sit officia esse consectetur sint labore cillum aute veniam et"
      },
      {
        "UIproduct": "eiusmod excepteur non",
        "UIid": 31,
        "UIcantidad": 35,
        "UIunidad": "kg",
        "UIprecio": 133,
        "OPsubtotal": 311,
        "UIiva": 21,
        "UIcomsINP": "ea esse dolore aliqua proident nisi tempor laborum mollit tempor tempor dolor"
      },
      {
        "UIproduct": "ullamco qui nostrud",
        "UIid": 23,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 528,
        "OPsubtotal": 1575,
        "UIiva": 21,
        "UIcomsINP": "minim ullamco aliquip deserunt cupidatat eu eiusmod ullamco minim cillum nostrud velit"
      },
      {
        "UIproduct": "anim esse elit",
        "UIid": 22,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 832,
        "OPsubtotal": 612,
        "UIiva": 21,
        "UIcomsINP": "aute proident laboris dolore proident veniam commodo ex adipisicing labore qui sint"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 17,
    "uiname": "Delgado Mosley",
    "uitlf": "+34 (935) 587-3714",
    "uiDNI": 553530,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "aute anim culpa enim aute fugiat quis et ipsum labore commodo irure",
    "uiother2": "labore et qui fugiat sint aliqua aute commodo duis sunt mollit exercitation",
    "presnum": "pres2370",
    "uipresname": "presupuestotempor sunt eu17",
    "uidate": "2014-01-02",
    "SUBTOTAL": 1277.412,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 2039.5083,
    "status": 4,
    "producto": [
      {
        "UIproduct": "esse tempor dolore",
        "UIid": 38,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 414,
        "OPsubtotal": 1525,
        "UIiva": 21,
        "UIcomsINP": "esse anim nulla pariatur nisi ea commodo laborum elit consectetur elit officia"
      },
      {
        "UIproduct": "qui commodo proident",
        "UIid": 28,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 749,
        "OPsubtotal": 1576,
        "UIiva": 21,
        "UIcomsINP": "dolore occaecat laboris sint nisi consequat excepteur tempor aliquip reprehenderit non culpa"
      },
      {
        "UIproduct": "Lorem culpa pariatur",
        "UIid": 38,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 645,
        "OPsubtotal": 1969,
        "UIiva": 21,
        "UIcomsINP": "consequat quis anim ut aute anim minim id elit laborum mollit culpa"
      },
      {
        "UIproduct": "sunt eiusmod eiusmod",
        "UIid": 31,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 910,
        "OPsubtotal": 1031,
        "UIiva": 21,
        "UIcomsINP": "sit officia veniam id aliqua duis aliquip officia cupidatat incididunt non eiusmod"
      },
      {
        "UIproduct": "nostrud culpa voluptate",
        "UIid": 33,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 939,
        "OPsubtotal": 1511,
        "UIiva": 21,
        "UIcomsINP": "laboris et pariatur enim quis veniam laborum do veniam veniam do ipsum"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 18,
    "uiname": "Consuelo Suarez",
    "uitlf": "+34 (877) 534-3779",
    "uiDNI": 471812,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "nulla adipisicing elit cillum ad nisi quis qui culpa esse ex veniam",
    "uiother2": "fugiat qui aliqua dolore cupidatat non velit aute nisi et sunt irure",
    "presnum": "pres1310",
    "uipresname": "presupuestodolor velit Lorem18",
    "uidate": "2016-08-02",
    "SUBTOTAL": 3721.9417,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 749.2543,
    "status": 2,
    "producto": [
      {
        "UIproduct": "quis voluptate eu",
        "UIid": 38,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 143,
        "OPsubtotal": 884,
        "UIiva": 21,
        "UIcomsINP": "ipsum sit dolor ullamco consectetur consequat nostrud nisi consectetur sunt voluptate exercitation"
      },
      {
        "UIproduct": "mollit in eiusmod",
        "UIid": 39,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 546,
        "OPsubtotal": 646,
        "UIiva": 21,
        "UIcomsINP": "minim enim laborum voluptate consectetur do aute ut occaecat nulla fugiat nostrud"
      },
      {
        "UIproduct": "amet id ullamco",
        "UIid": 26,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 713,
        "OPsubtotal": 1714,
        "UIiva": 21,
        "UIcomsINP": "labore quis exercitation occaecat irure pariatur culpa veniam do reprehenderit nostrud ut"
      },
      {
        "UIproduct": "laboris nulla labore",
        "UIid": 31,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 899,
        "OPsubtotal": 371,
        "UIiva": 21,
        "UIcomsINP": "labore fugiat nulla cillum sit non excepteur nisi ea non nulla aliquip"
      },
      {
        "UIproduct": "dolore consectetur fugiat",
        "UIid": 25,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 298,
        "OPsubtotal": 1283,
        "UIiva": 21,
        "UIcomsINP": "mollit excepteur mollit culpa quis sint ut in laborum voluptate aute aliqua"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 19,
    "uiname": "Hansen Velez",
    "uitlf": "+34 (842) 458-2863",
    "uiDNI": 511321,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "exercitation nostrud nisi duis sit proident quis esse aute ad sint cillum",
    "uiother2": "consequat ut ex laboris occaecat aliquip qui tempor reprehenderit reprehenderit magna tempor",
    "presnum": "pres1350",
    "uipresname": "presupuestosunt adipisicing consequat19",
    "uidate": "2017-11-26",
    "SUBTOTAL": 2019.3624,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 3024.4174,
    "status": 1,
    "producto": [
      {
        "UIproduct": "nisi enim nulla",
        "UIid": 37,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 846,
        "OPsubtotal": 1723,
        "UIiva": 21,
        "UIcomsINP": "labore nostrud voluptate enim nisi excepteur dolore sit ut Lorem esse deserunt"
      },
      {
        "UIproduct": "consequat eu amet",
        "UIid": 20,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 475,
        "OPsubtotal": 384,
        "UIiva": 21,
        "UIcomsINP": "tempor fugiat non enim duis qui officia excepteur et et ad deserunt"
      },
      {
        "UIproduct": "eu labore esse",
        "UIid": 23,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 384,
        "OPsubtotal": 495,
        "UIiva": 21,
        "UIcomsINP": "tempor mollit do dolore voluptate occaecat sint cillum minim nisi duis incididunt"
      },
      {
        "UIproduct": "amet elit et",
        "UIid": 35,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 848,
        "OPsubtotal": 1046,
        "UIiva": 21,
        "UIcomsINP": "aliquip duis aute nisi qui occaecat consectetur magna labore officia dolor sit"
      },
      {
        "UIproduct": "nostrud minim duis",
        "UIid": 39,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 407,
        "OPsubtotal": 325,
        "UIiva": 21,
        "UIcomsINP": "ut et proident officia proident sint reprehenderit consequat tempor aliqua cupidatat minim"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 20,
    "uiname": "Wilkinson Bradford",
    "uitlf": "+34 (875) 418-3287",
    "uiDNI": 553401,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "laboris excepteur officia ex enim adipisicing ea ex ex nisi veniam ad",
    "uiother2": "enim laboris minim est et veniam est occaecat aliquip minim ipsum ut",
    "presnum": "pres1481",
    "uipresname": "presupuestoad amet eu20",
    "uidate": "2017-02-10",
    "SUBTOTAL": 1043.3244,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1778.0451,
    "status": 4,
    "producto": [
      {
        "UIproduct": "velit adipisicing officia",
        "UIid": 28,
        "UIcantidad": 37,
        "UIunidad": "kg",
        "UIprecio": 238,
        "OPsubtotal": 771,
        "UIiva": 21,
        "UIcomsINP": "sit proident minim fugiat exercitation occaecat laboris nulla nulla velit Lorem do"
      },
      {
        "UIproduct": "proident nostrud non",
        "UIid": 21,
        "UIcantidad": 36,
        "UIunidad": "kg",
        "UIprecio": 874,
        "OPsubtotal": 1563,
        "UIiva": 21,
        "UIcomsINP": "minim nostrud exercitation irure non officia id adipisicing aliqua aute labore ipsum"
      },
      {
        "UIproduct": "adipisicing ullamco ut",
        "UIid": 33,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 169,
        "OPsubtotal": 1544,
        "UIiva": 21,
        "UIcomsINP": "ullamco in consectetur non exercitation eiusmod pariatur sunt consectetur labore enim occaecat"
      },
      {
        "UIproduct": "consequat commodo nisi",
        "UIid": 35,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 438,
        "OPsubtotal": 827,
        "UIiva": 21,
        "UIcomsINP": "sunt sint in ut ullamco voluptate in in et laboris eu laborum"
      },
      {
        "UIproduct": "officia deserunt et",
        "UIid": 26,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 875,
        "OPsubtotal": 744,
        "UIiva": 21,
        "UIcomsINP": "eu irure proident magna occaecat Lorem duis eiusmod quis ut sint cillum"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 21,
    "uiname": "Odessa Barrera",
    "uitlf": "+34 (855) 462-2621",
    "uiDNI": 49265,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "tempor ex non sint sint qui incididunt incididunt aliquip incididunt pariatur ad",
    "uiother2": "non cupidatat officia nostrud velit elit proident proident do magna cillum voluptate",
    "presnum": "pres1934",
    "uipresname": "presupuestoid exercitation sunt21",
    "uidate": "2017-05-23",
    "SUBTOTAL": 1308.0697,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4360.076,
    "status": 1,
    "producto": [
      {
        "UIproduct": "aliquip eu deserunt",
        "UIid": 24,
        "UIcantidad": 20,
        "UIunidad": "kg",
        "UIprecio": 389,
        "OPsubtotal": 1589,
        "UIiva": 21,
        "UIcomsINP": "minim elit dolor exercitation labore laborum tempor ea esse exercitation non esse"
      },
      {
        "UIproduct": "occaecat laborum nisi",
        "UIid": 34,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 546,
        "OPsubtotal": 598,
        "UIiva": 21,
        "UIcomsINP": "reprehenderit voluptate dolore elit laborum minim proident est veniam id aute sit"
      },
      {
        "UIproduct": "quis aute Lorem",
        "UIid": 25,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 613,
        "OPsubtotal": 1793,
        "UIiva": 21,
        "UIcomsINP": "minim dolor do proident excepteur ex mollit irure officia proident sunt non"
      },
      {
        "UIproduct": "culpa enim esse",
        "UIid": 33,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 217,
        "OPsubtotal": 1088,
        "UIiva": 21,
        "UIcomsINP": "excepteur quis incididunt ipsum dolore anim cupidatat nulla duis ipsum mollit adipisicing"
      },
      {
        "UIproduct": "culpa consequat id",
        "UIid": 33,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 279,
        "OPsubtotal": 1636,
        "UIiva": 21,
        "UIcomsINP": "occaecat do laboris officia fugiat amet Lorem aute ullamco officia ex minim"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 22,
    "uiname": "Bonita Owens",
    "uitlf": "+34 (823) 576-3166",
    "uiDNI": 214492,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "exercitation minim dolore culpa ad ea exercitation enim mollit ullamco dolore sit",
    "uiother2": "excepteur sit eiusmod cillum mollit est ipsum exercitation voluptate do enim cillum",
    "presnum": "pres2252",
    "uipresname": "presupuestolaboris adipisicing aute22",
    "uidate": "2014-12-21",
    "SUBTOTAL": 2201.6271,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1663.1626,
    "status": 2,
    "producto": [
      {
        "UIproduct": "est ad aliqua",
        "UIid": 33,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 238,
        "OPsubtotal": 437,
        "UIiva": 21,
        "UIcomsINP": "in sunt eu ut pariatur pariatur aute laborum ea consectetur irure dolor"
      },
      {
        "UIproduct": "ea qui cillum",
        "UIid": 38,
        "UIcantidad": 26,
        "UIunidad": "kg",
        "UIprecio": 191,
        "OPsubtotal": 1482,
        "UIiva": 21,
        "UIcomsINP": "ex veniam sit aliquip et cillum ut dolore veniam nulla proident est"
      },
      {
        "UIproduct": "sit officia aliqua",
        "UIid": 39,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 916,
        "OPsubtotal": 1808,
        "UIiva": 21,
        "UIcomsINP": "in eu adipisicing in consequat eu occaecat anim occaecat anim exercitation id"
      },
      {
        "UIproduct": "laborum incididunt ea",
        "UIid": 32,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 207,
        "OPsubtotal": 1424,
        "UIiva": 21,
        "UIcomsINP": "qui cillum reprehenderit officia laboris proident eu elit cupidatat magna velit veniam"
      },
      {
        "UIproduct": "labore labore tempor",
        "UIid": 40,
        "UIcantidad": 26,
        "UIunidad": "kg",
        "UIprecio": 864,
        "OPsubtotal": 1320,
        "UIiva": 21,
        "UIcomsINP": "voluptate mollit sit incididunt sit fugiat ea consequat enim quis dolor cupidatat"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 23,
    "uiname": "Brigitte Reeves",
    "uitlf": "+34 (914) 600-2906",
    "uiDNI": 119516,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "commodo et consectetur anim ut ut consequat est ad adipisicing in commodo",
    "uiother2": "ut aute deserunt minim est ex dolore cupidatat Lorem dolore consectetur Lorem",
    "presnum": "pres1422",
    "uipresname": "presupuestofugiat commodo anim23",
    "uidate": "2017-11-20",
    "SUBTOTAL": 2626.636,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1650.4247,
    "status": 3,
    "producto": [
      {
        "UIproduct": "ut sunt nostrud",
        "UIid": 40,
        "UIcantidad": 21,
        "UIunidad": "kg",
        "UIprecio": 736,
        "OPsubtotal": 879,
        "UIiva": 21,
        "UIcomsINP": "officia in culpa incididunt consequat commodo sit exercitation ad consectetur qui laborum"
      },
      {
        "UIproduct": "sint duis exercitation",
        "UIid": 40,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 300,
        "OPsubtotal": 1440,
        "UIiva": 21,
        "UIcomsINP": "Lorem minim enim pariatur culpa eu occaecat non incididunt sit Lorem cillum"
      },
      {
        "UIproduct": "esse labore qui",
        "UIid": 30,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 147,
        "OPsubtotal": 1968,
        "UIiva": 21,
        "UIcomsINP": "aliquip adipisicing Lorem non occaecat nulla nulla anim in ea culpa ea"
      },
      {
        "UIproduct": "nostrud excepteur in",
        "UIid": 30,
        "UIcantidad": 24,
        "UIunidad": "kg",
        "UIprecio": 425,
        "OPsubtotal": 1350,
        "UIiva": 21,
        "UIcomsINP": "ipsum culpa eu elit incididunt quis excepteur ea reprehenderit dolore nisi eiusmod"
      },
      {
        "UIproduct": "quis excepteur et",
        "UIid": 27,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 197,
        "OPsubtotal": 816,
        "UIiva": 21,
        "UIcomsINP": "adipisicing veniam sint minim adipisicing aliqua qui fugiat veniam excepteur magna magna"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 24,
    "uiname": "Nannie Mendoza",
    "uitlf": "+34 (848) 450-2887",
    "uiDNI": 264472,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "enim officia deserunt reprehenderit sit minim non cupidatat quis ad sit consequat",
    "uiother2": "cillum cillum aute magna ullamco est amet pariatur sit consequat officia laboris",
    "presnum": "pres2217",
    "uipresname": "presupuestosit aute ullamco24",
    "uidate": "2017-01-01",
    "SUBTOTAL": 3034.5317,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4993.5927,
    "status": 1,
    "producto": [
      {
        "UIproduct": "anim eu labore",
        "UIid": 23,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 470,
        "OPsubtotal": 838,
        "UIiva": 21,
        "UIcomsINP": "occaecat qui aliquip qui consequat esse nostrud incididunt elit sint excepteur cupidatat"
      },
      {
        "UIproduct": "id exercitation anim",
        "UIid": 29,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 846,
        "OPsubtotal": 858,
        "UIiva": 21,
        "UIcomsINP": "eu aliqua aute minim laborum ea eu et esse commodo ut sint"
      },
      {
        "UIproduct": "commodo labore sit",
        "UIid": 33,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 440,
        "OPsubtotal": 952,
        "UIiva": 21,
        "UIcomsINP": "voluptate officia officia do pariatur nulla voluptate cillum enim est est elit"
      },
      {
        "UIproduct": "sint minim enim",
        "UIid": 20,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 808,
        "OPsubtotal": 1689,
        "UIiva": 21,
        "UIcomsINP": "aliquip amet pariatur Lorem velit voluptate reprehenderit anim occaecat velit ea dolore"
      },
      {
        "UIproduct": "mollit dolore nulla",
        "UIid": 32,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 900,
        "OPsubtotal": 451,
        "UIiva": 21,
        "UIcomsINP": "non eiusmod cupidatat commodo aute magna dolor Lorem consequat nulla qui consequat"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 25,
    "uiname": "Harriet Giles",
    "uitlf": "+34 (978) 436-2772",
    "uiDNI": 263199,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "sunt aute proident qui cillum aliqua et ullamco aliqua proident magna sunt",
    "uiother2": "laborum velit proident irure anim ut officia nulla minim ea magna consequat",
    "presnum": "pres2224",
    "uipresname": "presupuestonisi consectetur dolore25",
    "uidate": "2015-05-17",
    "SUBTOTAL": 721.0518,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1169.1901,
    "status": 4,
    "producto": [
      {
        "UIproduct": "dolore laborum pariatur",
        "UIid": 27,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 862,
        "OPsubtotal": 947,
        "UIiva": 21,
        "UIcomsINP": "officia ex eu esse excepteur do ut velit laborum non amet consequat"
      },
      {
        "UIproduct": "ex amet enim",
        "UIid": 31,
        "UIcantidad": 20,
        "UIunidad": "kg",
        "UIprecio": 946,
        "OPsubtotal": 1953,
        "UIiva": 21,
        "UIcomsINP": "commodo esse minim ullamco incididunt commodo anim laborum nulla qui aute incididunt"
      },
      {
        "UIproduct": "ipsum adipisicing id",
        "UIid": 31,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 129,
        "OPsubtotal": 1664,
        "UIiva": 21,
        "UIcomsINP": "ullamco nisi nisi voluptate est excepteur anim ad do enim anim amet"
      },
      {
        "UIproduct": "nulla ex laborum",
        "UIid": 39,
        "UIcantidad": 26,
        "UIunidad": "kg",
        "UIprecio": 515,
        "OPsubtotal": 818,
        "UIiva": 21,
        "UIcomsINP": "officia in esse occaecat id amet velit adipisicing incididunt esse aliquip laboris"
      },
      {
        "UIproduct": "laboris voluptate id",
        "UIid": 29,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 949,
        "OPsubtotal": 768,
        "UIiva": 21,
        "UIcomsINP": "exercitation culpa tempor non irure non labore non culpa nisi ad laboris"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 26,
    "uiname": "Janine Tucker",
    "uitlf": "+34 (874) 524-2693",
    "uiDNI": 173941,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "sunt ex occaecat nostrud excepteur proident mollit elit magna elit amet dolor",
    "uiother2": "duis adipisicing ad consequat qui magna enim irure ullamco nisi consequat id",
    "presnum": "pres2107",
    "uipresname": "presupuestoveniam labore in26",
    "uidate": "2015-01-20",
    "SUBTOTAL": 795.1477,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1048.9313,
    "status": 4,
    "producto": [
      {
        "UIproduct": "minim ad do",
        "UIid": 20,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 810,
        "OPsubtotal": 832,
        "UIiva": 21,
        "UIcomsINP": "laborum deserunt irure reprehenderit proident ut pariatur ex occaecat pariatur eu labore"
      },
      {
        "UIproduct": "nostrud laboris elit",
        "UIid": 33,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 352,
        "OPsubtotal": 255,
        "UIiva": 21,
        "UIcomsINP": "proident nisi adipisicing ex nisi sunt nulla id laborum Lorem et elit"
      },
      {
        "UIproduct": "non fugiat enim",
        "UIid": 40,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 556,
        "OPsubtotal": 863,
        "UIiva": 21,
        "UIcomsINP": "consequat esse ut eiusmod nostrud velit excepteur magna labore cupidatat ea in"
      },
      {
        "UIproduct": "aliquip dolor duis",
        "UIid": 39,
        "UIcantidad": 38,
        "UIunidad": "kg",
        "UIprecio": 456,
        "OPsubtotal": 387,
        "UIiva": 21,
        "UIcomsINP": "sunt officia culpa anim culpa dolore enim velit non eiusmod do ad"
      },
      {
        "UIproduct": "occaecat aute aliqua",
        "UIid": 34,
        "UIcantidad": 28,
        "UIunidad": "kg",
        "UIprecio": 842,
        "OPsubtotal": 728,
        "UIiva": 21,
        "UIcomsINP": "esse ut veniam dolore dolor laborum Lorem magna voluptate do ea sint"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 27,
    "uiname": "Dixie Welch",
    "uitlf": "+34 (968) 483-2399",
    "uiDNI": 392200,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "et laboris laboris et velit proident sunt exercitation cillum reprehenderit proident duis",
    "uiother2": "nisi laborum minim id non fugiat irure commodo et officia anim laboris",
    "presnum": "pres1878",
    "uipresname": "presupuestoexcepteur velit quis27",
    "uidate": "2016-01-25",
    "SUBTOTAL": 4655.8489,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1010.1918,
    "status": 4,
    "producto": [
      {
        "UIproduct": "anim irure laboris",
        "UIid": 35,
        "UIcantidad": 26,
        "UIunidad": "kg",
        "UIprecio": 318,
        "OPsubtotal": 1259,
        "UIiva": 21,
        "UIcomsINP": "minim nostrud magna laboris magna quis aliquip nisi dolor qui voluptate nostrud"
      },
      {
        "UIproduct": "sunt nulla voluptate",
        "UIid": 35,
        "UIcantidad": 28,
        "UIunidad": "kg",
        "UIprecio": 858,
        "OPsubtotal": 1515,
        "UIiva": 21,
        "UIcomsINP": "nulla occaecat minim minim incididunt dolore enim ipsum officia amet ullamco commodo"
      },
      {
        "UIproduct": "laboris consectetur do",
        "UIid": 29,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 469,
        "OPsubtotal": 1097,
        "UIiva": 21,
        "UIcomsINP": "officia veniam eiusmod incididunt do laborum labore officia dolor voluptate voluptate adipisicing"
      },
      {
        "UIproduct": "fugiat duis pariatur",
        "UIid": 37,
        "UIcantidad": 20,
        "UIunidad": "kg",
        "UIprecio": 634,
        "OPsubtotal": 1301,
        "UIiva": 21,
        "UIcomsINP": "veniam enim laboris fugiat qui enim proident tempor aute sint consectetur nostrud"
      },
      {
        "UIproduct": "ut nostrud fugiat",
        "UIid": 20,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 547,
        "OPsubtotal": 1353,
        "UIiva": 21,
        "UIcomsINP": "ad incididunt deserunt aliquip laborum nisi sit officia est velit eiusmod do"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 28,
    "uiname": "Lorene Gibson",
    "uitlf": "+34 (909) 459-3336",
    "uiDNI": 55516,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "dolore culpa ipsum cupidatat dolor labore magna fugiat irure ipsum eu laboris",
    "uiother2": "magna pariatur consequat eiusmod ex cupidatat aute anim velit consectetur ad Lorem",
    "presnum": "pres1360",
    "uipresname": "presupuestoid laboris excepteur28",
    "uidate": "2015-04-14",
    "SUBTOTAL": 4962.6658,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1037.5802,
    "status": 2,
    "producto": [
      {
        "UIproduct": "officia dolore amet",
        "UIid": 34,
        "UIcantidad": 32,
        "UIunidad": "kg",
        "UIprecio": 586,
        "OPsubtotal": 746,
        "UIiva": 21,
        "UIcomsINP": "aliqua officia dolor ex fugiat nostrud fugiat fugiat aute adipisicing voluptate velit"
      },
      {
        "UIproduct": "consequat proident duis",
        "UIid": 30,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 732,
        "OPsubtotal": 821,
        "UIiva": 21,
        "UIcomsINP": "officia anim tempor esse ad est id Lorem esse in ea voluptate"
      },
      {
        "UIproduct": "aute officia eiusmod",
        "UIid": 21,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 337,
        "OPsubtotal": 288,
        "UIiva": 21,
        "UIcomsINP": "culpa laboris non Lorem qui aute ex est magna velit est consequat"
      },
      {
        "UIproduct": "commodo occaecat adipisicing",
        "UIid": 28,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 458,
        "OPsubtotal": 639,
        "UIiva": 21,
        "UIcomsINP": "proident aute do ipsum culpa esse nostrud in ullamco sunt nisi est"
      },
      {
        "UIproduct": "Lorem aliquip veniam",
        "UIid": 25,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 594,
        "OPsubtotal": 1720,
        "UIiva": 21,
        "UIcomsINP": "aute minim ex mollit magna ad dolore ullamco non non ipsum tempor"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 29,
    "uiname": "Sherrie Clemons",
    "uitlf": "+34 (982) 569-2904",
    "uiDNI": 103065,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "minim mollit magna aliquip et quis incididunt in non ex reprehenderit deserunt",
    "uiother2": "ullamco id id ex proident qui aliqua aliqua minim esse qui ullamco",
    "presnum": "pres2487",
    "uipresname": "presupuestoaliquip non voluptate29",
    "uidate": "2015-01-11",
    "SUBTOTAL": 2771.4194,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4816.3162,
    "status": 3,
    "producto": [
      {
        "UIproduct": "esse aliqua consequat",
        "UIid": 26,
        "UIcantidad": 36,
        "UIunidad": "kg",
        "UIprecio": 113,
        "OPsubtotal": 1272,
        "UIiva": 21,
        "UIcomsINP": "est officia dolore eiusmod adipisicing occaecat ad qui nulla tempor sunt excepteur"
      },
      {
        "UIproduct": "pariatur aute minim",
        "UIid": 20,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 599,
        "OPsubtotal": 1515,
        "UIiva": 21,
        "UIcomsINP": "adipisicing exercitation enim non est nulla sit dolor minim consectetur officia laborum"
      },
      {
        "UIproduct": "proident nostrud sit",
        "UIid": 20,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 972,
        "OPsubtotal": 1703,
        "UIiva": 21,
        "UIcomsINP": "pariatur nisi culpa nulla laborum enim ex consequat do minim voluptate do"
      },
      {
        "UIproduct": "ex nulla nulla",
        "UIid": 20,
        "UIcantidad": 33,
        "UIunidad": "kg",
        "UIprecio": 617,
        "OPsubtotal": 311,
        "UIiva": 21,
        "UIcomsINP": "veniam in amet nostrud quis enim et est eiusmod eiusmod dolore mollit"
      },
      {
        "UIproduct": "culpa officia veniam",
        "UIid": 38,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 647,
        "OPsubtotal": 1225,
        "UIiva": 21,
        "UIcomsINP": "excepteur velit pariatur Lorem eiusmod sunt pariatur quis pariatur officia fugiat laborum"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 30,
    "uiname": "Abbott Conley",
    "uitlf": "+34 (962) 540-2905",
    "uiDNI": 144959,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "est ipsum non quis ipsum ullamco consectetur fugiat dolore adipisicing sint velit",
    "uiother2": "magna elit laboris tempor laboris magna sint duis aliqua aliqua culpa consectetur",
    "presnum": "pres2115",
    "uipresname": "presupuestodolore eu quis30",
    "uidate": "2015-10-07",
    "SUBTOTAL": 2247.729,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 914.6834,
    "status": 4,
    "producto": [
      {
        "UIproduct": "culpa ex velit",
        "UIid": 31,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 529,
        "OPsubtotal": 1983,
        "UIiva": 21,
        "UIcomsINP": "reprehenderit dolore occaecat est laborum cupidatat labore labore id minim nulla in"
      },
      {
        "UIproduct": "minim minim ea",
        "UIid": 31,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 915,
        "OPsubtotal": 934,
        "UIiva": 21,
        "UIcomsINP": "aliqua ea magna culpa ut sint id labore qui aliquip laborum in"
      },
      {
        "UIproduct": "voluptate occaecat aute",
        "UIid": 32,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 674,
        "OPsubtotal": 1245,
        "UIiva": 21,
        "UIcomsINP": "commodo consequat nisi voluptate commodo cillum consequat proident eiusmod duis cillum occaecat"
      },
      {
        "UIproduct": "magna proident velit",
        "UIid": 24,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 276,
        "OPsubtotal": 1126,
        "UIiva": 21,
        "UIcomsINP": "tempor voluptate duis commodo nulla laboris commodo voluptate cupidatat labore excepteur ut"
      },
      {
        "UIproduct": "officia aliqua velit",
        "UIid": 26,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 373,
        "OPsubtotal": 1866,
        "UIiva": 21,
        "UIcomsINP": "fugiat culpa enim labore sint ex veniam ullamco velit adipisicing deserunt cupidatat"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 31,
    "uiname": "Wiley Rosario",
    "uitlf": "+34 (928) 528-3313",
    "uiDNI": 228664,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "ex nisi consequat laborum enim eiusmod amet dolor adipisicing ut sunt do",
    "uiother2": "occaecat do adipisicing ipsum eiusmod aliqua laboris reprehenderit fugiat consequat Lorem qui",
    "presnum": "pres1792",
    "uipresname": "presupuestomollit eu aliquip31",
    "uidate": "2014-12-09",
    "SUBTOTAL": 382.093,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 4423.4151,
    "status": 4,
    "producto": [
      {
        "UIproduct": "deserunt eu officia",
        "UIid": 33,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 602,
        "OPsubtotal": 434,
        "UIiva": 21,
        "UIcomsINP": "in veniam Lorem ad non in tempor ex ad reprehenderit et ut"
      },
      {
        "UIproduct": "duis cillum proident",
        "UIid": 25,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 946,
        "OPsubtotal": 1536,
        "UIiva": 21,
        "UIcomsINP": "irure aliquip laborum nisi consectetur reprehenderit nostrud fugiat ea sint fugiat dolore"
      },
      {
        "UIproduct": "qui ad et",
        "UIid": 37,
        "UIcantidad": 27,
        "UIunidad": "kg",
        "UIprecio": 762,
        "OPsubtotal": 900,
        "UIiva": 21,
        "UIcomsINP": "magna tempor velit deserunt do commodo mollit culpa nostrud sunt labore ipsum"
      },
      {
        "UIproduct": "nulla quis sit",
        "UIid": 31,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 261,
        "OPsubtotal": 226,
        "UIiva": 21,
        "UIcomsINP": "occaecat duis id irure irure veniam sunt ut irure ut ipsum anim"
      },
      {
        "UIproduct": "id proident voluptate",
        "UIid": 39,
        "UIcantidad": 23,
        "UIunidad": "kg",
        "UIprecio": 905,
        "OPsubtotal": 448,
        "UIiva": 21,
        "UIcomsINP": "fugiat enim proident culpa irure commodo nulla sint cupidatat qui ex adipisicing"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 32,
    "uiname": "Tracie Owen",
    "uitlf": "+34 (902) 552-3556",
    "uiDNI": 69430,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "ex sit fugiat ex velit eu consequat adipisicing enim exercitation sit amet",
    "uiother2": "sint aliqua eu magna occaecat laboris tempor consectetur fugiat esse labore do",
    "presnum": "pres2347",
    "uipresname": "presupuestoaliquip cupidatat sit32",
    "uidate": "2018-01-03",
    "SUBTOTAL": 4940.0902,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 424.0079,
    "status": 4,
    "producto": [
      {
        "UIproduct": "aliquip fugiat laborum",
        "UIid": 38,
        "UIcantidad": 39,
        "UIunidad": "kg",
        "UIprecio": 798,
        "OPsubtotal": 310,
        "UIiva": 21,
        "UIcomsINP": "occaecat incididunt dolor consequat enim eu magna proident ipsum exercitation ea exercitation"
      },
      {
        "UIproduct": "ex ut pariatur",
        "UIid": 39,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 435,
        "OPsubtotal": 993,
        "UIiva": 21,
        "UIcomsINP": "ea enim eiusmod officia occaecat sunt in ipsum mollit culpa qui aliqua"
      },
      {
        "UIproduct": "consequat adipisicing ut",
        "UIid": 37,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 345,
        "OPsubtotal": 1775,
        "UIiva": 21,
        "UIcomsINP": "duis enim deserunt tempor aliqua ut commodo mollit cillum occaecat officia sint"
      },
      {
        "UIproduct": "laboris ex pariatur",
        "UIid": 25,
        "UIcantidad": 32,
        "UIunidad": "kg",
        "UIprecio": 504,
        "OPsubtotal": 1608,
        "UIiva": 21,
        "UIcomsINP": "irure cillum do veniam sunt culpa labore et ut commodo consectetur officia"
      },
      {
        "UIproduct": "qui non voluptate",
        "UIid": 33,
        "UIcantidad": 30,
        "UIunidad": "kg",
        "UIprecio": 701,
        "OPsubtotal": 1426,
        "UIiva": 21,
        "UIcomsINP": "laboris tempor id enim ut mollit proident minim id ea dolor nulla"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 33,
    "uiname": "Finley Blair",
    "uitlf": "+34 (916) 497-2852",
    "uiDNI": 616607,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "qui mollit dolore eu sit ipsum velit duis excepteur duis fugiat nulla",
    "uiother2": "culpa minim ut deserunt ad elit cupidatat quis qui qui reprehenderit Lorem",
    "presnum": "pres2181",
    "uipresname": "presupuestonulla aute proident33",
    "uidate": "2015-01-14",
    "SUBTOTAL": 3115.1563,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 3392.5745,
    "status": 4,
    "producto": [
      {
        "UIproduct": "fugiat laboris est",
        "UIid": 26,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 119,
        "OPsubtotal": 1337,
        "UIiva": 21,
        "UIcomsINP": "cillum do proident sint aliqua id occaecat adipisicing eiusmod et eu aliquip"
      },
      {
        "UIproduct": "aute nulla eu",
        "UIid": 32,
        "UIcantidad": 29,
        "UIunidad": "kg",
        "UIprecio": 409,
        "OPsubtotal": 785,
        "UIiva": 21,
        "UIcomsINP": "deserunt esse sunt deserunt ad laborum laborum ipsum exercitation nostrud aliquip irure"
      },
      {
        "UIproduct": "amet nulla aute",
        "UIid": 25,
        "UIcantidad": 22,
        "UIunidad": "kg",
        "UIprecio": 668,
        "OPsubtotal": 1888,
        "UIiva": 21,
        "UIcomsINP": "nisi aliquip ex commodo laboris consequat aute esse sint officia exercitation Lorem"
      },
      {
        "UIproduct": "incididunt reprehenderit exercitation",
        "UIid": 22,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 465,
        "OPsubtotal": 583,
        "UIiva": 21,
        "UIcomsINP": "ipsum exercitation incididunt eiusmod commodo pariatur deserunt proident ut nulla eu fugiat"
      },
      {
        "UIproduct": "ipsum reprehenderit officia",
        "UIid": 22,
        "UIcantidad": 25,
        "UIunidad": "kg",
        "UIprecio": 217,
        "OPsubtotal": 238,
        "UIiva": 21,
        "UIcomsINP": "do anim aute proident eiusmod anim sunt fugiat incididunt pariatur ea id"
      }
    ]
  },
  {
    "connection": "success",
    "ID": 34,
    "uiname": "Delores Tanner",
    "uitlf": "+34 (809) 434-2757",
    "uiDNI": 559509,
    "uidir": "Dirección",
    "uiemail": "Email",
    "uiother1": "ex minim fugiat dolore nisi labore aliqua eiusmod amet in incididunt sunt",
    "uiother2": "irure aute commodo ea ea ullamco enim est tempor ipsum reprehenderit cupidatat",
    "presnum": "pres1230",
    "uipresname": "presupuestonostrud consequat adipisicing34",
    "uidate": "2014-07-10",
    "SUBTOTAL": 1869.1192,
    "IVAtotalamount": 21.02,
    "IVAtotalpercent": 21,
    "GRANDTOTAL": 1287.6808,
    "status": 3,
    "producto": [
      {
        "UIproduct": "voluptate reprehenderit incididunt",
        "UIid": 26,
        "UIcantidad": 31,
        "UIunidad": "kg",
        "UIprecio": 462,
        "OPsubtotal": 756,
        "UIiva": 21,
        "UIcomsINP": "reprehenderit ea cupidatat tempor ex labore laborum dolor elit eiusmod duis cillum"
      },
      {
        "UIproduct": "duis enim nulla",
        "UIid": 21,
        "UIcantidad": 34,
        "UIunidad": "kg",
        "UIprecio": 797,
        "OPsubtotal": 159,
        "UIiva": 21,
        "UIcomsINP": "enim et irure non duis cupidatat culpa cillum amet reprehenderit proident duis"
      },
      {
        "UIproduct": "velit qui consequat",
        "UIid": 23,
        "UIcantidad": 40,
        "UIunidad": "kg",
        "UIprecio": 651,
        "OPsubtotal": 103,
        "UIiva": 21,
        "UIcomsINP": "veniam ex eu officia sint magna officia eu do qui occaecat ea"
      },
      {
        "UIproduct": "enim elit fugiat",
        "UIid": 26,
        "UIcantidad": 28,
        "UIunidad": "kg",
        "UIprecio": 242,
        "OPsubtotal": 1868,
        "UIiva": 21,
        "UIcomsINP": "eu sint ad quis nisi aliqua reprehenderit tempor sit sint ut proident"
      },
      {
        "UIproduct": "eiusmod cillum sint",
        "UIid": 30,
        "UIcantidad": 36,
        "UIunidad": "kg",
        "UIprecio": 705,
        "OPsubtotal": 703,
        "UIiva": 21,
        "UIcomsINP": "ullamco dolor Lorem tempor deserunt nostrud ad incididunt enim enim sunt sit"
      }
    ]
  }
]