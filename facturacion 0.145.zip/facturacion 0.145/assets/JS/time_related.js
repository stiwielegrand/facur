let UIfechaslider = document.querySelector('#UIfechacheck');
let dateHolder = document.querySelector('#UIfecha');
dateHolder.value = currentDate;

UIfechaslider.addEventListener('change', function () {
    if (this.checked) {
        dateHolder.value = currentDate;
    } else {
        dateHolder.value = "";
    }
});

dateHolder.addEventListener('change', function () {
    if (currentDate == dateHolder.value) {
        UIfechaslider.checked = true;
    } else {
        UIfechaslider.checked = false;
    } 
});