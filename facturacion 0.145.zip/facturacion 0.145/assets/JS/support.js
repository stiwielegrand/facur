function cookies(cookie) {
    let cookiename = cookie + "=";
    let existingCookie = decodeURIComponent(document.cookie);
    let cookies = existingCookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
        while (cookies[i].charAt(0) == ' ') {
            cookies[i] = cookies[i].substring(1);
        }
        if (cookies[i].indexOf(cookiename) == 0) {
            return cookies[i].substring(cookiename.length, cookies[i].length)
        }
    }
    return "";
}