let uploadList = document.querySelector('#uploadList'),
    UIsubmit = document.querySelector('#uiSubmit'),
    UIdeletePres = document.querySelector('#UIdeletePres'),
    UserDataImport = document.querySelector("#UserDataImport"),
    uiname = document.querySelector('input[name="UIcompEmit"]'),
    uiDNI = document.querySelector('input[name="UIcompCIF"]'),
    uipresnum = document.querySelector('input[name="UIcompID"]'),
    UIcompValue = document.querySelector('input[name="UIcompValue"]'),
    uiother1 = document.querySelector('input[name="UIcompOther"]'),
    uidate = document.querySelector('input[name="uidate"]'),
    uipresname = document.querySelector('input[name="UIcompName"]'),
    container = document.querySelector('#inputcontainer');
    uploadForm = document.querySelector('input[name="UIcompUpload"]');

uploadForm.addEventListener('change', addUpload);

UIdeletePres.addEventListener('click', function () {
    relocate('factura_comp.html');
})

UserDataImport.addEventListener('click', function () {
    loadUsers(null);
});

let userList = Array.from(gatherData("provider"));

function addUpload() {
    let uploadList =[];
    for(let x=0; uploadForm.files.length > x; x++){
        uploadList.push(uploadForm.files[x])
    }

    uploadList.forEach(function(file){
        prepareUpload(file);
    })

    uploadForm.value = "";
}

function prepareUpload(file){
    let liContainer = document.createElement('LI');
    liContainer.class="collection-item";
    let row = document.createElement('div');
    row.classList.add('row')
    row.classList.add('bottomless')
    console.log(row)
}



function SubmitPres(e) {
    e.preventDefault;
    if (uiname.value == "" || uiDNI.value == "" || uidate.value == "" || uipresname.value == "" || UIcompValue.value == "") {

        let mandatory = [uiname, uiDNI, uipresname, UIcompValue];
        for (let i = 0; i < mandatory.length; i++) {
            if (mandatory[i].value == "") {
                mandatory[i].classList += " invalid";
                console.log(mandatory[i]);
            } else if (mandatory[i].value != "") {
                mandatory[i].class = "input-field validate valid";
            }
        }
        if (uidate.value == "") {
            uidate.classList += " invalid";
        } else if (uidate.value != "") {
            uidate.classList = "input-field validate datepicker valid";
        }
    } else {
        upload();
    }
}
function upload(style) {
    console.log("runs");
    let XHR = new XMLHttpRequest();
    let formData = new FormData(document.querySelector("#newComp"));

    var urlEncodedData = "";
    var urlEncodedDataPairs = [];

    for (var pair of formData.entries()) {
        console.log(pair[0] + ', ' + pair[1]);
        urlEncodedDataPairs.push(pair[0] + '=' + pair[1]);
    }
    console.log(urlEncodedDataPairs)


    // Combine the pairs into a single string and replace all %-encoded spaces to 
    // the '+' character; matches the behaviour of browser form submissions.
    urlEncodedData = urlEncodedDataPairs.join('&').replace(/%20/g, '+');
    console.log(urlEncodedData);

    XHR.addEventListener("load", function (event) {
        relocate('factura_comp.html');
        console.log(XHR.response);
    });

    XHR.addEventListener("error", function (event) {
        alert("Error!");
    });
    if (style == "temp") {
        XHR.open("POST", "assets/PHP/submit_pres.php?style=temp", true);
        XHR.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        XHR.send(urlEncodedData);
    }
    else {
        XHR.open("POST", "assets/submit_pres.php", true);
        XHR.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        XHR.send(urlEncodedData);
    }
}

function loadUsers(page) {
    if (page == null) page = 1;
    let clientDataList = document.querySelector("#clientDataList");
    let clientDataListFooter = document.querySelector('#clientDataListFooter');
    let userListToLoad = [];
    let articles = pagination("loadUsers", userList, page)[0];
    let pages = pagination("loadUsers", userList, page)[1];
    let contents = pagination("loadUsers", userList, page)[2];
    clientDataList.innerHTML = articles;
    clientDataListFooter.innerHTML = pages;
    console.log(contents)
}

function pagination(target, list, page) {
    let maxPages;
    if ((list.length % 10) == 0) maxPages = list.length / 10;
    else maxPages = Math.trunc((list.length / 10) + 1);
    let pageButtons = [];
    for (let x = 1; x <= maxPages; x++) {
        if (x != page) pageButtons.push('<li><a class="' + target + 'Pagination" href="#" data-page="' + x + '" data-target="' + target + '">' + x + '</a></li>');
        else pageButtons.push('<li class="active"><a>' + x + '</a></li>');

    }
    let clientListPagination =
        `<div class="modal-footer">
                <div class="row">
                    <div class="col s12 ">
                        <ul class="pagination center-align">
                        ${pageButtons.map(function (element) {
            return element;
        }).join('')}
                        </ul>
                    </div>
                </div>
            </div>`;

    let clientListcontent = function () {
        //FIRST
        if (page == 1) { list = list.slice(0, 10); }
        //LAST
        else if (maxPages == page) { list = list.slice((page * 10) - 10); }
        //MID
        else { list = list.slice(((page * 10) - 10), (page * 10)); }
        return list;
    }

    if (target == "loadUsers") {
        let clientList = `
            ${clientListcontent().map(function (collectionItems) {
                return '<a href="#!" class="collection-item modal-close" data-action="clientDataFiller" data-id="' + collectionItems.ID + '">' + collectionItems.uiname + '</a>'
            }).join('')}`
        return [clientList, clientListPagination, clientListcontent()];
    }
    if (target == "prevVers") {
        let clientList = `
            ${clientListcontent().map(function (collectionItems) {
                return '<a href="#" class="collection-item modal-close" data-action="prevEdit" data-id="' + collectionItems.ID + '" data-vers="' + collectionItems.vers + '">' + collectionItems.presname + ' (' + collectionItems.created + ')</a>'
            }).join('')}`

        return [clientList, clientListPagination, clientListcontent()];
    }
}

function fillClientData(ID) {
    let CD = function retrieveData() {
        let JSONuser = userList.filter(element => element.ID == ID);
        console.log(JSONuser);
        return JSONuser[0]; // TO BE REMOVED
    }
    uiname.value = CD().uiname;
    let CDphoneNo = CD().uitlf.match(/\d/g);
    CDphoneNo = CDphoneNo.join('');
    uitlf.value = CDphoneNo;
    uidir.value = CD().uidir;
    uiemail.value = CD().uiemail;
    uiDNI.value = CD().uiDNI;

    let mandatory = [uitlf, uidir, uiemail, uiDNI, uiname];
    for (let i = 0; i < mandatory.length; i++) {
        if (mandatory[i].value == "") {
            mandatory[i].classList += " invalid";
        }
        if (mandatory[i].value != "") {
            mandatory[i].classList = "input-field validate valid nospinner";
        }
    }
    if (uidate.value == "") {
        uidate.classList += " invalid";
    } else if (uidate.value != "") {
        uidate.classList = "input-field validate datepicker valid";
    }
}


var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
        if (!mutation.addedNodes) return;

        document.querySelectorAll('.closeThisAlertbox').forEach(function(closeBtn){
            closeBtn.addEventListener('click', function(){
                closeBtn.parentElement.parentElement.fadeOut();
                //closeBtn.parentElement.parentElement.remove();
                /////////////////////////////////////////////// LEFT HERE
            })
        });

        Array.from(document.querySelectorAll("a[data-action='clientDataFiller']")).forEach(function (page) {
            page.addEventListener('click', function () {
                fillClientData(page.dataset.id);
            });
        });

        Array.from(document.querySelectorAll("a[data-action='prevEdit']")).forEach(function (version) {
            version.addEventListener('click', function () {
                let trigger = document.querySelector("#UIrejectCurrentCont");
                trigger.dataset.ID = version.dataset.id;
                trigger.dataset.vers = version.dataset.vers;
                setTimeout(function () {
                    $('#UIrejectCurrent').modal('open');
                }, 300)
            });
        });


        Array.from(document.querySelectorAll(".loadUsersPagination")).forEach(function (page) {
            page.addEventListener('click', function () {
                loadUsers(page.dataset.page);
            });
        });

        Array.from(document.querySelectorAll('.prevPresPagination')).forEach(function (page) {
            page.addEventListener('click', function () {
                loadPrevs(page.dataset.page);
            });
        });

        for (var i = 0; i < mutation.addedNodes.length; i++) {
            var node = mutation.addedNodes[i];
        }
    })
})

observer.observe(document.body, {
    childList: true
    , subtree: true
    , attributes: false
    , characterData: false
})

$(window).bind('click mouseup mousedown keydown keypress keyup submit change', idleUser);
var active = true,
  delay = 60000,
  timer = null;

function idleUser(e)
{
  active = true;
  if (timer) clearTimeout(timer);
  timer = setTimeout(function(t){
    active = false;
    console.log("idle")
  }, delay);
}