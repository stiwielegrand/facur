

let trimStart = TrimSelector(currMonth)[2];
let trimEnd = TrimSelector(currMonth)[3];

//Request last 5 pres. 
let Last5 = function(){

}