function PrintElem(content,text,compdata) {
    let other1 = (content.uiother1.length > 0) ? `<tr><th>Otros datos: </th><td>${content.uiother1}</td></tr>` : '';
    let other2 = (content.uiother2.length > 0) ? `<tr><th>Otros datos: </th><td>${content.uiother2}</td></tr>` : '';

    function addCompdata(compdata){
        if(compdata != undefined||compdata != null) {
            compdata.entries

            //USE https://javascript.info/keys-values-entries
        }
    }

    function productArticles(productos) {
        return `
       ${content.producto.map(function (producto) {
                return `
        <tr>
            <td class="lft"><span class="PRNT-strong">${producto.UIproduct}</span> <br> ${producto.UIcomsINP}</td>
            <td>${producto.UIcantidad + producto.UIunidad}</td>
            <td>${producto.UIiva}%</td>
            <td>${producto.OPsubtotal}€</td>
        </tr>
        `
            }).join('')}
       `
    }

    var mywindow = window.open('', 'PRINT', 'toolbar=no,height=800,width=1000,titlebar=no,scrollbars=no'); // 
    mywindow.document.write('<!DOCTYPE html><html><head><title>Impresion</title>');
    mywindow.document.write('<link rel="stylesheet" href="assets/print.css" media="print">');
    mywindow.document.write('<link rel="stylesheet" href="assets/print.css" media="screen">');
    mywindow.document.write('<link href="https://fonts.googleapis.com/css?family=Raleway:900" rel="stylesheet">');
    mywindow.document.write('<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">');
    mywindow.document.write('</head><body>');
    mywindow.document.write(`
                <div id="PRNT-printable" class="PRNT">
                    <div id="PRNT-header">
                        <div id="PRNT-logo">ISOLATEC</div>
                        <div id="PRNT-subheader"><span id="PRNT-sublogo">Presupuesto</span></div>
                        <table>
                            <tr >
                            <td id="PRNT-userdetails">
                                    <table class="PRNT-userdetails-table">
                                        <tr><th>Cliente: </th><td>${content.uiname}</td></tr>
                                        <tr><th>DNI:</th><td>${content.uiDNI}</td></tr>
                                        <tr><th>Dirección: </th><td>${content.uidir}</td></tr>
                                        ${other1}
                                        ${other2}
                                    </table>
                                    </td>
                            <td id="PRNT-presdetails">
                            <table class="PRNT-userdetails-table">
                                <tr><th>Fecha:</th><td>${content.uidate}</td></tr>
                                <tr><th>Validez:</th><td>30 días</td></tr>
                                <tr><th>Número:</th><td>${content.presnum}</td></tr>
                            </table>
                            </td>
                                </tr>
                        </table>
                    </div>
                    <div id="PRNT-content">
                        <table id="PRNT-table">
                            <tr id="PRNT-tablehead">
                                <th class="cc c50 mid">Producto</th>
                                <th class="cc c15">Cantidad</th>
                                <th class="cc c10">IVA</th>
                                <th class="cc c15">Subtotal</th>
                            </tr>
                            ${productArticles((content.producto))}
                        </table>
                    </div>
                    <table>
                    <tr>
                    <td id="PRNT-left-sum">
                    ${text}
                    </td>
                    <td id="PRNT-sum">
                    <div class="PRNT-strong lpad20">Subtotal: <span id="PRNT-IVA" class="PRNT-normal">${content.SUBTOTAL}€</span></div>
                    <br>
                    <div class="PRNT-strong lpad20">IVA( ${content.IVAtotalpercent}% ): <span id="PRNT-IVA" class="PRNT-normal">${content.IVAtotalamount}€</span></div>
                    <br>
                    <div class="PRNT-totaldeco">
                    <div class="PRNT-strong">TOTAL A PAGAR: <span id="PRNT-TOTAL" class="PRNT-normal">${content.GRANDTOTAL}€</span></div>
                    </td>
                    </tr>
                    </table>
                    <div >
                        
                    </div>
                    <div >
                        
                        
                        </div>
                        <br>
                    </div>
                </div>
    `);

    //    mywindow.document.write(document.querySelector('#PRNT-printable').innerHTML);
    mywindow.document.write('</body></html>');
    mywindow.document.close();
    mywindow.addEventListener('load', function () {
        mywindow.print();
        //    mywindow.close();
    })
    mywindow.addEventListener('blur', function () {
        // mywindow.close();
    })
    return false;
}

function PDFprint() {

    let other1 = (content.uiother1.length > 0) ? `<tr><th>Otros datos: </th><td>${content.uiother1}</td></tr>` : '';
    let other2 = (content.uiother2.length > 0) ? `<tr><th>Otros datos: </th><td>${content.uiother2}</td></tr>` : '';

    function productArticles(productos) {
        return `
        ${content.producto.map(function (producto) {
                return `
            <tr>
                <td class="lft"><span class="PRNT-strong">${producto.UIproduct}</span> <br> ${producto.UIcomsINP}</td>
                <td>${producto.UIcantidad + producto.UIunidad}</td>
                <td>${producto.UIiva}%</td>
                <td>${producto.OPsubtotal}€</td>
            </tr>
            `
            }).join('')}
        `
    }

    let pdfCore = `<div id="PRNT-printable" class="PRNT">
                    <div id="PRNT-header">
                        <div id="PRNT-logo">ISOLATEC</div>
                        <div id="PRNT-subheader"><span id="PRNT-sublogo">Presupuesto</span></div>
                        <table>
                            <tr >
                            <td id="PRNT-userdetails">
                                    <table class="PRNT-userdetails-table">
                                        <tr><th>Cliente: </th><td>${content.uiname}</td></tr>
                                        <tr><th>DNI:</th><td>${content.uiDNI}</td></tr>
                                        <tr><th>Dirección: </th><td>${content.uidir}</td></tr>
                                        ${other1}
                                        ${other2}
                                    </table>
                                    </td>
                            <td id="PRNT-presdetails">
                            <table class="PRNT-userdetails-table">
                                <tr><th>Fecha:</th><td>${content.uidate}</td></tr>
                                <tr><th>Validez:</th><td>30 días</td></tr>
                                <tr><th>Número:</th><td>${content.presnum}</td></tr>
                            </table>
                            </td>
                                </tr>
                        </table>
                    </div>
                    <div id="PRNT-content">
                        <table id="PRNT-table">
                            <tr id="PRNT-tablehead">
                                <th class="cc c50 mid">Producto</th>
                                <th class="cc c15">Cantidad</th>
                                <th class="cc c10">IVA</th>
                                <th class="cc c15">Subtotal</th>
                            </tr>
                            ${productArticles((content.producto))}
                        </table>
                    </div>
                    <table>
                    <tr>
                    <td id="PRNT-left-sum">
                    Text
                    </td>
                    <td id="PRNT-sum">
                    <div class="PRNT-strong lpad20">Subtotal: <span id="PRNT-IVA" class="PRNT-normal">${content.SUBTOTAL}€</span></div>
                    <br>
                    <div class="PRNT-strong lpad20">IVA( ${content.IVAtotalpercent}% ): <span id="PRNT-IVA" class="PRNT-normal">${content.IVAtotalamount}€</span></div>
                    <br>
                    <div class="PRNT-totaldeco">
                    <div class="PRNT-strong">TOTAL A PAGAR: <span id="PRNT-TOTAL" class="PRNT-normal">${content.GRANDTOTAL}€</span></div>
                    </td>
                    </tr>
                    </table>
                    <div >
                        
                    </div>
                    <div >
                        
                        
                        </div>
                        <br>
                    </div>
                </div>
    `;
    console.log(pdfCore)
    return pdfCore;
}