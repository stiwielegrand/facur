let DLpres = document.querySelector(".DLpres"),
    DLfact = document.querySelector(".DLfact"),
    DLfactcomp = document.querySelector(".DLfactcomp"),
    DLfrom = document.querySelector("[name='DLfrom']"),
    DLto = document.querySelector("[name='DLto']"),
    DLtype = document.querySelector(".DLtype"),
    DLexcel = document.querySelector("[data-output='excel']"),
    DLstyle = document.querySelector("[class*='DLtype']"),
    DLtimespan = document.querySelector("[class*='DLtimespan']"),
    DLyear = document.querySelector("[class*='DLyear']"),
    DLstart = document.querySelectorAll("[class*='DLstart']"),
    DLpdf = document.querySelector("[data-output='pdf']");
    
let requestLink = "assets/php/report.php";
let DLcontent = document.querySelector("[class*='DLcontent']");

//UI
/*DLstyle.addEventListener("change", buttons);*/
DLtimespan.addEventListener("change", autofillDate);
DLyear.addEventListener("change", autofillDate);

autofillDate()

/*function buttons() {
    if(DLstyle.value == "doc") {
        console.log(DLexcel)
        DLexcel.style.display = "none";
    }
    if(DLstyle.value == "info"){
        DLexcel.style.display = "";
    }
}*/

function autofillDate(){
    let currTimespan = document.querySelector("[class*='DLtimespan']").value;
    let currDLyear = document.querySelector("[class*='DLyear']").value;
    if(currTimespan == 5){
        DLfrom.value=firstday(currDLyear,1);
        DLto.value = lastday(currDLyear,12);
    }
    else {
        DLfrom.value = firstday(currDLyear,currTimespan-2);
        DLto.value=(lastday(currDLyear,currTimespan));
    }
}

//FUNCTIONALITY
Array.from(DLstart).forEach(function(button){
    button.addEventListener("click", function(){
        console.log(button.dataset.output)
        startDownload(button.dataset.output)
    })
})

function startDownload(format){

    $('#DL').modal('open');

    let link= `${requestLink}
                ?format=${format}
                &factura=${DLfact.checked}
                &presupuesto=${DLpres.checked}
                &facturaCompra=${DLfactcomp.checked}
                &from=${DLfrom.value}
                &to=${DLto.value}
                &content=${DLtype.value}`;
    console.log(link)
    let XHR = new XMLHttpRequest();

    XHR.addEventListener("progress", DLloading)
    XHR.addEventListener("error", DLloaderr)
    XHR.addEventListener("load", function () {
        console.log("loaded")
        let RES = XHR.response;
        /*console.log(RES)
        if (XHR.response.includes("MSQROW0") == true) {
            console.log("loaderr")
            return loaderr("MSQROW0");
        } else {
            console.log("else");
                try {
                    JSON.parse(RES);
                    console.log("not catched")
                } catch (e) {
                    console.log("Catch")
                    return loaderr(RES);
                }
                console.log("works")
                let RESPONSE = JSON.parse(RES);
                console.log(RESPONSE)
                loadsucc();
                return load(RESPONSE);

        }*/
    })
    XHR.open("GET", link, true); //TRY FALSE CHECK WHAT LOADS
    XHR.send(); //SEND ID

}

function DLloading() {
    
        animation =
        `<div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>`;
        DLcontent.innerHTML = "<div class='loadingDL'><h4>Preparando la descarga</h4><br><br>"+animation+"</div>";
    
}

function DLloaderr() {
        DLcontent.innerHTML = "<div class='loadingDL DLerr'><h4>Ha ocurrido un error</h4><br><br><i class='material-icons giantIco'>report_problem</i></div>";
}

function DLempty() {
        DLcontent.innerHTML = "<div class='loadingDL'><h4>No se ha encontrado ningún documento</h4><br><br><h6>No hay documentos con las propiedades seleccionadas. Intente modificar los filtros.</h6></div>";
}

function DLloadsucc() {
    DLcontent.innerHTML = "<div class='loadingDL DLsucc'><h4>Descarga preparada</h4><br><br><i class='material-icons giantIco'>get_app</i></div>";
    setTimeout(function(){
        $('#DL').modal('close');
    },3000)
}