var uiUsername = document.querySelector("[name=login-un]");
var uiPw = document.querySelector("[name=login-pw]");
var uiSubmit = document.querySelector("[name=send]");
var loginWarning = document.querySelector("#login-warning");
var fields =[uiUsername,uiPw];
uiUsername.className += "";

uiSubmit.addEventListener("click", function (e) {
    e.preventDefault;
    loginauth(uiUsername, uiPw);
})

fields.forEach(function(instance){
    instance.addEventListener("keydown", function(){
        loginWarning.innerHTML ="";
    })
})

function loginauth(un, pw) {
    var animation =
        `<div class="spinner">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>`;
    if (un.value != "" && pw.value != "") {
        loginWarning.innerHTML = animation;
        setTimeout(function () {
            let auth = 1;
            if (auth == 1) {
                console.log("works");
                loginWarning.innerHTML ="";
                setTimeout(function(){ 
                    let loginInterface = document.querySelector(".login-interface")
                    loginInterface.classList.add("getOut");
                    document.querySelector("html").style.overflow = "hidden";
                    document.body.classList.add("bg-transition");
                    setTimeout(function(){
                        window.location.assign("../index.html")
                    },2000)
                },500)
            }
            else 
            {
                var fieldContainer = pw.parentElement.parentElement;
                loginWarning.innerHTML = "Error!";
                fieldContainer.className += " animated shake infinite incorrect";
                pw.className += " incorrect-input";
                setTimeout(function () {
                    fieldContainer.classList.remove("animated");
                    fieldContainer.classList.remove("incorrect");
                    fieldContainer.classList.remove("shake");
                    fieldContainer.classList.remove("infinite");
                    pw.value = "";
                    pw.classList.remove("incorrect-input");
                    pw.focus();
                }, 500)
            }
        }, 500)

    }
    else {
        fields.forEach(function(field){
            if (field.value == ""){
                var fieldsContainer = field.parentElement.parentElement;
                console.log(fieldsContainer)
                fieldsContainer.className += " animated shake infinite";
                setTimeout(function(){
                    fieldsContainer.classList.remove("animated");
                    fieldsContainer.classList.remove("incorrect");
                    fieldsContainer.classList.remove("shake");
                    fieldsContainer.classList.remove("infinite");
                    un.focus();
                },500)
            }
        })
    }
}   