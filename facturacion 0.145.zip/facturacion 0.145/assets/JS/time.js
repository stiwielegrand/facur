let fullDate = new Date();
let currYear = fullDate.getUTCFullYear();
let currMonth = fullDate.getUTCMonth() + 1;
let currDay = fullDate.getUTCDate();
let currentDate = currDay + "-" + currMonth + "-" + currYear;

function TrimSelector(current) {
    if (current <= 3){
        return["Enero","Marzo",firstday(currYear,1),lastday(currYear,3)];
    }
    else if(current <= 6){
        return["Abril","Junio",firstday(currYear,4),lastday(currYear,6)];
    }
    else if(current <= 9){
        return["Julio","Septiembre",firstday(currYear,7),lastday(currYear,9)];
    }
    else if(current <= 12){
        return["Octubre","Diciembre",firstday(currYear,10),lastday(currYear,12)];
    }
}

function lastday(y,m) {
    let lastday = new Date(y,m,0);
    return `${lastday.getDate()}-${m}-${y}`;
}

function firstday (y,m) {
    let firstday = new Date(y,m-1,1);
    return `${firstday.getDate()}-${m}-${y}`;
}