<?php
require('scripts/PDO.php');
$auth = "author"; //GET IT FROM THE SESSION

//INDIVIDUAL VALUES
//$uiname         =$_POST['uiname'];
//$uitlf          =$_POST['uitlf'];
//$uiDNI          =$_POST['uiDNI'];
//$uidir          =$_POST['uidir'];
//$uiemail        =$_POST['uiemail'];
//$uiother1       =$_POST['uiother1'];
//$uifecha        =$_POST['uidate'];
//$uiother2       =$_POST['uiother2'];
//$presnum        =$_POST['presnum'];
//$uipresname     =$_POST['uipresname'];
////ARRAY VALUES
// $UIproduct[]    =$_POST['INPUIproductINP[]'];
// $UIid[]         =$_POST['UIid[]'];
// $UIcantidad[]   =$_POST['UIcantidad[]'];
// $UIunidad[]     =$_POST['UIunidad[]'];
// $UIprecio[]     =$_POST['UIprecio[]'];
// $OPsubtotal[]   =$_POST['OPsubtotal[]'];
// $UIiva[]        =$_POST['UIiva[]'];
// $UIcomsINP[]    =$_POST['UIcomsINP[]'];

// $uiname = "dummyform";
// $uitlf = "dummyform";
// $uiDNI = "dummyform";
// $uidir = "dummyform";
// $uiemail = "dummyform";
// $uiother1 = "dummyform";
// $uifecha = "dummyform";
// $uiother2 = "dummyform";
// $uipresname = "dummyform";
// //ARRAY VALUES
// $UIproduct[] = "dummyform";
// $UIid[] = "dummyform";
// $UIcantidad[] = "dummyform";
// $UIunidad[] = "dummyform";
// $UIprecio[] = "dummyform";
// $OPsubtotal[] = "dummyform";
// $UIiva[] = "dummyform";
// $UIcomsINP[] = "dummyform";


//FUNCTIONS

function newpresno($current){
    global $dsn, $username, $pw, $pdo;
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if($current == ''){
        $highest_vers = 1;
        $sql = "SELECT MAX(presno) AS highest FROM headers_pres";
        $stmt = $pdo->query($sql);
        $highest = $stmt->fetch()['highest']+1;
    }
    else{
        $highest = $current;
        $sql = "SELECT MAX(vers) AS highest FROM headers_pres WHERE presno=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$current]);
        $highest_vers = $stmt->fetch()['highest']+1;
    }
    return array ($highest,$highest_vers);
}

function newEntry() {
    echo "runs";
    global $dsn, $username, $pw, $pdo, $auth;
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $presnum = $_POST['presnum'];
    $CurrMax = newpresno($presnum);
    $newPresNum = $CurrMax[0];
    $vers = $CurrMax[1];
    $uiname = $_POST['uiname'];
    $uitlf = $_POST['uitlf'];
    $uiDNI = $_POST['uiDNI'];
    $uidir = $_POST['uidir'];
    $uiemail = $_POST['uiemail'];
    $uiother1 = $_POST['uiother1'];
    $uifecha = $_POST['uidate'];
    $uiother2 = $_POST['uiother2'];
    $uipresname = $_POST['uipresname'];
    

    $UIproduct = $_POST['UIproductINP'];
    $UIid = $_POST['UIid'];
    $UIcantidad = $_POST['UIcantidad'];
    $UIunidad = $_POST['UIunidad'];
    $UIprecio = $_POST['UIprecio'];
    $OPsubtotal = $_POST['OPsubtotal'];
    $UIiva = $_POST['UIiva'];
    $UIcomsINP = $_POST['UIcomsINP'];

    try {
        $sql = "INSERT INTO headers_pres (presno,vers,auth,uiname,uitlf,uidni,uidir,uiemail,uiother1,uiother2,uifecha,uipresname,lang,presstate) VALUES (:presno,:vers,:auth,:uiname,:uitlf,:uidni,:uidir,:uiemail,:uiother,:uiother2,:uifecha,:uipresname,'es','1')";
        $ref = [
            'presno' => $newPresNum,
            'auth' => $auth,
            'uiname' => $uiname,
            'uitlf' => $uitlf,
            'uidni' => $uiDNI,
            'uiemail' => $uiemail,
            'uiother' => $uiother1,
            'uiother2' => $uiother2,
            'uifecha' => $uifecha,
            'uipresname' => $uipresname,
            'uidir' => $uidir,
            'vers' => $vers
        ];
        $stmt = $pdo->prepare($sql);
        $stmt->execute($ref);
        $headerID = $stmt ->lastInsertID();

        $sql2 = ("INSERT INTO pres (uiid,uiproduct,uicant,uiunidad,uiprecio,uiiva,uicoms) VALUES (:uiid,:uiproduct,:uicant,:uiunidad,:uiprecio,:uiiva,:uicoms)"); // ID shouuld be called headerID in mysql
        $i = 0;
        while (sizeof($UIid) > $i) {
            $ref2 = [
                'uiid' => $headerID,
                'uiproduct' => $UIproduct[$i],
                'uicant' => $UIcantidad[$i],
                'uiunidad' => $UIunidad[$i],
                'uiprecio' => $UIprecio[$i],
                'uiiva' => $UIiva[$i],
                'uicoms' => $UIcomsINP[$i]
            ];
            $stmt2 = $pdo->prepare($sql2);
            $stmt2->execute($ref2);
            $i++;
        }
    } catch (Exception $e) {
        echo 'Exception -> ';
        var_dump($e->getMessage());
        // echo 'Vaya, parece que ha ocurrido un error!';
    }
}


if (isset($_POST['uipresname'])) {
        newEntry();
}
?>
