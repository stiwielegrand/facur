<?php

require('scripts/PDO.php');
require('scripts/sanitize.php');

function edit($q, $qparams) {
    global $dsn, $username, $pw, $pdo;
    try {
            $stmt  = $pdo->prepare("SELECT * FROM ajustes"); 
            $stmt -> execute();

            }
        catch(Exception $e) {
            echo 'Exception -> ';
            var_dump($e->getMessage());
        }
    }

$id = $_GET['id'];
$table = null;
if($_GET['type'] == "pres"){
    $table = "headers_pres";
}else if($_GET['type'] == "fact"){
    $table = "headers_fact";
}

if($_GET['edit'] == "state"){
    $new = $_GET['newstate'];
    $qParams = array('new'=>$new,'id'=>$id);
    $q = "UPDATE ".$table."SET presstate = :new WHERE id = :id";
}



?>