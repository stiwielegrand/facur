<?php

$sendTo = $_POST['sendTo'];
$Text = $_POST['Text'];
$sendToName = $_POST['sendToName'];

// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
require_once 'dompdf/lib/html5lib/Parser.php';
require_once 'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
require_once 'dompdf/lib/php-svg-lib/src/autoload.php';
require_once 'dompdf/src/Autoloader.php';
Dompdf\Autoloader::register();

// reference the Dompdf namespace
use Dompdf\Dompdf;
use PHPMailer\src\PHPMailer;
use PHPMailer\src\Exception;
//Load Composer's autoloader
/*require 'vendor/autoload.php';*/

function PDF(){
    $dompdf = new Dompdf();
    $dompdf->loadHtml('

<html><head>
<title>Impresion</title>
<link rel="stylesheet" href="assets/print.css" media="print">
<link rel="stylesheet" href="assets/print.css" media="screen">
<link href="https://fonts.googleapis.com/css?family=Raleway:900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<style>

body {
    font-family: "Open Sans", sans-serif;
    margin: 50px 0 ;
}

@page {
    margin: 50px 50px;
    padding: 20px;
}

#PRNT-printable, #PRNT-printable *, .PRNT {
    visibility: visible;
    overflow: visible;
    overflow-y:visible;
}

#PRNT-printable {
    overflow:visible; 
    width: 80%;
    height: 100%;
    margin: 0 auto;
    left: 15%;
    overflow:visible !important;
    overflow-y:visible !important;
}

#PRNT-logo {
    font-weight: bolder;
    color: #659264;
    font-size: 4.1rem;
    font-family: "Raleway", sans-serif;
    text-transform: capitalize;
    margin-bottom: 50;
}

#PRNT-sublogo {
    font-weight:bolder;
    color: #659264;
    font-size: 2rem;
    font-family: "Open Sans", sans-serif;
    text-transform: uppercase;
    margin-left: 60%;
    background: #fff;
    margin-right: 20%;
    padding: 0 32px;
}

#PRNT-subheader {
    /*background: #ff8000;*/
    background: #659264;
    height: 38px;
    width: 140%;
    margin-top: 20px;
    padding: 0;
    margin-left: -20%;
    margin-right: -20%;
}

#PRNT-userdetails {
    width: 56%;
    margin-top: 20px;
    margin-right: 4%;
}

.PRNT-userdetails-table * {
    text-align: left !important;
}
.PRNT-userdetails-table th {
    padding-right: 25px !important; 
    color: #8c8c8c;
    text-transform: uppercase;
    font-weight: normal;
}

.PRNT-userdetails-table td {
    color: #4f4f4f !important;
}

#PRNT-presdetails {
    width: 40%;
    margin-top: 20px;
}

.PRNT-strong {
    font-weight:600;
    text-transform: uppercase;
    color: #4f4f4f !important;
}

#PRNT-content {
    margin-top: 25px;
    padding-top: 20px;
}

#PRNT-sum {
    margin-left:5%px;
    margin-top: 50px;
    font-size: large;
    overflow: visible;
    width: 40%;
}

#PRNT-left-sum {
    margin-top: 50px;
    width: 40%;
    font-size: small;
    overflow: visible;
}

/*PRNT-TABLE SETTINGS*/

#PRNT-table {
    margin-top: 25px;
    width:100% !important;
}

#PRNT-table td {
    vertical-align: top;
    text-align: center;
    padding: 10px 10px 0 0;
    color: #8c8c8c;
}

#PRNT-tablehead {
    color: black;
    border: 0 0 5px 0 solid black;
    text-transform:uppercase;
}

#PRNT-table tr {
    page-break-inside: avoid;
}

/*SUPPORT */

.lpad20 {
    padding-left: 20px;
}

.lft {
    text-align: left !important;
    padding: 20px;
}

.c10 {
    width: 10%;
    text-align: center !important;
    
}

.c15 {
    width: 20%;
    text-align: center !important;
}

.c50 {
    width: 50%;
    text-align: left !important;
}

.cc{
    border-bottom: #c4c4c4;
    border-bottom-style: solid;
    border-width: 1px;
    padding-bottom: 20px;
    color: #8c8c8c;
    text-align: left;
    font-weight: normal;
}

.PRNT-normal {
    font-weight: normal;
}

.PRNT-totaldeco{
    background-color: #659264;
    width: 150%;
    height: 30px;
    padding: 20px;
    color: black;
}

</style>

</head>
<body>
'.$_POST['PDF'].'
</body>
</html>

');
// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

$output = $dompdf->output();
$outputDir = "./PDFs/".time()."_".$sendToName.".pdf";
file_put_contents($outputDir, $output);
return $outputDir;
}


$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp!!!';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'info@isolatec.es';                 // SMTP username
    $mail->Password = 'contrasena';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('info@isolatec.es', 'Isolatec');
    $mail->addAddress($sendTo, $sendToName);     // Add a recipient

    //Attachments - PDF version????
    $mail->addAttachment(PDF());         // Add attachments

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Mensaje de Isolatec.es ';
    $mail->Body    = $Text;
    $mail->AltBody = $Text;

    $mail->send();
    echo 'TRUE';
} catch (Exception $e) {
    echo 'FALSE', $mail->ErrorInfo;
}

?>