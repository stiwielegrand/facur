<?php
require('scripts/PDO.php');
// $id = $_GET['id'];
define("LC","listContent");
define("AC","articleContent");

function sanitize($target,$type){
    if(!$type){
        $sanitized = filter_var($target, FILTER_SANITIZE_STRING);
        return $sanitized;
    }
    else if ($type ="number") {
        $target = filter_var(preg_replace("([^0-9/] | [^0-9-])","",htmlentities($target)));
        return $target;
    }
}

function queryProceed($q, $qParams, $fetchedContentType){
    if($fetchedContentType == LC){
        try {
            $stmt  = $pdo->prepare($q); 
            $stmt -> execute($qParams)
            $JSON = new \stdClass();
            while($row = $stmt->fetch()){
                $id = $row['id'];
                echo $id;
                $JSON->connection = "success";
                $JSON->ID = $row['id'];
                $JSON->uiname = $row['uiname'];
                $JSON->uitlf = $row['uitlf'];
                $JSON->presnum = $row['presno'];
                $JSON->uipresname = $row['uipresname'];
                $JSON->uidate = $row['uifecha'];
                $JSON->SUBTOTAL = $row['GRANDTOTAL'];
                $JSON->uiid = $row['uiid'];
                $JSON->uiid = $row['state'];
                }
            return $JSON;
            }
        catch(Exception $e) {
            echo 'Exception -> ';
            var_dump($e->getMessage());
            $JSON->connection = "failed";
            $JSON->err = "MSQL error";
            $JSON->errmsg = $e->getMessage();
            return $JSON;
        }
    }
    else if($fetchedContentType == AC){
        try {
        $stmt  = $pdo->query($q); 
        $JSON = new \stdClass();
        while($row = $stmt->fetch()){
            $id = $row['id'];
            echo $id;
            $JSON->connection = "success";
            $JSON->ID = $row['id'];
            $JSON->uiname = $row['uiname'];
            $JSON->uitlf = $row['uitlf'];
            $JSON->uiDNI = $row['uidni'];
            $JSON->uidir = $row['uidir'];
            $JSON->uiemail = $row['uiemail'];
            $JSON->uiother1 = $row['uiother1'];
            $JSON->uiother2 = $row['uiother2'];
            $JSON->presnum = $row['presno'];
            $JSON->uipresname = $row['uipresname'];
            $JSON->uidate = $row['uifecha'];
            $JSON->SUBTOTAL = $row['SUBTOTAL'];
            $JSON->GRANDTOTAL = $row['GRANDTOTAL'];
            $JSON->IVAtotalamount = $row['IVAtotalamount'];
            $JSON->IVAtotalpercent = $row['IVAtotalpercent'];
            $vers = $row['vers'];
            }
        $stmt2  = $pdo->query("SELECT pres.* FROM pres WHERE assocID=$id"); //SET UP ASSOC ID to look fot the headers ID 

            $results = $stmt2->fetchAll();
            foreach ($results as $row){
                echo $row['id']."<br>";
                $JSON ->prodid[] ->ID = $row['id'];
                $JSON ->prodid[] ->uiproduct= $row['uiproduct'];
                $JSON ->prodid[] ->UIcantidad= $row['UIcantidad'];
                $JSON ->prodid[] ->UIunidad= $row['UIunidad'];
                $JSON ->prodid[] ->UIprecio= $row['UIprecio'];
                $JSON ->prodid[] ->UIcomsINP= $row['UIcomsINP'];
                $JSON ->prodid[] ->UIiva= $row['UIiva'];

            }
            echo "<pre>",var_dump($JSON),"</pre>";
            return $JSON;
        }
        catch(Exception $e) {
        echo 'Exception -> ';
        var_dump($e->getMessage());
        $JSON->connection = "failed";
        return $JSON;
        }

    }
    
}

if(isset($_GET['type'])&&$_GET['type'] == "sorting") {
    $from = $until = $user = $sorttype = "";
    $sortedQuery = "SELECT *, MAX(vers) AS highest_vers FROM pres GROUP BY id";
    if(isset($_GET['criteria1'])||isset($_GET['criteria2'])||isset($_GET['criteria3'])) {
        $sortedQuery .= " WHERE";
        if (isset($_GET['criteria1'])){
            $from = sanitize($_GET['criteria1'],"number"));
            $sortedQuery .= " date < :from";
        }
        if (isset($_GET['criteria2'])){
            if(isset($from)) {
                $sortedQuery .= " AND";
            }
            $until = sanitize($_GET['criteria1'],"number");
            $sortedQuery .= " date > :until";
        }
        if (isset($_GET['criteria3'])){
            if(isset($from) || isset($until)){
                $sortedQuery .= " AND";
            }
            $user = sanitize($_GET['criteria3']);
            $sortedQuery .= " uiname = :user";
        }
        if(isset($_GET['sorttype'])){
            $sorttype = sanitize($_GET['sorttype']);
            $sortedQuery .= " ORDER BY = :sort";
        }
    }
    $qParams = [
        'from' => $from,
        'until' => $until,
        'user' => $user,
        'sort' => $sorttype
    ];
    echo $sortedQuery;
    queryProceed($sortedQuery,$qParams,LC)
}
else if (isset($_GET['type'])&&$_GET['type'] == "article") {
    $qParams = ['id' => sanitize($_GET['ID'], "number")];

    queryProceed($singleQ, $qParams, AC);
} 

?>