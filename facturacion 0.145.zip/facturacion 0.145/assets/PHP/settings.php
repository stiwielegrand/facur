<?php

require('scripts/PDO.php');
require('scripts/sanitize.php');


    global $dsn, $username, $pw, $pdo;
    try {
            $stmt  = $pdo->prepare("SELECT * FROM ajustes"); 
            $stmt -> execute();

            while($row = $stmt->fetch()){
                $ajustes = array(
                'empresa' => $row['empresaid'],
                'cif' => $row['cif'],
                'calle' => $row['calle'],
                'postal' => $row['postal'],
                'poblacion' => $row['poblacion'],
                'tel' => $row['tel'],
                'email' => $row['email']
                );
                $PresMailTemplate = $row['PresMailTemplate'];
                $FactMailTemplate = $row['FactMailTemplate'];
                $PresTemplate = $row['PresTemplate'];
                $FactTemplate = $row['FactTemplate'];
                $defaultMail = $row['defaultMail'];
                }
            // return $JSON;
            }
        catch(Exception $e) {
            echo 'Exception -> ';
            var_dump($e->getMessage());
            $JSON->connection = "failed";
            $JSON->err = "MSQL error";
            $JSON->errmsg = $e->getMessage();
            return $JSON;
        }
    
if($_GET['req'] == "mailtxt"){
    if($_GET['for'] == "pres")
    {
        return $PresMailTemplate;
    }

    else if($_GET['for'] == "fact")
    {
        return $FactMailTemplate;
    }
}

if($_GET['req'] == "prestemp"){
    if()
}

if($_GET['req'] == "compinfo"){
    if(!empty($ajustes)){
        return json_encode($ajustes);
    }
    else{
        return false;
    }
}


?>