<?php
require('scripts/PDO.php');
require('scripts/sanitize.php');
// $id = $_GET['id'];
define("LC","listContent");
define("AC","articleContent");
define("LIM","limited");
define("METR", "metric");
define("RETR","retrieve");

function match_SQL($initial) {
    if($initial == "num") {
        return "presno";
    }
    else {
        //default
        return "uipresname";
    }
}

function queryProceed($q, $qParams, $fetchedContentType, $limit){
  
    //  echo "q: ".$q."<br>";
    // $q = "SELECT * FROM headers_pres WHERE uifecha BETWEEN :fromdate AND :until ORDER BY presno";
    // echo "q: ".$q."</br>";
    // echo "<br>";
    // var_dump($qParams);
    // echo "<br>";
    // echo "<br>";
    // echo "type: ".$fetchedContentType."<br>";
    global $dsn, $username, $pw, $pdo;
    if($fetchedContentType == LC){
        try {
            $stmt  = $pdo->prepare($q); 
            $stmt -> execute($qParams);
            $JSON = array();
            if ($stmt->rowCount() < 1) {
                echo 'MSQROW0';
                return 0;
            }
            while($row = $stmt->fetch()){
                $id = $row['id'];
                $JSON_elem = array(
                'ID' => $row['id'],
                'uiname' => $row['uiname'],
                'uitlf' => $row['uitlf'],
                'presnum' => $row['presno'],
                'uipresname' => $row['uipresname'],
                'uidate' => $row['uifecha'],
                'GRANDTOTAL' => $row['GRANDTOTAL'],
                'status' => $row['presstate']
                // $JSON->uiid => $row['state'],
                );
                array_push($JSON, $JSON_elem);
                }
                // var_dump($JSON);
            return $JSON;
            }
        catch(Exception $e) {
            echo 'Exception -> ';
            var_dump($e->getMessage());
            $JSON->connection = "failed";
            $JSON->err = "MSQL error";
            $JSON->errmsg = $e->getMessage();
            return $JSON;
        }
    }
    else if($fetchedContentType == AC){
        try {
        $stmt  = $pdo->prepare($q); 
        $stmt -> execute($qParams);
        $JSON = array();
        while($row = $stmt->fetch()){
            $id = $row['id'];
            echo $id;
            $JSON = array(
            'ID' = $row['id'],
            'uiname' => $row['uiname'],
            'uitlf' => $row['uitlf'],
            'uiDNI' => $row['uidni'],
            'uidir' => $row['uidir'],
            'uiemail' => $row['uiemail'],
            'uiother1' => $row['uiother1'],
            'uiother2' => $row['uiother2'],
            'presnum' => $row['presno'],
            'uipresname' => $row['uipresname'],
            'uidate' => $row['uifecha'],
            'SUBTOTAL' => $row['SUBTOTAL'],
            'GRANDTOTAL' => $row['GRANDTOTAL'],
            'IVAtotalamount' => $row['IVAtotalamount'],
            'IVAtotalpercent' => $row['IVAtotalpercent']);
            $vers = $row['vers'];
            }
            
            $stmt2  = $pdo->query("SELECT * FROM pres WHERE assocID = $id"); 
            $JSONprod = array();
            // $results = $stmt2->fetchAll();
            while ($row = $stmt2->fetch()){
                // echo $row['id']."<br>";
                $JSONprod_elem = array( 
                'ID' = $row['id'],
                'uiproduct'=> $row['uiproduct'],
                'UIcantidad'=> $row['UIcantidad'],
                'UIunidad'=> $row['UIunidad'],
                'UIprecio'=> $row['UIprecio'],
                'UIcomsINP'=> $row['UIcomsINP'],
                'UIiva'=> $row['UIiva']);
                array_push($JSONprod, $JSONprod_elem);
            }
            // echo "<pre>",var_dump($JSON),"</pre>";
            $JSON->producto=$JSONprod;
            return $JSON;
        }
        catch(Exception $e) {
        echo 'Exception -> ';
        var_dump($e->getMessage());
        $JSON->connection = "failed";
        return $JSON;
        }

    }
    else if($fetchedContentType == LIM) {
        try {
            $stmt  = $pdo->prepare($q); 
            $stmt -> execute($qParams);
            $JSON = array();
            while ($row = $stmt->fetch()){
                $JSON[] = array(
                    'id =>'$row['id'], 
                    'presname'=>$row['uipresname'],
                    'date' => $row['uifecha']);
            }
            return $JSON;
        }
        catch (Exception $e){
            echo 'Exception -> ';
            var_dump($e->getMessage());
            $JSON->connection = "failed";
            return $JSON;
        }
    }
    else if($fetchedContentType == METR) {
        try {
            $stmt  = $pdo->prepare($q); 
            $stmt -> execute($qParams);
            $JSON = array();
            while ($row = $stmt->fetch()){
                $JSON[] = array(
                    'id'=>$row['id'] ,
                    'presname'=>$row['uipresname'],
                    'GRANDTOTAL' => $row['GRANDTOTAL'],
                    'IVAtotalamount' => $row['IVAtotalamount'],
                    'status' => $row['status']);
            }
            return $JSON;
        }
        catch (Exception $e){
            echo 'Exception -> ';
            var_dump($e->getMessage());
            $JSON->connection = "failed";
            return $JSON;
        }
    }
        else if($fetchedContentType == RETR) {
        try {
            $stmt -> query();
            $JSON = array();
            while ($row = $stmt->fetch()){
                $JSON[] = array(
                    'ID' = $row['id'],
                    'uiname' => $row['uiname'],
                    'uitlf' => $row['uitlf'],
                    'uiDNI' => $row['uidni'],
                    'uidir' => $row['uidir'],
                    'uiemail' => $row['uiemail']);
            }
            return $JSON;
        }
        catch (Exception $e){
            echo 'Exception -> ';
            var_dump($e->getMessage());
            $JSON->connection = "failed";
            return $JSON;
        }
    }
    
}

$qParams = [];
if(isset($_GET['type'])&&$_GET['type'] == "sorting"&&isset($_GET['content'])) {
    $from = $until = $user = $sorttype = "";
    if($_GET['content'] == "pres"){
        $table = 'headers_pres';
    }
    else if($_GET['content'] == "fact"){
        $table = 'headers_fact';
    }
    else if($_GET['content'] == "comp"){
        $table = "fact_comp"; //DB MIGHT BE DIFFERENT
    }
    $sortedQuery = "SELECT * FROM ".$table; //GROUP BY id
    if(isset($_GET['criteria1'])||isset($_GET['criteria2'])||isset($_GET['criteria3'])) {
        if(($_GET['criteria1']) != ""||($_GET['criteria2']) != ""||($_GET['criteria3'])!= ""||($_GET['criteria4'])!= "") {
            $sortedQuery .= " WHERE  uifecha BETWEEN";
            // if($_GET['criteria1']!=""||$_GET['criteria2']!=""){
            //     $sortedQuery .= " uifecha BETWEEN";
            // }
            if (($_GET['criteria1'])!=""){
                $from = sanitize($_GET['criteria1'],"date");
                $sortedQuery .= " :fromdate";
                $qParams['fromdate'] =$from;
            }
            else{
                $from = "0000-00-00";
                $sortedQuery .= " :fromdate";
                $qParams['fromdate'] =$from;
            }
            if (($_GET['criteria2']!="")){
                if(isset($from)) {
                    $sortedQuery .= " AND";
                }
                $until = sanitize($_GET['criteria2'],"date");
                $sortedQuery .= " :until";
                $qParams['until'] =$until;
            }
            else{
                $until = "0000-00-00";
                $sortedQuery .= " :until";
                $qParams['until'] =$until;
            }
            if (($_GET['criteria3'])!=""){
                if(isset($from) || isset($until)){
                    $sortedQuery .= " AND";
                }
                $user = sanitize($_GET['criteria3'],"");
                $sortedQuery .= " uiname = :user";
                $qParams['user'] =$user;
            }
            if (($_GET['criteria4'])!=""){
                if(isset($from) || isset($until) || isset($user)){
                    $sortedQuery .= " AND";
                }
                $state = $_GET['criteria4'];
                $sortedQuery .= " presstate = :state";
                $qParams['state'] =$state;
            }
        }
    }
    if(isset($_GET['sorttype'])){
        if($_GET['sorttype']!="") {
            $sorttype = sanitize($_GET['sorttype'],"");
            $sortedQuery .= " ORDER BY :sort";
            // $qParams['sort'] = match_SQL($_GET['sorttype']);
        }
    }
    echo json_encode(queryProceed($sortedQuery,$qParams,LC));
}
else if (isset($_GET['type'])&&$_GET['type'] == "article"&&isset($_GET['content'])) {
    $qParams = array('id' => sanitize($_GET['ID'], "number"));
    if($_GET['content'] == "pres") {
        $table = "headers_pres";
    }
    else if($_GET['content'] == "fact"){
        $table = "headers_fact";
    }
    $singleQ = "SELECT * FROM ".$table." WHERE id = :id";

    echo json_encode(queryProceed($singleQ, $qParams, AC));
} 

else if(isset($_GET['type'])&&$_GET['type'] == "demo"&&isset($_GET['content'])){
    $limit = 5
    if($_GET['content'] == "pres"){
        $table = "headers_pres";
    }
    else if($_GET['content'] == "fact"){
        $table = "headers_fact";
    }
    $q= "SELECT id, uipresname FROM ".$table." ORDER BY uifecha DESC LIMIT $limit";
    $fetchedContentType = LIM;
    echo json_encode(queryProceed($q, $qParams, $fetchedContentType, $limit));
}
else if(isset($_GET['type'])&&$_GET['type'] == "metrics"&&isset($_GET['content'])){
    $qParams = array(
        'fromadte' => sanitize($_GET['from'],'date'),
        'until' => sanitize($_GET['until'],'date')
    );
    if($_GET['content'] == "pres"){
        $table = "headers_pres";
    }
    else if($_GET['content'] == "fact"){
        $table = "headers_fact";
    }
    $q= "SELECT id, status, GRANDTOTAL, presname FROM ".$table." WHERE uifecha BETWEEN :fromdate AND :until ";
    $fetchedContentType = METR;
    echo json_encode(queryProceed($q, $qParams, $fetchedContentType, $limit));
}

else if(isset($_GET['type'])&&$_GET['type'] == "retr"&&isset($_GET['content'])){
    $table = "";
    $id = sanitize($_GET['id'],'number');
    $fetchedContentType = RETR;
    $q= "SELECT ".$rows." FROM ".$table;
    $rows = "id, uiname, uitlf, uiDNI, uidir, uiemail";
    if($_GET['content'] == "userlist"){
        $table = "users";
    }
    if($_GET['content'] == "provider"){
        $table = "providers";
    }

/*    else if($_GET['content'] == "prevPres"){
        $fetchedContentType = LIM;
        $table = "headers_pres";
        $rows = "id, uiname, uitlf, uiDNI, uidir, uiemail";
        $q= "SELECT ".$rows." FROM ".$table." WHERE presno = :id";
    }*/
    
    
    echo json_encode(queryProceed($q, $qParams, $fetchedContentType, $limit));
}


?>