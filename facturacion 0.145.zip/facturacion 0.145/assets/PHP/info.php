<?php

if($_GET['info'] == "username") {
    if($_SESSION["login"]) {
        echo  $_SESSION["login"];
    }
}

?>