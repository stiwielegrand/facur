<?php

function sanitize($target,$type){
    if(!$type){
        $sanitized = filter_var($target, FILTER_SANITIZE_STRING);
        return $sanitized;
    }
    else if ($type =="number") {
        $target = preg_replace('/[^0-9-]/', '', $target);
        return $target;
    }
    else if ($type == "date") {
        $target = preg_replace('/[^0-9-]/', '', $target);
        $target = date("Y-m-d", strtotime($target));
        return $target;
    }
}

?>