<?php
$server     = "127.0.0.1";
$username   = "root";
$pw         = "";
$dbname     = "isolatec";
$dsn        = "mysql:hosts=".$server.";dbname=".$dbname.";charset=utf8";
$pdo = new PDO($dsn, $username, $pw);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
?>
