<?php 
require('scripts/PDO.php');
global $dsn, $username, $pw, $pdo;

function requestPresInfo($SQLtable){
    $PresInfo = array();
    try{
        $stmt  = $pdo->prepare("SELECT * FROM ".$SQLtable." WHERE uifecha BETWEEN :fromdate AND :until");
        $qParams = [":fromdate" => datecheck($_GET['from']), ":until" => datecheck($_GET['to'])];
        $stmt -> execute($qParams);
        while($row = $stmt->fetch()){
                $id = $row['id'];
                $PresInfoElem = array(
                'ID' => $row['id'],
                'uiname' => $row['uiname'],
                'presnum' => $row['presno'],
                'uipresname' => $row['uipresname'],
                'uidate' => $row['uifecha'],
                'GRANDTOTAL' => $row['GRANDTOTAL'],
                'status' => $row['presstate']);
                array_push($PresInfo, $PresInfoElem);
                }
            return $PresInfo;
            }
    catch(Exception $e){

    }
}

/*function requestFactInfo() {
    $factInfo = array();
    try{$stmt  = $pdo->prepare("SELECT * FROM headers_fact WHERE uifecha BETWEEN :fromdate AND :until");
        $qParams = [":fromdate" => datecheck($_GET['from']), ":until" => datecheck($_GET['to'])];
        $stmt -> execute($qParams);
        while($row = $stmt->fetch()){
                $id = $row['id'];
                $factInfoElem = array(
                'ID' => $row['id'],
                'uiname' => $row['uiname'],
                'presnum' => $row['presno'],
                'uipresname' => $row['uipresname'],
                'uidate' => $row['uifecha'],
                'GRANDTOTAL' => $row['GRANDTOTAL'],
                'status' => $row['presstate']);
                array_push($factInfo, $PresInfoElem);
                }
            return $factInfo;
            }
    catch(Exception $e){

    }
}

function requestCompInfo() {
    $compInfo = array();
    try{$stmt  = $pdo->prepare("SELECT * FROM headers_comp WHERE uifecha BETWEEN :fromdate AND :until");
        $qParams = [":fromdate" => datecheck($_GET['from']), ":until" => datecheck($_GET['to'])];
        $stmt -> execute($qParams);
        while($row = $stmt->fetch()){
                $id = $row['id'];
                $compInfoElem = array(
                'ID' => $row['id'],
                'uiname' => $row['uiname'],
                'presnum' => $row['presno'],
                'uipresname' => $row['uipresname'],
                'uidate' => $row['uifecha'],
                'GRANDTOTAL' => $row['GRANDTOTAL'],
                'status' => $row['presstate']);
                array_push($compInfo, $compInfoElem);
                }
            return $compInfo;
            }
    catch(Exception $e){

    }
}*/

function datecheck($target) {
        if($target != ""){
        $target = preg_replace('/[^0-9-]/', '', $target);
        $target = date("Y-m-d", strtotime($target));
        return $target;
        }
        else {
            return "0000-00-00";
        }
}

function CSV($content,$filename){
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename='.$filename.'.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, array('Column 1', 'Column 2', 'Column 3')); /* Change column names */    mysql_select_db('database');

    while ($row = mysql_fetch_assoc($rows)) fputcsv($output, $content);
}

if(isset($_GET)){
    $facturas = $presupuestos = $compras = "";
    if($_GET['content'] == "info"){
        $comp = ["factura" => $_GET['factura'],"presupuesto" => $_GET['presupuesto'],"presupuestoCompra" => $_GET['facturaCompra']];
        if($_GET['format'] == "excel"){
            if($comp['factura'] == true){
                $facturas = requestPresInfo("headers_fact");
            }
            if($comp['presupuesto'] == true){
                $presupuestos = requestPresInfo("headers_pres");
            }
            if($comp['presupuestoCompra'] == true){
                $compras = requestPresInfo("headers_comp");
            }
        CSV($presupuestos, 'presupuestos'.datecheck($_GET['from'].' - '.datecheck($_GET['to']);
        }
        if($_GET['format'] == "pdf"){

        }
    }
}

?>