





/*

TO BE DONE:

----async/await:
index: connect backend frontend for:
-statistics
-ultimos presupuestos /facturas
-calcular estadisticas

General:
-mails system

----Frontend:
index: calcular estadisticas

----Backend: 
index:
-revisar si funciona el backend para datos

presupuestos:
-check filters
-check content load

General: 
-Login /session system implement
-Search engine















*/

//JS

//fixme:  [x] materialize modals
//TODO: [x] Add delete action if the button was cliucked not the icon in crear_presupuesto.html
//FIXME: [x] IMPORTANT units to be checked in the dynamically created fields 
// TODO : [x] Add waring if del 
//TODO : [x]if empty fields do not prompt modal 
//FIXME : [x]when not clicked away the vaules do not chnage like adding iva to total
//TODO: [x]add a reverse percentage utility
//TODO: [x]Auto date slider funcionality implement
//FIXME :[x] if modal opened window shifts to the right
//EXTRA: [x] SIMPLIFY sumLinear
//TODO: [x]implement ID sys
//FIXME: [x]IVA counting issues when IVA 0%
//EXTRA [x]LIVE FIELD VALIDATION


//FIXME: subtotal marked as invalid
//FIXME : the left slider occupies space when invisible
// FIXME CRITICAL!!!! - PDO https://websitebeaver.com/php-pdo-prepared-statements-to-prevent-sql-injection // PREVENT PASSWORD LEAK
//FIXME: calc truncate 2 digits may give incorrect resuelts 1 = 0.99
//FIXME: TRUNCATE 2 decimals on iva calcualation diff iva
//TODO: add focus to the invalid eleemnt when submitting form 
//FIXME: MATCH HTML INPUT FILEDS WITH THE ONES TO BE ADDED
//TODO: check for unidades like m2 and convert it to expo number
//TODO : Limit annual dispaly 
//TODO : Tap target bottom add buttons
//TODO: Add animations
//TODO: WHen second line is added add del to first
//TODO : implement truncating in stead of toFixed
//FIXME: implement email verification when form submitted
//FIXME: Translate the calendar 
//FIXME : if values pasted functions do not trigger -- PossibleSolution (chrome disbles trigger on Paste)
//FIXME : Search window on autocomplete search icon raises
//TODO: turn buttons gray and only switch on mouseover the color
// EXTRA implement drag and drop place change
// EXTRA: add a loading screen
//EXTRA: smoothState JS - page trasition animation
//EXTRA: add dropdown autocomplete to nombre field + take out client search window
//EXTRA: ANIMATION WHILE SUBMITTED CONTENT IS BEING PROCESSED
//TODO factura datede control / if current factura number or date higher than prevous give option to automatically modify the others
//EXTRA: https://codepen.io/woranov/pen/NRqLWK
//TODO: https://www.codementor.io/amehjoseph/convert-html-css-content-to-a-sleek-multiple-page-pdf-file-using-jspdf-javascript-library-eyyz74hci
//Todo: https://foundation.zurb.com/emails/getting-started.html
//TODO : automatize trimester selector

//TODO ADD EXISITING USER ID to submit for and receive it in MYSQL - 
//PHP
//TODO:ADD OLDER VERSIONS

PLANS 

STATES 
1 - pendiente
2-rechazado
3-aceptado/facturable
4-facturado
5-contabilizado
6-incompleto


Keep

Euro sym 
<i class="material-icons">
euro_symbol
</i>

Primary #659264
P — Light#94c392
P — Dark#396439

data-target="rightcontent" class="sidenav-trigger"

L 993
M 601